import json, os, time
until = time.monotonic() + 1.5
while time.monotonic() < until:
    values = [str(i) for i in range(1000)]
with open('/profile-libraries-cpu-results/access/receipt.json', 'x') as stream:
    json.dump({'diagnostic_pid': os.getpid(), 'diagnostic_parent_pid': os.getppid(), 'diagnostic_profile': True, 'valid_for_comparison': False}, stream)
