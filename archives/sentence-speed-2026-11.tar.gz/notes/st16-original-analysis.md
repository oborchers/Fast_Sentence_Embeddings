# ST-16: Analyse ohne Eingriff

Gesicherte Quelle: /Users/oliverborchers/fse-speed-run/sentence-run/collected/speed-results. Manifest a409cf374700b7dfd8729ce16939dfaefc24b106b1fd9fe8ddc3aaf5369a5a16, alle384 Dateien unabhängig auf Größe/SHA256 geprüft,1980239Bytes. Kein weiterer Test und keine Veränderung auf der Maschine.

## Belegt

- Gefrorener Benchmark-Pin7f2fe04. ST-Job Runde0,5000000 Texte,1024 Dimensionen,16 erlaubte CPUs, installierte sentence-transformers6.2.0.
- Die einzige abgeschlossene Operation dieses Paares ist fse Runde0,2.19097418396Sekunden,22765162496Bytes Kindprozess-Peak. Kein ST-Aufruf abgeschlossen, keine ST-Receipt, ST-Joblog leer.
- Zelle wurde nach1491.8828Sekunden als failed mit Childstatus-9 beendet. SIGKILL durch fse-main war ausdrücklich von Oliver freigegeben. Dieser Status belegt keinen selbstständigen Bibliotheksabsturz.
- Cgroup-Zähler nach Ende des Satzlaufs, beim bereits laufenden Headline-Prozess nur lesend abgefragt: memory.events oom0,oom_kill0,max0; memory.peak69833392128Bytes bei128000000000Byte Grenze. Diese Spitze gilt für die gesamte Container-Lebenszeit, nicht isoliert für ST. Kein OOM-/Limitereignis dokumentiert. CPU-Throttling-Zähler ebenfalls0.
- Unser ST-Adapter setzt torch.set_num_threads(16), nutzt CPU und model.encode(...normalize_embeddings=True,convert_to_numpy=True) ohne Batch-Override.
- Gepinnte ST-Quelle sentence_transformer/model.py nutzt batch_size32. Die Inferenz sammelt Tensoransichten pro Text (Zeile996) und führt danach torch.stack aus (1001). StaticEmbedding nutzt nn.EmbeddingBag und tokenizer.encode_batch.

## Wahrscheinlich, aber nicht bewiesen

Bei5M Texten entstehen156250 Batches pro Encode, bei Warmup plus Messung bis312500. Viele kleine Torch-Aufrufe mit16 Rechenthreads können stark unter Thread-Synchronisierung und Scheduling leiden. Die hohe beobachtete Hostlast kann zusätzlich beitragen. Das erklärt einen sehr langsamen CPU-Pfad plausibler als die unbelegte Behauptung eines Deadlocks.

Die Laufzeit mit einer CPU war im direkten ST-Paar107.79Sekunden pro2M Texte. Eine rein lineare Hochrechnung auf Warmup und Messung von5M läge ungefähr bei9Minuten, ist aber kein gemessener Vergleich. Mehr als24Minuten ohne Receipt zeigen hier fehlende Skalierung oder einen Stillstand, unterscheiden die beiden Fälle aber nicht.

## Nicht rekonstruierbar

Die Receipt wird erst nach Aufwärmen, Messung, Stichprobenspeicherung und Codeprüfung geschrieben. Ohne Stacktrace oder Batch-Fortschritt lässt sich nicht feststellen, ob der Prozess beim Aufwärmen, im gemessenen Encode, beim Stacking oder einem späteren Schritt stand. Aus den gesicherten Logs lässt sich daher keine eindeutige Rootcause beweisen.

Das Paar bleibt failed und ohne veröffentlichte Tempozahlen. Die sieben übrigen gültigen Paare bleiben erhalten. Es gibt keinen neu gestarteten ST-Test und keine Veränderung des laufenden Headline-Codes. Größere Batches wären eine mögliche spätere Optimierung, sind hier nicht getestet und nicht als Beschleunigung belegt.
