# DR-212: ST CPU pool and Linux file-descriptor limit

For DR-212 (Benchmark-Skill fse-benchmark für Claude und Codex schreiben). This is a recorded finding, not implementation of that deferred skill.

The first recommended CPU-pool run used16 processes and batch1024 on5M texts. It failed in torch.multiprocessing.reductions.rebuild_storage_fd, then multiprocessing.reduction.recvfds, with RuntimeError: received0 items of ancdata. The soft RLIMIT_NOFILE was1024, hard524288. The original trace is preserved in studies/st16/attempt1-collected/st16-results/libraries-st-16-0-st.job.log. The maintainer's status.md records the limit and retry command.

The maintainer retried the same source, runner, model and input after raising the soft limit to524288. The retry completed three valid pairs. Read-only observation independently confirmed soft/hard524288 in parent and sampled worker processes. No source change or tolerance change separated these two pool attempts.

PyTorch's file_descriptor sharing transfers storage handles through ancillary Unix-socket data and caches descriptors while storages remain live. Its documentation warns that many shared tensors can exceed low file limits. At5M rows, the default5000-row multiprocessing chunks can create about1000 output tensor storages per call, already close to a1024 soft limit before queue/model descriptors. This is a strong FD-pressure explanation supported by the failed low-limit and successful high-limit run, not a recorded EMFILE syscall or measured1024-FD peak.

Primary reference: https://docs.pytorch.org/docs/2.15/multiprocessing.html#file-descriptor-file-descriptor

Future operating guidance: check actual soft and hard nofile limits and available /dev/shm before a large CPU-pool run. The full5M×1024 float32 output is20.48GB. A small correctness rehearsal does not exercise the descriptor count of the full output. Do not silently switch sharing strategy or output semantics; document any environment correction. Keep failed attempts and their logs.

The earlier single-process ST16 attempt is a separate failure. It used sixteen Torch threads with default32-row batches and was manually killed after roughly24minutes. No saved stack identifies its exact stalled phase. That result provides no speed claim and is not the ancdata failure.
