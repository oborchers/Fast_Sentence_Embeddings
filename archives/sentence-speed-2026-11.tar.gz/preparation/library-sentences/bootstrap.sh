set -euo pipefail
umask 077
mkdir -p /speed-logs
exec > >(tee -a /speed-logs/bootstrap.log) 2>&1
finish() {
  export SPEED_EXIT_STATUS="$?"
  set +e
  trap - EXIT
  /usr/local/bin/python - <<'FAILURE_RECORD'
import hashlib,json,os,pathlib,time
p=pathlib.Path('/speed-results')
if not (p/'DONE').exists():
    p.mkdir(parents=True,exist_ok=True)
    status=int(os.environ['SPEED_EXIT_STATUS']) or 1
    def write(name,value):
        q=p/(name+'.pending')
        with q.open('w') as f:
            json.dump(value,f);f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(q,p/name)
    (p/'cells.jsonl').touch(exist_ok=True)
    rows=sum(1 for _ in (p/'cells.jsonl').open())
    write('progress.json',dict(stage='terminal-failure',cell='FAILED',finished=rows,planned=8,exit_status=status))
    files=[dict(path=str(f.relative_to(p)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(p.rglob('*')) if f.is_file() and f.name not in ('DONE','manifest.json')]
    write('manifest.json',dict(files=files))
    write('DONE',dict(exit_status=status,completed_at=time.time(),cells=rows,manifest_sha256=hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest(),terminal_supervisor=True))
FAILURE_RECORD
  sleep infinity
}
trap finish EXIT
mkdir -p /speed-state
first_run=1
if ! (set -o noclobber; printf '%s\n' '7f2fe04a8f27d881cfcd1e38269066bce25ec8d6' > /speed-state/started); then
  first_run=0
fi
if ! test -x /usr/sbin/sshd; then
  /usr/bin/apt-get update
  /usr/bin/apt-get install -y openssh-server git
fi
mkdir -p /run/sshd /root/.ssh
chmod 700 /root/.ssh
if test "${SPEED_REHEARSAL:-0}" = 1 && test -z "${PUBLIC_KEY:-}"; then
  PUBLIC_KEY="$(cat /etc/ssh/ssh_host_ed25519_key.pub)"
fi
: "${PUBLIC_KEY:?SSH public key required}"
printf '%s\n' "$PUBLIC_KEY" > /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
/usr/sbin/sshd
if test "$first_run" = 0 || test -e /speed-source || test -e /speed-env || test -e /speed-work || test -e /speed-results; then
  printf 'RESTART_DETECTED: SSH only; setup and measurement will not restart.\n'
  exit 77
fi
: "${SPEED_ALLOCATED_AT:?Set the actual allocation Unix timestamp}"
export PYTHONUNBUFFERED=1
export UV_CACHE_DIR=/speed-cache/uv
export HF_HOME=/speed-cache/huggingface
export HF_DATASETS_CACHE=/speed-cache/datasets
export RUSTUP_HOME=/root/.rustup
export CARGO_HOME=/root/.cargo
export LC_ALL=C.UTF-8
/usr/bin/git clone --single-branch --branch dr151-compare https://github.com/oborchers/Fast_Sentence_Embeddings.git /speed-source
/usr/bin/git -C /speed-source checkout --detach 7f2fe04a8f27d881cfcd1e38269066bce25ec8d6
export SPEED_SETUP_STARTED_AT="$(/usr/local/bin/python -c 'import time; print(time.time())')"
printf 'allocation=%s setup_started=%s\n' "$SPEED_ALLOCATED_AT" "$SPEED_SETUP_STARTED_AT"
/usr/local/bin/python /speed-source/benchmarks/speed-run-2026-11.py --setup /speed-env --allocated-at "$SPEED_ALLOCATED_AT"
mode=--run
if test "${SPEED_REHEARSAL:-0}" = 1; then mode=--rehearse; fi
/speed-env/main/bin/python /speed-source/benchmarks/speed-run-2026-11.py "$mode" --results /speed-results --work /speed-work --reference-python /speed-env/reference/bin/python --allocated-at "$SPEED_ALLOCATED_AT" &
measurement_pid=$!
printf '%s\n' "$measurement_pid" > /speed-logs/measurement.pid
wait "$measurement_pid"
