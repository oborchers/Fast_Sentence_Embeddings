# Übergabe des Satzvergleichs

**Satzvergleich bereit zur Übergabe an fse-main. Start nur durch fse-main.**

Source-Pin: `7f2fe04a8f27d881cfcd1e38269066bce25ec8d6`.
Bootstrap: `/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/library-sentences/bootstrap.sh`.
Bootstrap-SHA256: `f3509ab300cb0fff230892eb76dfb22e3f6d36b24856fe80137c37901d255ada`.

Keine bezahlte Aktion durch DR-151. Start, Sicherung und Löschung liegen bei fse-main. Kein Merge.

## Start

Image: `python:3.13@sha256:f23cf6c01ace0da9aa4d04fd078dba0fcce0c23cf3320329a38a2b6890761f9c`.
cpu5g, EUR-IS-1, 32 vCPU, 128 GB RAM, 150 GB Datenträger. CPU-Modell beim Start lesen, cpu5g garantiert keinen 9965. `startSsh=true`, Ports `["22/tcp"]`. Entrypoint `/bin/bash`, Argument der unveränderte Inhalt von bootstrap.sh.

Environment: `SPEED_ALLOCATED_AT=<tatsächlicher Unix-Zeitpunkt der Maschinenzuteilung>`, `SPEED_ALLOCATION_ID=<Maschinen-ID>`. PUBLIC_KEY wird vom Anbieter injiziert. SPEED_REHEARSAL nicht setzen.

Das Bootstrap startet SSH, klont den Source-Pin, installiert die beiden gelockten Umgebungen und führt aus:

```bash
/speed-env/main/bin/python /speed-source/benchmarks/speed-run-2026-11.py --run --results /speed-results --work /speed-work --reference-python /speed-env/reference/bin/python --allocated-at "$SPEED_ALLOCATED_AT"
```

## Sicherung

Alle zwei Minuten `/speed-results/cells.jsonl`, `/speed-results/progress.json`, `/speed-results/DONE` abholen. Nach DONE sofort das komplette `/speed-results` mit `manifest.json`, außerdem `/speed-logs/bootstrap.log` und `/speed-env/setup.json` sichern und anhand SHA256 prüfen. Danach Maschine löschen. Große Rohbelege sind die JSON-Aufrufe und Stichproben-Prüfbelege unter `/speed-results`; vollständige Vektormatrizen und Modelle werden nicht gesichert.

Controller-PID: `/speed-logs/measurement.pid`. SIGTERM beendet das laufende Paar vollständig und startet danach keines mehr. Es entstehen acht terminale Zellzeilen, progress.json, manifest.json und DONE. Geld und Zeit begrenzen die Zulassung, sie schneiden kein aktives Paar ab. Ein hängendes Paar kann daher die Schätzung überschreiten. Bootstrap bleibt nach Ende oder Fehler in sleep infinity, Neustart startet keine zweite Messung.

## Eingabe und Speicher

WikiText-103 train, Revision b08601e04326c79dfdd32d625aee71d232d685c3. 832318 normalisierte Absätze, daraus 3863020 Satzstücke per `(?<=[.!?])\s+`, mindestens fünf Wörter. Quelle im Mittel 25.57375654 Wörter, Median24. Satzkorpus-SHA256 e52df0a9a5b34fd9dad7b70e911603e6c603d6a83642f7fd1c99708df01ad198. Seed0, PCG64, Ziehen mit Zurücklegen und anschließendes Mischen. Gleiche Eingabe und Kürzung innerhalb jedes Paares. Jede Ergebniszeile enthält input_identity mit Mittelwert Wörtern/Zeichen, Anzahl, Digest und beiden Distinkt-Zahlen. repetition_factor bezeichnet Gesamtzahl geteilt durch verschiedene Quelltexte; die tatsächlichen verschiedenen Eingabetexte stehen separat in distinct_input_texts.

Die acht ursprünglichen ST-UNK-Absätze bleiben unverändert als ausdrücklich protokollierte Ausnahme am Anfang der Eingabe und in der 10000-Zeilen-Stichprobe. Natives ST behält UNK; Toleranz rtol3e-5, atol3e-6. Keine A/A-Doppelarme. Drei abwechselnde Runden, je ein Aufwärmen und ein gemessener Warmaufruf. Jeder fse-Aufruf mindestens2s, sonst ungültiges Paar. Keine Zielrate als Gültigkeitskriterium.

| Bibliothek | Worker | Texte | Eingabebytes | Peak GB |
|---|---:|---:|---:|---:|
| model2vec | 1 | 2000000 | 272590827 | 14.352046 |
| rust | 1 | 2000000 | 272590827 | 14.352046 |
| fastembed | 1 | 2000000 | 272590827 | 14.352046 |
| st | 1 | 2000000 | 272595911 | 26.921832 |
| model2vec | 16 | 18000000 | 2455180892 | 60.651595 |
| rust | 16 | 18000000 | 2455180892 | 60.651595 |
| fastembed | 16 | 18000000 | 2455180892 | 60.651595 |
| st | 16 | 5000000 | 681709559 | 56.648002 |

Zulassung unter85% von min(128GB, wirklichem cgroup-Limit), maximal108.8GB. Zweite Matrix deckt reale Konkatenation ab (Model2Vec np.concatenate, FastEmbed np.stack, ST torch.stack). Warmup-Ergebnis wird vorher gelöscht und gc.collect() läuft außerhalb der Messung. Seiten laufen in getrennten Prozessen, nur10000 Ergebniszeilen werden geprüft. Speicherkomponenten vollständig in exact-input-memory-128gb.json und während des Laufs in preflight-memory.json.

## Zeit und Kosten

| Stufe/Paar | Minuten | Erwartetes Ende ab Zuteilung |
|---|---:|---:|
| Einrichtung | 8 | 8 min |
| Ruhebeobachtung | 3 | 11 min |
| libraries-model2vec-1 | 13 | 24 min |
| libraries-rust-1 | 2 | 26 min |
| libraries-fastembed-1 | 14 | 40 min |
| libraries-st-1 | 17 | 57 min |
| libraries-model2vec-16 | 10 | 67 min |
| libraries-rust-16 | 6 | 73 min |
| libraries-fastembed-16 | 18 | 91 min |
| libraries-st-16 | 10 | 101 min |
| Sicherung | 3 | 104 min |

Compute1.472USD/h, Datenträger150×0.10/720USD/h. Zusammen1.492833333USD/h. Erwartung104min = 2.587578USD. Nomineller Horizont140min einschließlich10min Sammelreserve. Geldgrenze3.48USD ergibt effektiv 139.868259min. Die Zeit ist aus früheren Absatzraten nach Wortmenge übertragen, keine gemessene Garantie für Sätze. Feste Kosten je Text und geteilte Hardware können verlängern. Keine automatische Wiederholung.

## Datei-Hashes

| Datei | Bytes | SHA256 |
|---|---:|---|
| benchmarks/speed-run-2026-11.py | 18424 | c7706e5395e99104ae5c2d270ce9cec77656a16a350f01a86fc8b0faa025dc8c |
| benchmarks/_speed_cells.py | 10777 | 89dd9c3d88b1322f7ee0e3b793708615ce5162210afc9fff9af718ca2f8da17e |
| benchmarks/_speed_pipeline.py | 12073 | 60c59a72071a51600d7557e692def19113bf4244960c86bdca969529045dd8f1 |
| benchmarks/speed-input-2026-11.json | 7458 | 822a0f48160c01213875fa6b8082d092af504ec8922a6a0c8c73045e45e1f28a |
| benchmarks/speed-main.lock.txt | 173667 | e7db4ba8b6afdf36d9eb0cd41499cb10ff01d3a4a3bacbd7a413d3e2c964f875 |
| benchmarks/speed-reference.lock.txt | 98420 | 218d9855038b4ef6f3253c04c1f031350f4c52135fe16cbff35bf625e348f73d |
| benchmarks/speed-rust.lock | 26727 | b64150bf3e47180247cf6d220848c4ac1191dfc6dfc6b62ac86cc178dbaebe0f |

## Prüfung

Endgültige Linux-amd64-Generalprobe auf genau diesem Pin bestanden: alle8 realen Paare, je12000 Sätze und10000 geprüfte Zeilen pro Runde. Lokale Produktionsfälle mit16 Workern wurden innerhalb der vorgeschriebenen zwei CPUs und vier GiB mit zwei Workern geprüft. Alle8 Produktions-Bytezahlen wurden zusätzlich unabhängig im gepinnten Linux aus dem vollständigen Satzkorpus rekonstruiert, ohne Millionen-Eingabedateien oder große Ausgabematrizen lokal zu schreiben. Die ursprünglichen acht ST-UNK-Absätze sind enthalten und die unveränderten Toleranzen bestanden.

Belege: `rehearsal-final-proof.json`, `collected-final/library-sentence-final-proof/report.json`, `collected-final/speed-results-sentences-final/`. Letzteres enthält108 gegen SHA256 geprüfte Manifestmitglieder. Manifest-SHA256345d83ef2ada877d02ae64990c2ef04e9ee8c05c99b1c7451eab26cca4eb629d. Die Ergebnisse sind ausschließlich Funktionsnachweise, niemals veröffentlichbare Tempozahlen.

Steuerungsproben: normaler Abschluss mit8 gestarteten Paaren, SIGTERM mit1 gestartetem und7 not_started, Geldende mit0 gestarteten und8 not_started. Alle schreiben vollständige Abschlussdateien. Der bestehende Linux-Container wurde neu gestartet, die ursprüngliche DONE blieb unverändert. Der neue Bootstrap ist bis auf den Source-Pin bytegleich zum bereits ausgeführten Bootstrap. `bootstrap-restart-equivalence.json` dokumentiert diese Zuordnung.

Genau ein unabhängiges Codex-Review mit gpt-6-astra und high auf diesem Pin, Exit0. Eine Warnung zur JSON-Maskierung wurde geprüft und mit Git-Inhalt, json.loads, AST-Konstante und Beispiel widerlegt. Der gespeicherte und der ausgeführte Regex sind exakt gleich und enthalten einen Backslash. Kein korrigierender Source-Commit nötig, kein zweites Review. Belege `review.last.md`, `review-response.md`, `regex-review-proof.json`, `review-start-proof.json`.

`make check PYTEST_N=4` auf diesem Pin bestanden:8973 bestanden,514 übersprungen,218.08Sekunden. Belege `final-make-check.json` und `final-make-check.log`. Ruff und Guardrails bestanden. Keine Benchmark-Tests hinzugefügt. Alle7 Quell-/Lockdateien aus dem veröffentlichten GitHub-Pin bytegleich nachgeprüft, siehe `published-source-proof.json`.

Eigene Linux-Container und Docker Desktop sind gestoppt. Der nach Review nicht mehr benötigte eigene Checkout wurde geprüft und entfernt,8839986 logische Bytes. Ergebnisse und Berichte bleiben erhalten. Keine geteilten Caches gelöscht, keine bezahlte Aktion und kein Merge.

Remote CI auf demselben Pin: CI41417536342 und Integrations41417536090 vollständig erfolgreich. Kein Merge.
