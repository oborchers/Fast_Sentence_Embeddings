# ST-16 bereit zur Übergabe

Source-Pin: 6c9fc1a5fd5f42d4b1af0e0756ef9123d493aad9.
Start nur durch fse-main: /bin/bash /Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/st16/start-after-DONE.sh
Startskript-SHA256: f52b4585adf8aa7741d1d915b58c5e8b8f46364101f9904930b06748585243d0
Runner-SHA256: a78284b79cfa75d191519c1b41b586503597b68b37f083f2c6ce1aedb6399056
Vertrag-SHA256: b54b91885a60aa36045c9b399d59df62da6ff3e272a89f2f7ef624cda8211ed1

Kein bezahlter Start durch mich. Kein Review, wie Oliver zuletzt entschieden hat. Nur _speed_pipeline.py geändert. Alle sieben gepushten Dateien auf GitHub bytegleich bestätigt, vollständige Hashes in handoff-hashes.json.

## Messung

Ein Paar ST gegen unveränderten fse-Arm,5M identische WikiText-Sätze, native1024 Dimensionen, float32 vollständig, Normalisierung an, dieselben10000 Stichproben und acht UNK-Absätze. Drei alternierende Runden, Aufwärmen und Messung pro Arm. Erwarteter Input-SHA256 wie im Satzlauf:64bd628b0b456c9a8529a4b358232a3caa3e77e18150f02b9587a3559bcfbce0,681709559Bytes. Nach Sammlung explizit vergleichen. Die2-Sekunden-Grenze bleibt unverändert.

ST startet genau16 CPU-Prozesse über start_multi_process_pool und verwendet denselben Pool beim Aufwärmen und Messen. Batch1024, ein begründeter Startpunkt statt eines behaupteten Optimums. Bei chunksize5000 ungefähr5000 statt156250 kleine Batches pro Durchlauf. OMP/MKL/OPENBLAS/RAYON vor den Imports auf1, Tokenizerparallelität false. Spawn-Worker setzen Torch intra- und interop explizit auf1. Affinität bleibt insgesamt16 erlaubte CPUs. Pool wird im finally gestoppt, auch bei Fehlern. Fse-Timing, Eingabe und Vergleichstoleranz bleiben unverändert. RSS der ST-Receipt ist nur die Elternprozess-Hochwassermarke, keine Summe des Prozessbaums.

## Funktion

Kleine Linux-amd64-Probe im gleichen gepinnten Image,2CPU/4GiB,2 echte Poolprozesse.12000 Texte,10000 Vergleichszeilen einschließlich8UNK, maximaler Absolutfehler2.9802322387695312e-08, rtol3e-5/atol3e-6 unverändert. Derselbe Pool wurde für beide Aufrufe verwendet. PIDs42/44 nachher beendet. report.json untercollected enthält die Nachweise. Lokaler resource_tracker warnte beim Interpreterende vor2 Semaphoreobjekten; keine lebenden Poolprozesse. Warnung nicht unterdrückt, probe.log behalten. Probe Exit0. Ruff/Format/Guardrails bestanden. Kein volles make check oder neues Review gemäß dringendem eingeschränkten Auftrag.

Lokale Standard-/dev/shm64MiB reichen nicht für das125MB-Modell, daher Probe in1GiBshm. Live-Maschine nur lesend geprüft:64GBshm frei. Start prüft mindestens24GiBshm und5GiB freien Datenträger.

## Start und Budget

Das Startskript prüft alte DONE-Dateien und frische Zielordner, extrahiert nur den gepinnten Code nach/st16-source und prüft alle SHA256. /speed-env und Modelle/Korpus in/speed-work bleiben in Gebrauch. Neue Ergebnisse/st16-results, neue Arbeitsdaten/st16-work, Logs/st16-logs/run.log, Supervisor-PID/st16-logs/measurement.pid. Es wird keine bestehende Quelldatei oder Modellablage überschrieben.

Der gemeinsame Runner baut derzeit auch bei einem reinen ST-Paar die gelockte Rust-Brücke. Das bleibt außerhalb jeder Messung, nutzt vorhandene Cargo-Quellen mit16 Buildjobs und schreibt ausschließlich ein neues Target unter/st16-work. Keine Überschreibung der alten Rust-Binärdatei. Für diese kurze Folgephase nur1Sekunde Ruhebeobachtung auf dem gleichen ST-Modell, kein weiterer3-Minuten-Block.

Budget0.35USD,14Minuten einschließlich2Minuten Sammlung. Bei1.492833333USD/h kosten14Minuten0.348328USD. Zusätzlich harte Prozessgruppenbegrenzung: insgesamt höchstens12Minuten ab SSH-Budgetbeginn, TERM mit10Sekunden KILL-Nachlauf darin enthalten. Fetch45s und Archive20s ebenfalls begrenzt. Ein fehlendes DONE wird vom Supervisor als failed samt Manifest erzeugt. Der Fallback ist funktional geprüft (Exit124, eine failed-Zeile, konsistenter Manifest-SHA256). Erwartung für den korrigierten Pool grob4bis8Minuten, nicht als gemessene Garantie. Operativer Höchstwert hat Vorrang.

Start wird abgelehnt, wenn14Minuten bis11:58UTC nicht mehr verbleiben. Absolute Löschung spätestens11:58UTC bleibt ausschließlich bei fse-main. Falls Pool/IPC langsamer laufen, endet die Messung durch den Timeout, keine automatische Wiederholung.

## Sammlung

Alle2Minuten/st16-results/cells.jsonl,progress.json,DONE lesen. Bei DONE gesamtes/st16-results samtmanifest.json und/st16-logs sichern und SHA256 prüfen. Nicht Modelle, Caches oder ganze Matrixdateien kopieren. Bei failed oder invalid keine Tempozahl veröffentlichen. Übernommener Original-Maschinenzeitpunkt wird aus dem altenenvironment.json gelesen, die0.35USD gelten inkrementell ab dieser Folgephase. Kein Merge.
