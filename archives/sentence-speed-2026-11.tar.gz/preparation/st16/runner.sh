#!/bin/bash
set -uo pipefail
seconds="$(/speed-env/main/bin/python -c 'import os,time;remaining=int(720-(time.time()-float(os.environ["ST16_BUDGET_STARTED_AT"]))-10);assert remaining>0;print(remaining)')"
/usr/bin/timeout --signal=TERM --kill-after=10s "${seconds}s" /speed-env/main/bin/python /st16-source/benchmarks/speed-run-2026-11.py --run --input /st16-source/input.json --reuse-work /speed-work --results /st16-results --work /st16-work --allocated-at "$ST16_BUDGET_STARTED_AT"
status=$?
export ST16_EXIT_STATUS="$status"
/speed-env/main/bin/python - <<'FALLBACK'
import hashlib,json,os,pathlib,time
root=pathlib.Path('/st16-results')
if not (root/'DONE').exists():
 root.mkdir(exist_ok=True)
 def atomic(name,value):
  p=root/(name+'.pending')
  with p.open('w') as f:json.dump(value,f);f.write('\n');f.flush();os.fsync(f.fileno())
  os.replace(p,root/name)
 status=int(os.environ['ST16_EXIT_STATUS']) or 1
 with (root/'cells.jsonl').open('a') as f:json.dump(dict(cell_id='libraries-st-16',status='failed',reason='supervisor terminated before normal DONE',exit_status=status),f);f.write('\n');f.flush();os.fsync(f.fileno())
 atomic('progress.json',dict(stage='collection',cell='DONE',finished=1,planned=1,exit_status=status))
 files=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file() and p.name not in ('DONE','manifest.json')]
 atomic('manifest.json',dict(files=files))
 atomic('DONE',dict(exit_status=status,cells=1,completed_at=time.time(),manifest_sha256=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),supervisor=True))
FALLBACK
exit "$status"
