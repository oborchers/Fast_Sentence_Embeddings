# Antwort auf das einzelne Review

Reviewmodell gpt-6.1-sol, Reasoning high. Geprüfter Stand f80cb2f5f5161592ad120774cf1f85eb1ff5205d gegen7f2fe04a8f27d881cfcd1e38269066bce25ec8d6. Exit0,195.25Sekunden. Genau ein Review, kein zweiter Auftrag.

Alle vier Befunde sind bestätigt und im Stand b2e960f923c67cf0ed1fd4fcfc517836a333a06e behoben:

1. Gespeicherte int8-Codes und float32-Skalen werden getrennt über ihre Byteansichten gegen reference.codes und reference.scales verglichen. Keine Gleichsetzung lediglich dequantisierter Werte. Die Linux-Probe mit beiden Startparametern hat jeweils30000 feste Stichprobenprüfungen bestanden.
2. Paketidentität wird vor und nach jeder Ausführung verglichen, zusätzlich zwischen den Runden. Unterschiedliche Identitäten führen zu failed.
3. Nach dem Erzeugen des Work-Verzeichnisses wird dessen Elternverzeichnis synchronisiert. Nach dem Erzeugen jedes Rundenordners wird Work synchronisiert. Dateien, Store-Unterverzeichnisse, Store und Rundenordner werden vor dem Dauerhaft-Zeitpunkt synchronisiert. Nach Löschung wird das Elternverzeichnis synchronisiert.
4. Begonnene Runden werden in headline_rounds gesammelt. Fehler führen zu failed mit konkreter Ursache und tatsächlicher Anzahl abgeschlossener Messungen. Injizierter Fehler vor Runde2: eine vollständig gemessene und geprüfte Runde, failed, DONE Exit1. SIGTERM nach Runde1: partial, DONE Exit1. Normal: drei Runden, valid, DONE Exit0.

Belege: rehearsal-reviewed-proof.json und collected-reviewed/headline-reviewed-evidence. Die Sammlerhülle hatte nach erfolgreich abgeschlossener Linux-Ausführung einen veralteten lokalen Verzeichnisnamen erwartet. Die vollständige Kopie lag bereits vor. Alle Manifestmitglieder wurden unter dem tatsächlichen Namen unabhängig auf Größe und SHA256 geprüft. Dieser Sammlerfehler betrifft keine Mess- oder Steuerungsfunktion.

Keine weiteren bestätigten Befunde offen. Keine Benchmark-Tests ins Repository aufgenommen. Alle drei Skriptdateien bleiben unter500Zeilen. Kein Start einer bezahlten Aktion, kein Merge.
