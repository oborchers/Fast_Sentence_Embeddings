# Übergabe: 100-Millionen-Schreibmessung

**100M-Übergabe bereit. Start erst nach DONE des Satzlaufs und Olivers ausdrücklicher Freigabe durch fse-main.**

Source-Pin: `b2e960f923c67cf0ed1fd4fcfc517836a333a06e`.
Geprüfter Startbefehl nach Olivers Freigabe: `/bin/bash /Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/start-after-DONE.sh 16` oder derselbe Befehl mit `32`.
Startskript-SHA256: `3b32b25d3f83318e865c9a98299d821245b123bde10886758403aaa27c602825`.

Der Start bleibt ausdrücklich fse-main vorbehalten. Das Skript wurde hier nur vorbereitet, niemals ausgeführt. Es verweigert den Start ohne `/speed-results/DONE` und bei bestehenden Zielordnern. Es holt den neuen Pin als Git-Objekt, extrahiert nur die sieben Dateien in `/headline-source` und prüft jeden SHA256 vor dem Start. Der bestehende `/speed-source`-Checkout bleibt auf7f2fe04. Vorhandene `/speed-env` sowie gepinnte Modelle und Parquet-Daten unter `/speed-work` werden wiederverwendet. Kein Bootstrap und keine Neuinstallation auf der vorhandenen Maschine.

## Ergebnisdateien und Steuerung

Alle zwei Minuten `/headline-results/cells.jsonl`, `/headline-results/progress.json`, `/headline-results/DONE` sichern. Nach DONE das komplette `/headline-results` mit `manifest.json` sowie `/headline-logs/run.log` und `/headline-logs/measurement.pid` sammeln, SHA256 prüfen und Lebenszyklus beenden. Keine Gewichte, Caches, Eingabedateien oder Vektorausgaben kopieren. Große Ausgaben werden nach verifiziertem Sync und Checks gelöscht, keine großen Roharchive sind vorgesehen.

SIGTERM an die PID aus `/headline-logs/measurement.pid`: die laufende Runde beendet Encode, Sync und Prüfung, danach startet keine weitere. Der Bericht ist partial, DONE Exit1. Ein echter Fehler nach begonnenen Runden ist failed, mit Fehlerursache und bereits abgeschlossenen Runden. Alle erfolgreichen Runden werden fortlaufend in operations.jsonl und cleanup.jsonl gesichert. Ein Abbruch mitten in einer Runde kann zur Diagnose eine unverifizierte Ausgabe unter `/headline-work/headline-100m-<runde>-fse/sample` zurücklassen; sie wird nicht automatisch gelöscht oder als gültig gewertet.

## Definition

Ein wiederholbares Datenfeld neben acht Bibliothekspaaren, derselbe Einstieg mit `--study headline`, Worker16 oder32 verpflichtend als Parameter. Bei16 begrenzt configure die tatsächliche Affinität des Mess-Kindes auf16 erlaubte CPUs. Das Journal zeichnet die tatsächliche Affinität auf. Alle Dateien bleiben unter500 Zeilen, keine vierte Skriptdatei, keine Benchmark-Tests im Repository.

POTION-8M bf8b056651a2c21b8d2565580b8569da283cab23. Float32-Modelltabelle, normalisierter Encoder, ShardSink-Ausgabe int8, durability none. Das entspricht dem alten Beleg hinsichtlich Tabelle und Ausgabe. Der installierte fse-Code bleibt624251df2269e3099f5c61987be63e718893b58c, eigener Paketpfad/Version/Inhaltshash vor/nach jeder Runde und zwischen den Runden geprüft.

Gepinnter WikiText-103-Satzkorpus mit3863020 Quellpositionen, mindestens fünf Wörter.100M Texte mit Zurücklegen gezogen und mit PCG64 Seed0 gemischt. Die reale große Datei wird einmal erzeugt und von fse nativ als Pfad gestreamt. Kein Python-Array mit100M Texten beim Encode. Dieselbe Datei für alle drei Runden. Input-SHA256, Bytezahl, verschiedene Texte, Wiederholungsfaktor sowie mittlere Wörter/Zeichen/Token stehen im Ergebnis.

Drei Runden, Median und Bereich. Primärzeit vom ersten Lesen bis Sink-Close, wie beim alten Beleg. Sink-Eröffnung wird zusätzlich gemeldet. Das externe fsync aller Dateien und relevanten Verzeichnisse erfolgt danach, mit eigenem Zeitpunkt bis dauerhaft. Hash-Prüfung und Stichprobe sind außerhalb der primären Messung. Vollständige Zeilenzahl, gespeicherte Shard-Prüfsummen, SHA256-Dateiinventar,10000 feste Stichprobenzeilen. Int8-Codes und float32-Skalen werden getrennt bitgenau gegen `encoder.encode(sample_texts,dtype="int8")` geprüft. Danach Ausgabe löschen und deren Elternverzeichnis fsync, erst danach nächste Runde. Last, Speicher, Dirty/Writeback, Prozess-/cgroup-I/O und df sind protokolliert.

Abweichungen zum alten EPYC-7713-Beleg: neue tatsächliche Maschine und neuer fse-Pin, drei Runden ohne A/A-Doppelarm, zufällige Ziehung mit Zurücklegen statt ausgeglichenem Wiederholen der Quellpositionen, Stichprobe statt vollständiger dequantisierter Vektorenprüfung. Tokenangabe zählt begrenzte Tokenizer-IDs einschließlich UNK, der alte Beleg schloss UNK aus. Keine direkte kausale CPU-Speedup-Aussage aus unterschiedlichen Input-Digests. Der Satzvergleich und die alte Kopfzeile bleiben getrennte Kohorten.

## Budget und Platz

Keine neue Maschine. CPU5g32vCPU,128GB,150GB vorhandener Datenträger.100M Input ungefähr13.6GB, int8-Ausgabe einschließlich Skalen/Normen ungefähr26.4GB. Nur eine Ausgabe gleichzeitig, freier Platz wird vorher konservativ geprüft, einschließlich20% Inputpuffer und5GiB Reserve. Streaming-Speichervorprüfung20GiB gegen85% der echten cgroup-Grenze, kein100M-Vektorarray im RAM. Peak-RSS bezeichnet Kindprozess-Hochwassermarke vor Verifikation, nicht den vollständigen Prozessbaum.

Planungswert:25Minuten und0.60USD, Sammlung120Sekunden. Mit1.472USD/h Compute plus150×0.10/720USD/h Datenträger =1.492833333USD/h ergibt die Geldgrenze24.12Minuten. Der monetäre Wert hat Vorrang. Erwartung grob15bis22Minuten einschließlich Vorbereitung, Sync und Prüfung =0.373bis0.547USD. Keine Garantie für geteilte Datenträger. Einzelne zugelassene Runden werden nicht hart abgeschnitten; bei einem Hänger entscheidet Oliver mit fse-main.

Der inkrementelle Budgetbeginn wird direkt nach DONE-Prüfung vor Fetch und Extraktion gesetzt. Die tatsächliche ursprüngliche Maschinenallokation wird separat aus dem alten environment.json übernommen. Alle100000 erzeugten Inputzeilen wird Budget/Stop geprüft. Der aktuelle Satzlauf wird nicht erneut diesem0.60USD-Budget zugerechnet.

Später auf anderer Maschine: derselbe gepinnte Einstieg und dieselben gelockten Pakete, mit vorhandenem Bootstrap-Muster zuerst `--setup /speed-env`, dann `--run --study headline --workers16` beziehungsweise32 und frischen Ergebnis-/Work-Verzeichnissen. Ohne `--reuse-work` werden die gepinnten Modelle und Korpusdaten vorbereitet. Preis und Maschinenwerte müssen im Vertrag zur neuen Maschine passen. Neuinstallation/Bootstrap sind zusätzliche Kosten außerhalb dieser Schätzung für die bereits eingerichtete Maschine.

## Prüfnachweise

Genau ein GPT-6.1-Sol/high-Review. Vier bestätigte Befunde korrigiert, kein zweites Review. Abschließende Linux-Probe auf korrigiertem Pin mit16 und32 als Startparameter, jeweils1M Texte und drei Runden, tatsächliche lokale Begrenzung auf zwei CPUs/vier GiB. Alle10000 Stichproben-Codes/Skalen bitgenau. SIGTERM nach Runde1 ergibt partial/Exit1, injizierter Fehler in Runde2 ergibt failed/Exit1 und exakt eine abgeschlossene Runde. Manifest-Dateien unabhängig lokal verifiziert. Ein veralteter Sammler-Verzeichnisname verursachte nach erfolgreicher Linux-Ausführung einen lokalen Sammlerfehler; die vollständig kopierten Daten wurden unter dem korrekten Pfad geprüft, nichts ging verloren.

Belege: `rehearsal-reviewed-proof.json`, `collected-reviewed/headline-reviewed-evidence/`, `review.last.md`, `review-response.md`. `make check PYTEST_N=4` auf genau diesem Pin bestanden:8973 bestanden,514 übersprungen,207.99Sekunden. Nachweis `reviewed-make-check.json` und `reviewed-make-check.log`. Alle7 veröffentlichten Dateien auf GitHub bytegleich geprüft, siehe `published-source-proof.json`. Keine Benchmark-Tests hinzugefügt.

## Datei-Hashes

| Datei | Bytes | SHA256 |
|---|---:|---|
| benchmarks/speed-run-2026-11.py | 18395 | 8d7c2e0938b03aa1e0fc8c3bf178f2a2604aaa1f3ec9dde44216249d69e2a2a4 |
| benchmarks/_speed_cells.py | 17715 | e5dc7e2df696c1e943ab083aa5782267029d9437d5a842ec30b6f6856b1c3d07 |
| benchmarks/_speed_pipeline.py | 17592 | 3f879dfdef14c67db7e544a464faaf5e9b3c9b45427a0c01520e40f79dd10514 |
| benchmarks/speed-input-2026-11.json | 7951 | ac44c4deaa2c3bb8107f5eb60653d5b587c1d156fdf342e54fff34776d4c425e |
| benchmarks/speed-main.lock.txt | 173667 | e7db4ba8b6afdf36d9eb0cd41499cb10ff01d3a4a3bacbd7a413d3e2c964f875 |
| benchmarks/speed-reference.lock.txt | 98420 | 218d9855038b4ef6f3253c04c1f031350f4c52135fe16cbff35bf625e348f73d |
| benchmarks/speed-rust.lock | 26727 | b64150bf3e47180247cf6d220848c4ac1191dfc6dfc6b62ac86cc178dbaebe0f |

Eigene Linux-Container und Docker Desktop gestoppt, lokaler Heavy-Slot freigegeben. Kein Start einer bezahlten Aktion und kein Merge.
