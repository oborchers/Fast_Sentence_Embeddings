Vier Befunde: drei Fehler und eine Warnung. Keine Blocker.

**1. Korrektheit und Reproduzierbarkeit**

**Fehler: Die Stichprobe prüft dequantisierte Werte statt der exakten int8-Darstellung.**  
Fundstelle: [benchmarks/_speed_pipeline.py:384](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/_speed_pipeline.py:384)

Beleg: `reference.codes.astype(np.float32) * reference.scales[:, None]` wird mit `store.get_vectors(...)` verglichen. `get_vectors()` liefert ebenfalls dequantisierte float32-Werte.

Folge: `sample_bitwise_equal=True` belegt keine bitgleiche Übereinstimmung der gespeicherten Codes und Skalen. Beispielsweise können unterschiedliche Codes bei einer Nullskala dieselben Werte ergeben. Interne Prüfsummen schließen eine vom Sink falsch erzeugte Darstellung nicht aus.

Konkrete Korrektur: Für die 10.000 festen Zeilen gespeicherte int8-Codes und float32-Skalen jeweils bitweise mit `reference.codes` und `reference.scales` vergleichen.

**Warnung: Unterschiedliche Codeidentitäten zwischen Runden verhindern kein gültiges Gesamtergebnis.**  
Fundstellen: [benchmarks/_speed_pipeline.py:409](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/_speed_pipeline.py:409), [benchmarks/speed-run-2026-11.py:422](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/speed-run-2026-11.py:422)

Beleg: `package_identity("fse")` wird erst nach der Messung erfasst. `complete` prüft ausschließlich `len(rows) == cell["rounds"]`. Der Bibliotheksvergleich prüft dagegen Identität vor und nach der Ausführung sowie zwischen den Runden.

Folge: Ändert sich die Installation während des Laufs, kann ein Median verschiedener Codeversionen als `valid` erscheinen.

Konkrete Korrektur: Die vorhandene Identitätsprüfung auch im Headline-Pfad anwenden und abweichende Rundenidentitäten zurückweisen.

Die Eingabeauswahl und Stichprobe sind deterministisch. `configure()` begrenzt die Kindprozess-Affinität auf die gewählte Workerzahl. Der Tokenzähler zählt begrenzte Tokenizer-IDs einschließlich UNK. Der alte Headline-Zähler schloss UNK aus. Diese unterschiedliche Definition ist kein Zahlenfehler.

**2. Datenträger, Speicher, Synchronisierung und Bereinigung**

**Fehler: Der neue Rundenordner fehlt in der Synchronisierung seiner Verzeichnisverknüpfung.**  
Fundstellen: [benchmarks/speed-run-2026-11.py:94](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/speed-run-2026-11.py:94), [benchmarks/_speed_pipeline.py:430](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/_speed_pipeline.py:430)

Beleg: `folder.mkdir()` erzeugt `work/headline-100m-<runde>-fse`. `sync_headline()` synchronisiert Dateien, Unterverzeichnisse, den Store und `path.parent`, also diesen Rundenordner. `work` wird anschließend nicht synchronisiert.

Folge: `external_fsync=True` bestätigt keine vollständig dauerhaft erreichbare Ausgabe. Bei einem Absturz kann die Verzeichnisverknüpfung des neuen Rundenordners fehlen.

Konkrete Korrektur: Nach `folder.mkdir()` auch `work` synchronisieren. Beim erstmaligen Erzeugen von `work` dessen Elternverzeichnis ebenfalls synchronisieren.

Ansonsten sind erfolgreiche Runden sequenziell. Die Ausgabe wird vor der nächsten Runde gelöscht und das Elternverzeichnis synchronisiert. Die Bereinigung prüft Eigentumsgrenze, Dateiinventar und Symlinks.

**3. Budget, SIGTERM, Fehlerstatus und Artefakte**

**Fehler: Fehler nach begonnenen Runden werden als „nicht gestartet“ protokolliert.**  
Fundstellen: [benchmarks/speed-run-2026-11.py:410](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/speed-run-2026-11.py:410), [benchmarks/speed-run-2026-11.py:360](/Users/oliverborchers/.herdr/worktrees/Fast_Sentence_Embeddings/dr151-compare/.review/headline/review-tree/benchmarks/speed-run-2026-11.py:360)

Beleg: Fehler aus `launch()` oder `remove_headline()` verlassen `run_headline()` vor `ledger.result()`. Der äußere `finally`-Block schreibt dann `status="not_started"` und `reason="preparation failed"`.

Folge: Scheitert beispielsweise Runde zwei nach erfolgreicher Runde eins, beschreibt der Zellbericht den tatsächlichen Ablauf falsch. Anzahl und Zusammenfassung abgeschlossener Runden fehlen. `DONE.exit_status` wird zwar korrekt `1`.

Konkrete Korrektur: Nach Beginn der Runden bei Fehlern einen Zellbericht mit `status="failed"`, tatsächlicher Fehlerursache und abgeschlossenen Runden schreiben.

Die Budgetformel ergibt rund **24,12 Minuten**, einschließlich der 120 Sekunden Sammelreserve. Sie verwendet den inkrementellen Startzeitpunkt. Die Maschinenallokation wird separat erfasst. Laufende Runden unterliegen keiner harten Kostengrenze. Ein SIGTERM an den Elternprozess verhindert weitere Zulassungen und lässt die laufende Runde abschließen.

**4. Unbeabsichtigte Änderungen am Bibliotheksvergleich**

**Keine Befunde.** Die acht Bibliothekspaare bleiben unverändert. Auswahl, Messablauf und Standardreserve bleiben erhalten. Der extrahierte Ledger verwendet korrekt die Anzahl der ausgewählten Zellen.

Erledigt: Commit-Vergleich und umgebenden Code statisch geprüft. Keine Dateien geändert oder Ressourcen gestartet.  
Offen: Vier Befunde. Rehearsal, SIGTERM und Laufzeitverhalten wurden gemäß Auftrag nicht ausgeführt.  
Benötigt von dir: nichts.