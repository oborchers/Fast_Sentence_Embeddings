#!/bin/bash
set -euo pipefail
workers="${1:?Usage: start-after-DONE.sh 16 or 32}"
case "$workers" in 16|32) ;; *) printf 'workers must be 16 or 32\n' >&2; exit 2 ;; esac
ssh -i /Users/oliverborchers/.ssh/runpod_fse_ed25519 -p 58373 -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes -o UserKnownHostsFile=/Users/oliverborchers/fse-speed-run/known_hosts root@185.226.157.247 /bin/bash -s -- "$workers" <<'REMOTE'
set -euo pipefail
workers="$1"
test -f /speed-results/DONE
test ! -e /headline-source
test ! -e /headline-work
test ! -e /headline-results
HEADLINE_STARTED_AT="$(/speed-env/main/bin/python -c 'import time;print(time.time())')"
mkdir /headline-source /headline-logs
/usr/bin/git -C /speed-source fetch origin b2e960f923c67cf0ed1fd4fcfc517836a333a06e
/usr/bin/git -C /speed-source archive b2e960f923c67cf0ed1fd4fcfc517836a333a06e benchmarks/speed-run-2026-11.py benchmarks/_speed_cells.py benchmarks/_speed_pipeline.py benchmarks/speed-input-2026-11.json benchmarks/speed-main.lock.txt benchmarks/speed-reference.lock.txt benchmarks/speed-rust.lock | /bin/tar -x -C /headline-source
/speed-env/main/bin/python - <<'VERIFY_SOURCE'
import hashlib,json,pathlib
expected=[{'path': 'benchmarks/speed-run-2026-11.py', 'bytes': 18395, 'sha256': '8d7c2e0938b03aa1e0fc8c3bf178f2a2604aaa1f3ec9dde44216249d69e2a2a4'}, {'path': 'benchmarks/_speed_cells.py', 'bytes': 17715, 'sha256': 'e5dc7e2df696c1e943ab083aa5782267029d9437d5a842ec30b6f6856b1c3d07'}, {'path': 'benchmarks/_speed_pipeline.py', 'bytes': 17592, 'sha256': '3f879dfdef14c67db7e544a464faaf5e9b3c9b45427a0c01520e40f79dd10514'}, {'path': 'benchmarks/speed-input-2026-11.json', 'bytes': 7951, 'sha256': 'ac44c4deaa2c3bb8107f5eb60653d5b587c1d156fdf342e54fff34776d4c425e'}, {'path': 'benchmarks/speed-main.lock.txt', 'bytes': 173667, 'sha256': 'e7db4ba8b6afdf36d9eb0cd41499cb10ff01d3a4a3bacbd7a413d3e2c964f875'}, {'path': 'benchmarks/speed-reference.lock.txt', 'bytes': 98420, 'sha256': '218d9855038b4ef6f3253c04c1f031350f4c52135fe16cbff35bf625e348f73d'}, {'path': 'benchmarks/speed-rust.lock', 'bytes': 26727, 'sha256': 'b64150bf3e47180247cf6d220848c4ac1191dfc6dfc6b62ac86cc178dbaebe0f'}]
for row in expected:
 p=pathlib.Path('/headline-source')/row['path']
 assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
print('ALL_SEVEN_SOURCE_HASHES_VERIFIED')
VERIFY_SOURCE
export SPEED_ALLOCATION_ID=fp09zqzjdg0pgh
export SPEED_MACHINE_ALLOCATED_AT="$(/speed-env/main/bin/python -c 'import json;print(json.load(open("/speed-results/environment.json"))["machine"]["allocated_at_unix"])')"
export PYTHONUNBUFFERED=1
nohup /speed-env/main/bin/python /headline-source/benchmarks/speed-run-2026-11.py --study headline --workers "$workers" --run --reuse-work /speed-work --results /headline-results --work /headline-work --allocated-at "$HEADLINE_STARTED_AT" > /headline-logs/run.log 2>&1 < /dev/null &
printf '%s\n' "$!" > /headline-logs/measurement.pid
printf 'HEADLINE_PID=%s\n' "$!"
REMOTE
