# DR-151 (Tempo, Qualität und Kosten gegen die Alternativen vergleichen): Auswertung und Vorschlag

Stand: 2. November 2026. Nur Auswertung und Planung. Kein neuer Lauf, kein Merge.

## Sammlung und Ergebnis

Der eingefrorene Quellstand ist `0c639113f80383fda461f3e776db38eee0efee71`. Die Bibliothek stammt aus `624251df2269e3099f5c61987be63e718893b58c`. Das ist der unreleaste 2.0-Quellstand, auch wenn setuptools-scm als Paketversion `1.1.1.dev919+g624251d` schreibt.

Die Hauptsammlung liegt unter `/Users/oliverborchers/fse-speed-run/collected/speed-results`. Alle 380 Manifestdateien (1.883.476 Payload-Bytes) sind unabhängig nach Größe und SHA256 geprüft. Das Manifest hat SHA256 `d859a769215f9f5724ad523864b1a7dfd46e86aecf07e712a66c62017ec0abe1` und stimmt mit dem direkt gelesenen DONE überein. Die fünf zusätzlichen Diagnosedateien (2.048.005.762 Bytes) stimmen ebenfalls mit den übertragenen Hashes überein. `remote-sha256.txt` enthält zusätzlich ein Verzeichnislisting. Seine fünf Hashzeilen stimmen mit `local-sha256.txt` überein.

Der Host meldet AMD EPYC 9965 192-Core Processor. Die Maschine hatte 32 zugewiesene logische CPUs, 64.000.000.000 Bytes RAM und 150 GB Disk. Die Adapter begrenzen die CPU-Affinität auf die ersten 1 beziehungsweise 16 erlaubten CPUs. Hostlast wird gemäß Freigabe aufgezeichnet, nicht als Gültigkeitsfilter verwendet.

| Stufe | Gültig | A/A ungültig | Fehlgeschlagen | Nicht gestartet |
| :--- | ---: | ---: | ---: | ---: |
| 100M-Schreiben | 0 | 1 | 0 | 0 |
| Datentypen | 6 | 0 | 0 | 0 |
| Klassifikation | 0 | 0 | 1 | 0 |
| Bibliotheken | 2 | 1 | 5 | 0 |
| Aufrufgrößen und Startkosten | 5 | 3 | 0 | 2 |
| Gesamt | 13 | 5 | 6 | 2 |

Gültig heißt zunächst: das aufgezeichnete Protokoll ist erfüllt. Ich habe die A/A-Bänder, Mediane, gepaarten Quotienten, identischen Eingaben, Adapter-Hashes und die Verknüpfung mit den vollständigen Ausgabeprüfungen unabhängig reproduziert. Diese Prüfung ersetzt keine neue Inferenz. Die fünf kurzen Diagnosezellen sind ausdrücklich keine allgemeinen Tempo-Kopfzeilen.

Veröffentlichbare Bibliothekszellen aus diesem Lauf sind POTION-8M float32 bei einem Worker gegen Rust und FastEmbed. Der gepaarte Median beträgt 1,726263 beziehungsweise 28,489500 zugunsten fse. Die A/A-Obergrenzen sind 1,099178 beziehungsweise 1,098456. Der Python-Model2Vec-Vergleich ist ungültig. Der ST-Vergleich liefert wegen des Adapterfehlers keine veröffentlichbare Geschwindigkeit.

## Ursachen und Grenzen der Belege

### headline-01

Die gemessene Reihenfolge war A0, B0, A1, B1. A benötigt 45,619 / 45,895 Sekunden, B 53,033 / 51,877 Sekunden. Globales A/A: 1,162501. Der Abstand liegt überwiegend zwischen den Armen und bleibt ungültig.

Die Jobdateien wurden um 23:27:20, 23:28:36, 23:29:59 und 23:31:15 UTC geschrieben. Diese Zeitstempel markieren die Jobvorbereitung. Sie sind keine exakten Encode-Startzeiten. Die Untimed-Abschnitte enthalten Ausgabeprüfung und Löschung.

Der Quellcode widerlegt eine gleichzeitig laufende Python-Löschung: Der Kindprozess endet, die vollständige Ausgabe wird geprüft, `remove_output` kehrt synchron zurück, erst dann startet der nächste Kindprozess. Asynchroner Writeback oder andere Datenträgereffekte bleiben möglich. Sie sind nicht belegt. Es gibt weder Löschzeitstempel noch eine Writeback-Zeitreihe.

Die Ruhekontrolle war mit A/A 1,009409 sauber. Sie dauerte etwa 211 Sekunden und beweist keine spätere Ruhe beim Schreiben. Die vom Koordinator beobachteten null CPU-Drosselungen erklären den Abstand ebenfalls nicht. Eine Ursache durch CPU, NUMA oder Datenträger lässt sich aus den vorhandenen Aufzeichnungen nicht eindeutig bestimmen. Die nicht rotierte Schreibreihenfolge ist ein tatsächlicher Versuchsdesign-Mangel.

### libraries-09 und call-size-19/20/24

| Zelle | Globales A/A | Größter Abstand innerhalb einer Runde | Beobachtetes Muster |
| :--- | ---: | ---: | :--- |
| libraries-09 | 1,276203 | 1,075010 | Beide Arme in Runde 3 langsamer |
| call-size-19 | 1,109751 | 1,083989 | A relativ stabil, B schwankt zwischen Runden |
| call-size-20 | 1,114938 | 1,016891 | Beide Arme in Runde 3 schneller |
| call-size-24 | 1,373023 | 1,051720 | Beide Arme werden über die Runden schneller |

Für libraries-09: A 3,588 / 3,900 / 4,514 Sekunden, B 3,613 / 3,628 / 4,579 Sekunden. Für call-size-20: A 28,561 / 29,446 / 26,856 Sekunden, B 28,545 / 29,344 / 26,410 Sekunden. Für call-size-24: A 3,161 / 2,546 / 2,421 Sekunden, B 3,088 / 2,432 / 2,302 Sekunden.

Das sind überwiegend zeitliche Veränderungen, keine unterschiedlichen A/B-Implementierungen. Alle Kontrollen identifizieren denselben geladenen fse-Code. Die Kontrollen liegen durch die rotierenden Bibliotheksarme teilweise mehrere Minuten auseinander. Das strenge globale Band erkennt gerade diese Drift. Ein Wechsel auf ein Band pro Runde wäre eine Lockerung und wird nicht vorgeschlagen.

Die rekonstruierten Job-Zeitstempel stehen in `control-timeline-analysis.json`. Es fehlen Last, `memory.stat`, Dirty-/Writeback-Werte und I/O-Werte pro Runde. Die Umgebung enthält nur anfängliche Last und Speicherbelegung. Daher kann ich keine belegte Korrelation mit diesen Größen liefern. Es wäre falsch, nachträglich CPU-Rauschen oder Writeback als bewiesene Ursache zu benennen.

### Speicherbudget: classification-08, libraries-13 bis 16

Alle fünf Abbrüche kamen aus der Python-Vorprüfung, bevor ein Messkindprozess startete. Es gab keinen OOM-Kill und keinen Status 137.

Die Vorprüfung berechnet:

`memory.current + texts * dimensions * 4 * 3 + input_file_bytes * 4 > 0.85 * memory.max`

| Zellen | Pauschal zusätzlich reserviert | Aus der Ablehnung folgende Mindestbelegung |
| :--- | ---: | ---: |
| classification-08 | 40,216 GB | mehr als 14,184 GB |
| libraries-13/14/15 | 23,561 GB | mehr als 30,839 GB |
| libraries-16 | 24,465 GB | mehr als 29,935 GB |

Die Schwelle beträgt 54,4 GB. Der genaue damalige Wert von `memory.current` wurde nicht gespeichert. Die Mindestwerte folgen algebraisch aus der Ablehnung, sie sind keine gemessenen RSS-Werte.

Zwei Fehler im Schutzmodell sind nachgewiesen: Klassifikation wird mit Dimension 256 und drei großen Embeddingmatrizen budgetiert, obwohl die Rückgabe int64-Labels ist und der gefaltete Kopf vier Klassen hat. Für den ungefalteten Arm ist weiterhin eine eigene volle Embeddingmatrix einzuplanen. Außerdem behandelt die Vorprüfung jeden belasteten Dateicache als nicht verfügbar, ohne Rückgewinnung zu berücksichtigen. Alle vorbereiteten Eingaben bleiben bis zum Ende bestehen. Damit ist die Ablehnung kein Nachweis, dass die Aufgaben tatsächlich mehr als 64 GB brauchen.

Vorschlag: Budget je Messart und Backend anhand gleichzeitig lebender Arrays berechnen. Cgroup-Grenze, `memory.current`, `memory.stat` und jede Schätzkomponente im Ablehnungsbeleg speichern. Eigene nicht mehr benötigte Eingaben nach ihrem letzten Nutzer entfernen. Keine fremden Caches löschen und nicht einfach die Sicherheitsgrenze erhöhen.

### libraries-12: ST-Ausgabefehler

Das ist mein Fehler im Benchmark-Adapter. `prepare_models` nutzt für das ST-Repository `StaticModel.from_pretrained(..., max_length=None).encoder`. Dieser Ladepfad hat die Model2Vec-Regel und verwirft `[UNK]`. Natives ST `StaticEmbedding` mittelt dessen Tabellenzeile mit. Normierung und fehlende Längenbegrenzung allein machen beide Modelle daher nicht gleich.

Die gespeicherten Ausgaben bestätigen die Ursache: 1.257 von 250.000 Zeilen verletzen die unveränderten Grenzen `rtol=3e-5, atol=3e-6`. Beide Ausgaben haben Einheitsnorm. Die größte Komponentenabweichung beträgt 0,0348472. Bei allen 1.257 betroffenen Zeilen erklärt die Richtung der originalen `[UNK]`-Tabellenzeile die Abweichung bis auf höchstens 7,76e-8 Restfehler. Die acht ersten Fehlertexte wurden aus dem gepinnten WikiText und dem Seed rekonstruiert. Alle enthalten `[UNK]`, acht anfängliche Kontrolltexte enthalten keines.

Die gelesene lokale ST-Installation ist byte-identisch zum Paketfingerprint des Messarms: Version 6.2.0, SHA256 `eba53ca5e629e51e238172f86ecfe7e2bce769ddb3eaa2f060b5af04349d79c3`. Der entsprechende Quellcode mittelt alle Token-IDs. Der gepinnte fse-Quellcode und `docs/architecture/hub.md` dokumentieren den Unterschied ausdrücklich.

Der korrekte Adapter ist bereits vorhanden:

```python
Encoder.from_pretrained(snapshot, normalize=True, truncate=False)
```

Damit wird der native ST-Ladepfad mit `unknown=keep` verwendet. Kein Bibliothekscode muss geändert werden. Keine Toleranz wird gelockert. Vor einem weiteren Messlauf muss ein kleiner untimed Funktionsnachweis mit den gesicherten Fehlertexten gelingen. Dafür werden keine Benchmark-Tests ins Repository geschrieben. Bestehende Qualitätswerte werden nicht geändert.

### call-size-25 und call-size-26

Die Diagnose begann ungefähr 00:39:08 UTC. Ihr Budget war 45 Minuten, also bis etwa 01:24:08 UTC. call-size-24 startete um 01:21:14 UTC und durfte zu Ende laufen. Sie endete um 01:28:45 UTC. Die beiden Startkosten-Kontrollen wurden danach mit `not_started` und dem dokumentierten Budgetgrund geschrieben. Das ist das vereinbarte Verhalten, kein verschwiegener Fehler. Ein weiterer Versuch muss diese billigen Kontrollen zuerst ausführen.

## Was zur Rust-Frage schon belegt ist

Bei 16 Workern ist Rust für 5.000 Texte pro Aufruf im gepaarten Median etwa 1,73-fach schneller. Bei 50.000 Texten ist fse 1,94-fach schneller, bei 500.000 Texten 1,62-fach. Alle drei Diagnosezellen bestehen A/A. Damit liegt der beobachtete Wechsel zwischen 5.000 und 50.000 Texten. Eine genauere Schwelle wurde nicht gemessen.

Der wiederverwendete fse-Rechenpool senkt bei 5.000 Texten den Median von ungefähr 11,97 auf 10,75 ms. Rust liegt dort bei 6,99 ms. Wiederverwendung erklärt also nur einen Teil des Abstands. Bei 500.000 Texten liegen fse normal und wiederverwendet beide bei etwa 0,524 s. Der verschachtelte Rust-Ausgabepfad ist als Diagnose schneller als sein flacher Pfad. Seine nachfolgende Umwandlung ist ausdrücklich nicht mitgemessen. Er ist deshalb kein Ersatz für den primären Vergleich mit zusammenhängender Ausgabe.

Die absoluten Startkosten wurden nicht gemessen, weil die beiden Kontrollen nicht starteten. Ich behaupte daher keine vollständige kausale Zerlegung.

## Kosten des abgeschlossenen Laufs

Der Koordinator bestätigt 8.244 Sekunden bis zur Löschung. Bei 0,96 USD/h plus 150 GB zu 0,10 USD/GB/Monat mit 720 Stunden sind das rechnerisch 2,2461 USD, gerundet 2,25 USD. Das ist eine Laufzeitrechnung, keine Rechnung des Anbieters. Der frühere Einrichtungsfehler mit ungefähr 0,10 USD bleibt separat. Die Maschine ist gelöscht und der eigene SSH-Wächter beendet.

## Vorschlag für einen begrenzten Folgelauf

Das ist ein Vorschlag für Oliver, keine Startfreigabe. Empfehlung: zehn fehlende Zellen mit Priorität für Veröffentlichung und Klassifikation. Die sechs gültigen Datentypzellen, Rust und FastEmbed mit einem Worker sowie gültige Diagnosepunkte werden nicht wiederholt.

| Stufe | Zellen oder Eingabe | Erwartete Minuten |
| :--- | :--- | ---: |
| Einrichtung, kleine Funktionsprüfung, Ruhekontrolle | gleiche Pins, korrigierter ST-Adapter | 10 |
| Startkosten zuerst | call-size-25/26 | 2 |
| Python Model2Vec, 1 Worker | libraries-09, 500.000 Absätze | 14 |
| Natives ST, 1 Worker | libraries-12, 200.000 Absätze | 11 |
| Python Model2Vec, 16 Worker | libraries-13, 3,2 Mio. Absätze | 13 |
| Rust, 16 Worker | libraries-14, 3,2 Mio. Absätze | 6 |
| FastEmbed, 16 Worker | libraries-15, 3,2 Mio. Absätze | 44 |
| Natives ST, 16 Worker | libraries-16, 1,4 Mio. Absätze | 35 |
| Gefaltet, expliziter gleicher Kopf, Model2Vec gleicher Kopf | classification-08, 7,2 Mio. AG-News-Texte | 30 |
| 100M-Schreiben zuletzt | headline-01, gleiche kurze Texte | 12 |
| Gesamt | zehn Zellen | 177 |

Die Größen stammen aus den gemessenen Raten und sind Planungsvorschläge. Jede Paarung erhält exakt dieselbe Eingabe. Die Datentyp-Tabelle des abgeschlossenen Laufs bleibt eine getrennte, vollständig beschriftete Maschinenkohorte. Ein neuer Lauf auf einer neuen Maschine darf nicht als derselbe gemeinsame Host ausgegeben werden. Falls Oliver weiter alle Grafiken auf exakt einer Maschine verlangt, reicht ein Lauf nur fehlender Zellen nicht. Dann müssten auch gültige Zellen wiederholt werden, was hier nicht vorgeschlagen ist.

Die Empfehlung verschiebt drei ungültige Diagnosewiederholungen ausdrücklich: call-size-19, call-size-20 und call-size-24. Die vorhandenen gültigen 16-Worker-Punkte beantworten bereits die Frage nach dem Größenwechsel. Nichts wird als gültig umgedeutet. Alle 13 offenen Zellen sind als zweite Variante möglich, kosten aber mehr.

32 vCPU, 64 GB RAM, 150 GB Disk. Bei den bisherigen Preisen: etwa 2,89 USD erwartet. Vorschlag für die weiche Laufzeitgrenze: 270 Minuten plus zehn Minuten Sicherungsreserve. Dafür 4,58 USD einplanen. Bereits gestartete Zellen laufen zu Ende. Eine weiche Grenze ist keine mathematisch harte Kostengarantie. Neue Zellen müssen vor ihrem Start gegen Restzeit und Geldreserve geprüft werden. Keine automatische Wiederholung oder neue Maschine bei Rauschen.

Alle 13 offenen Zellen würden nach den gemessenen Dauern etwa 218 Minuten und 3,56 USD erwarten lassen. Mit 330 Minuten weichem Horizont und zehn Minuten Sicherungsreserve wären ungefähr 5,56 USD einzuplanen. Annahme für das Restguthaben: 7,30 minus 0,10 minus 2,25 ergibt 4,95 USD. Unter dieser Annahme liegt die volle Reserve etwa 0,61 USD darüber. Der Koordinator muss das echte Guthaben vor einer Freigabe bestätigen.

Weitere notwendige Änderungen vor einer Freigabe:

1. Den nativen ST-Ladepfad verwenden und genau die gesicherten Fehlertexte untimed prüfen.
2. Speicherbedarf je Arm berechnen und aufzeichnen. Vorbereiten und auswerten in getrennten Prozessen. Eigene fertige Eingaben nach dem letzten Nutzer freigeben.
3. A/A-Arme beim Schreiben über die Runden rotieren. Eigene Ausgabe nach dem Timer explizit synchronisieren, prüfen und löschen. Den nächsten Arm erst danach starten. Kein globales `sync` auf dem Host. Die Synchronisation bleibt separat ausgewiesen, die gemessene Durability bleibt `none`.
4. UTC- und monotone Zeitstempel für Laden, Encode, Prüfung, Synchronisation und Löschung aufzeichnen. Dazu CPU-Affinität, cgroup CPU-/Speicher-/I/O-Zähler und Dirty-/Writeback-Werte an den Grenzen. Hostlast bleibt nur Kontext.
5. Für die Klassifikation zusätzlich Dateigrößen und SHA256 von gefaltetem Modell, Encoder und identischem linearem Kopf speichern. Keine neue Genauigkeit berechnen.
6. Drei vollständige Runden für normale Zellen, zwei rotierte A/A-Runden für 100M. Minimum zwei Sekunden für jeden normalen fse-Aufruf. Das globale A/A-Limit bleibt 10 Prozent. Ein erfolgreicher Startprobe garantiert keinen ruhigen Restlauf.
7. Startkosten zuerst, lange Bibliotheken einzeln budgetieren, 100M-Schreiben zuletzt. Jede Zelle sofort sichern, DONE auf jedem terminalen Pfad, beaufsichtigte Sammlung und sofortige Löschung durch fse-main.

Keine neuen Qualitätsmessungen. Keine Tests für Messwerkzeuge im Repository. Kein Merge und kein Start durch diesen Worker.

## Lokale Prüfbelege

Alle folgenden Dateien liegen im selben Arbeitsverzeichnis wie dieser Bericht:

- `final-collection-verification.json`: 380 Dateien und Abschlussmanifest.
- `diagnostics-transfer-verification.json`: fünf zusätzliche Diagnosedateien.
- `final-cells-audit.json`: unabhängige Arithmetik und Protokollverknüpfung für alle 26 Zellen.
- `control-timeline-analysis.json`: Reihenfolge, vorhandene Zeitstempel und Telemetriegrenzen.
- `memory-admission-analysis.json`: genaue Speicherformel und abgeleitete Grenzen.
- `saved-vector-analysis.json`: blockweise Vektorprüfung und `[UNK]`-Nachweis.
- `followup-cost-proposal.json`: Kostenrechnung und beide vorgeschlagenen Varianten.

Die Analyse benutzte kleine Puffer unter heavy.lock, nice 10, über 60 GiB freien Speicher. Es wurden keine Modelle inferiert und keine lokale Geschwindigkeit gemessen. Die erste Diagnoseprüfung scheiterte an einem privaten NumPy-Hilfsnamen. Die korrigierte Prüfung und der nachfolgende Ursachenabgleich liefen erfolgreich. Eigene Sperren wurden freigegeben. Keine Daten oder fremden Caches wurden gelöscht.
