Review the committed implementation at 8ce4f68 in this detached worktree. Read all three source files, the input contract and three dependency locks. Do not modify files, run tests, install packages, launch measurements or inspect credentials.

Scope: benchmarks/speed-run-2026-11.py, benchmarks/_speed_cells.py, benchmarks/_speed_pipeline.py, benchmarks/speed-input-2026-11.json, benchmarks/speed-main.lock.txt, benchmarks/speed-reference.lock.txt, benchmarks/speed-rust.lock. The rest of this branch contains historical evidence and unfinished cleanup outside this review.

This is one final Linux x86 CPU comparison, Python 3.13, 32 vCPU, 64GB RAM and 150GB disk. Only the coordinator launches a paid machine. Quality is already complete and must not be recomputed. No benchmark tests are wanted. One executable plus two private modules is approved. Existing engineering guardrails remain binding.

The approved full workload has 26 result cells: streamed 100M int8 writes (two A/A rounds), POTION-8M three dtypes at workers 1/16 on a shared 4.62M input, four same-model library pairs at workers 1/16, one folded/unfolded/Model2Vec same-linear-head classification speed cell, eight call-size cells and two startup diagnostics. Normal cells have three rotating fresh-process rounds, separate first and warm timings, identical input within pairs, every fse call >=2 seconds, A/A global warm median band upper <=1.10, output checks and each backend's own code identity. Call-size diagnostics explicitly exempt the two-second rule and include persistent-pool/native nested-output controls. The classification compares engines with the same raw-mean linear head, not the fine-tuned Model2Vec MLP. No accuracy is evaluated.

Only one bounded sizing estimate is allowed per configuration, no iterative calibration. An initial noisy quiet control must not abort later cells. Each stage has an admission budget. Started cells finish, the budget is deliberately soft. The planning horizon is 345 minutes, spend admission uses machine allocation time, compute $0.96/h plus 150GB at $0.10/GB/month divided by 720 hours, balance $7.30 and a 10-minute collection reserve. No hard kill of a started cell. Every completed cell is immediately durable JSONL, progress every 15 seconds, final DONE with status and manifest hash. Inputs/cache/output buffers stay outside collected evidence. Prepared outputs may be deleted only after row/digest checks. Never invent a speed number or relabel different inputs as identical.

Report in German, with an explicit 'Keine Befunde' for each category without findings:
1. Runtime correctness, actual library APIs, dtype/normalization/output equivalence and thread budgets.
2. Experimental validity, A/A, paired ratios, input/loaded-code identity and Rust attribution.
3. Memory/disk safety, costs, stage isolation, durable terminal status and observability.
4. Reproducible setup, dependency locks and source/toolchain pins.

Each finding needs file:line, severity (Blocker, Fehler, Warnung), exact code evidence and a concrete fix. Distinguish verified defects from uncertainty. Do not suggest extra benchmark test files or broad new studies.
