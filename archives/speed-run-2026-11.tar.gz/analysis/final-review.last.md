Der Stand ist **nicht startbereit**. Ein fehlender Pflichtbaustein verhindert fse-Importe. Weitere Befunde betreffen Messauswertung und Budgetsteuerung.

Alle sieben Dateien wurden vollständig gelesen. Die folgenden Befunde stammen aus der statischen Prüfung, ohne Tests, Installationen oder Messungen.

**1. Laufzeit, Bibliotheks-APIs, Ausgabeäquivalenz und Threads**

- **Warnung: FastEmbed und fse kürzen Texte unterschiedlich.**  
  Beleg: `benchmarks/_speed_pipeline.py:130–133` übergibt die vollständigen Texte an `model.embed`. FastEmbed 0.9.1 begrenzt auf 512 Tokens. fse übernimmt zusätzlich Model2Vecs vorgelagerten Zeichenschnitt bei `512 * median_token_length`. Diese Regeln sind nachweislich verschieden. Ob die konkrete Stichprobe abweichende Vektoren erzeugt, wurde nicht ausgeführt. Dann würde der vollständige Ausgabevergleich die Zelle abbrechen.  
  **Korrektur:** Eine gemeinsame Kürzungsregel für dieses Paar festlegen und deren Anwendung dokumentieren. Bei vorbereiteten Textänderungen deren tatsächlichen Input-Hash speichern. Die Vergleichstoleranz beibehalten. Quellen: [FastEmbed](https://raw.githubusercontent.com/qdrant/fastembed/v0.9.1/fastembed/text/static_embedding.py), [Model2Vec](https://raw.githubusercontent.com/MinishLab/model2vec/v0.10.0/model2vec/model.py).

- **Fehler: Der exakte Vergleich prüft Werte statt Bitmuster.**  
  Beleg: `benchmarks/_speed_cells.py:295` verwendet `np.array_equal(a, b)`. Dadurch gelten beispielsweise `+0.0` und `-0.0` als gleich. Die vorhandenen Ausgabe-Hashes werden nicht zwischen diesen Prozessen verglichen. Das erfüllt den verbindlichen Bitvergleich für fse nicht.  
  **Korrektur:** Im exakten Pfad die Byteansichten der bereits auf Form und Datentyp geprüften Arrays vergleichen.

Keine weiteren Befunde zu den geprüften API-Signaturen, Datentypen oder den gesetzten CPU-Affinitätsgrenzen.

**2. Experimentelle Gültigkeit, A/A, Paarverhältnisse und Rust-Zuordnung**

- **Fehler: Streaming erfindet eine Warmbeobachtung.**  
  Beleg: `benchmarks/_speed_pipeline.py:463–466` misst genau einen Schreibaufruf. Zeilen 485–486 speichern denselben Wert als `first_seconds=seconds` und `warm_seconds=[seconds]`. `controls()` und `arm_summary()` behandeln ihn anschließend als Warmmessung.  
  **Korrektur:** Tatsächliche Erst- und Warmaufrufe getrennt messen und speichern. Einen einzelnen Schreibdurchlauf niemals zusätzlich als Warmbeobachtung ausweisen.

- **Fehler: Streaming prüft keine Ausgabeidentität zwischen den A/A-Armen.**  
  Beleg: `benchmarks/_speed_pipeline.py:467–487` prüft Zeilenzahl und erzeugt Datei-Hashes. `benchmarks/speed-run-2026-11.py:222–225` löscht die Ausgabe danach, ohne diese Hashes zwischen Armen oder Runden zu vergleichen. Unterschiedliche, intern gültige Vektoren können deshalb eine gültige Zelle ergeben.  
  **Korrektur:** Einen kanonischen Digest der gespeicherten Vektordaten einschließlich Quantisierungsdaten bilden. Diesen über alle vier Schreibläufe vergleichen, bevor die jeweilige Ausgabe gelöscht wird.

- **Fehler: Die native Nested-Kontrolle enthält zusätzliche Adapterarbeit im Zeitfenster.**  
  Beleg: `benchmarks/_speed_pipeline.py:227–230` misst  
  `model.encode(&texts).into_iter().flatten().collect::<Vec<f32>>()`.  
  Damit enthält diese Kontrolle zusätzlich Flattening, eine weitere Ausgabeallokation und die Freigabe der einzelnen Zeilen. Eine Differenz zur Flat-API lässt sich dadurch nicht allein dem nativen Ausgabeformat zuordnen.  
  **Korrektur:** Die Zeit direkt nach `model.encode(&texts)` stoppen. Flattening oder zeilenweise Hashprüfung anschließend ausführen.

- **Fehler: Der Klassifikationszelle fehlen die gepaarten Verhältnisse.**  
  Beleg: `benchmarks/_speed_cells.py:106–118` berechnet Verhältnisse nur bei `cell.get("reference")`. Die Klassifikationszelle in `benchmarks/speed-input-2026-11.json:178–187` besitzt dieses Feld nicht. Ihr Ergebnis enthält deshalb `paired_speedup=null`, obwohl vier Arme gemessen werden.  
  **Korrektur:** Pro Runde die Verhältnisse `unfolded/folded` und `model2vec-linear/folded` berechnen und anschließend deren Streuung zusammenfassen.

Keine weiteren Befunde zur gemeinsamen 4,62-Millionen-Eingabe, zur globalen A/A-Medianbandprüfung oder zur gespeicherten Rust-Binäridentität.

**3. Speicher, Kosten, Stufenisolation, Abschluss und Beobachtbarkeit**

- **Fehler: Vorbereitungsstufen umgehen die Aufnahmebudgets.**  
  Beleg: `benchmarks/speed-run-2026-11.py:437–439` startet Vorbereitung, Quiet-Kontrolle und Sizing ohne `ledger.admit`. Die Budgetprüfung beginnt erst bei den Ergebniszellen. Insbesondere startet `size_once()` in Zeilen 374–391 weitere Prozesse unabhängig vom 15-Minuten-Budget. `billing.planning_minutes=345` wird nicht zur Aufnahmeentscheidung verwendet.  
  **Korrektur:** Vor jedem neuen Vorbereitungsschritt und Sizing-Prozess Stufenbudget, Planungshorizont und verbleibendes Geld prüfen. Bereits gestartete Arbeit weiterhin vollständig beenden.

- **Fehler: Laufzeitschätzungen übertragen ungleiche Arbeitsmengen.**  
  Beleg: `benchmarks/_speed_cells.py:143–151` skaliert frühere Zellzeiten ausschließlich nach Textanzahl. Der Vergleichsschlüssel ignoriert Rundenzahl, `warm_passes` und zusätzliche Kontrollarme. Dadurch können Bibliothekszellen mit zwei Aufrufen Schätzungen für Call-size-Zellen mit 129 Aufrufen bestimmen. Zusätzlich zählt `benchmarks/speed-run-2026-11.py:359–364` bei Klassifikation nur zwei gefaltete Arme, ohne Unfolded und Model2Vec.  
  **Korrektur:** Schätzungen nach tatsächlicher Arm- und Aufrufzahl gewichten. Alle Klassifikationsarme berücksichtigen. Dafür vorhandene Beobachtungen verwenden, keine zusätzliche Kalibrierung starten.

- **Warnung: Fehlgeschlagene Zellen können den gemeinsamen Datenträger füllen.**  
  Beleg: `benchmarks/speed-run-2026-11.py:248–262` entfernt Ausgaben erst nach erfolgreichem Vergleich. Bei einem Fehler bleiben Referenz und aktuelle Ausgabe liegen. Zeilen 413–414 protokollieren den Fehler und starten später weitere Zellen. `benchmarks/_speed_pipeline.py:462` erfasst freien Speicher lediglich, ohne Aufnahmeprüfung.  
  Die fehlende Begrenzung ist belegt. Ein tatsächlicher Platzmangel wurde nicht gemessen. Er könnte auch JSONL und `DONE` auf demselben Dateisystem verhindern.  
  **Korrektur:** Vor Eingabeerzeugung und Zellstart den benötigten Speicher einschließlich vorhandener Restdateien prüfen. Eine feste Reserve für Ergebnisse und Abschlussdateien freihalten. Ungeprüfte Ausgaben nicht automatisch löschen.

Die Kostenformel ist korrekt: **0,980833… USD/h** einschließlich Datenträger. Allokationszeit und zehn Minuten Reserve fließen ein. Keine weiteren Befunde zur Fortsetzung nach einer verrauschten Quiet-Kontrolle oder zum regulären JSONL-/DONE-Abschluss.

**4. Reproduzierbares Setup, Locks und Pins**

- **Blocker: Im Haupt-Lock fehlt `pydantic`.**  
  Beleg: `benchmarks/speed-main.lock.txt:1–62` enthält weder `pydantic` noch dessen notwendige Abhängigkeiten. Die festgelegte fse-Revision verlangt `pydantic>=2.5.0` und importiert es über `fse._validation`. `benchmarks/_speed_pipeline.py:58–67` installiert fse ausdrücklich mit `--no-deps`. Die Paketprüfung in Zeile 55 läuft vorher.  
  Deshalb kann das Setup erfolgreich enden, obwohl anschließend fse-Importe mit `ModuleNotFoundError: No module named 'pydantic'` scheitern.  
  **Korrektur:** Pydantic samt vollständiger Abhängigkeitsauflösung in den Haupt-Lock aufnehmen. Die bestehende Paketprüfung zusätzlich nach der fse-Installation ausführen.

- **Warnung: Die Build-Umgebung ist nur teilweise festgelegt.**  
  Beleg: `benchmarks/_speed_pipeline.py:26–37` installiert Compiler und Systembibliotheken ohne Versionsbindung. Zeile 42 übernimmt `sys.executable`, ohne Python-Patchversion festzulegen. Beide Python-Locks enthalten Versionspins, aber keine Artefakt-Hashes.  
  Das belegt eine Reproduzierbarkeitslücke, keinen bereits nachgewiesenen Buildfehler.  
  **Korrektur:** Basisimage, Python-Patchversion und Compiler festhalten. Die verwendeten Python-Artefakte über Hashes binden und den Setup-Nachweis in das abschließende Manifest aufnehmen.

Keine weiteren Befunde zur Übereinstimmung von Rust-Revision, Cargo-Lock und deklarierten direkten Rust-Abhängigkeiten.

Erledigt: Statische Prüfung von Commit `8ce4f68`, ohne Dateiänderungen oder Ausführung des Benchmarks.  
Offen: Ein Blocker sowie die beschriebenen Mess- und Steuerungsfehler.  
Benötigt von dir: nichts.