# Response to the single independent review

Reviewed source: 8ce4f682c0c17a6abbb6e3f7ebfdcf9889862f8a. Reviewer: gpt-6-astra, high. Exactly one review ran, completed with exit status 0, without tests or measurement execution. Final implementation source: dca557f (full pin in the handoff). No second review is claimed.

1. FastEmbed truncation: accepted. POTION library pairs now use a shared character-capped source before sampling. The cap and actual file digest are recorded. Native StaticEmbedding uses its unlimited-text rule in the corresponding fse artifact. Long and Unicode input checks passed.
2. Exact output checks: accepted. The exact branch compares uint8 views, including signed zero. A functional assertion confirmed that +0 and -0 differ.
3. Streaming warm observation: accepted as a reporting defect. The approved headline still has four real writes, not eight. Each is now explicitly a streamed-single-call observation. No fabricated warm field exists. Controls and summaries support this declared observation type.
4. Stream output identity: accepted. Canonical hashes cover all saved NPY payloads, including quantization scales and inverse norms. All four tiny output digests and row counts matched before deletion.
5. Native nested adapter: accepted. Its timer stops before flattening. The corrected native worker compiled and its outputs passed the same checks.
6. Classifier ratios: accepted. Results report unfolded/folded and Model2Vec-linear/folded paired median ratios separately. Fixed-duration functional assertions verified both formulas.
7. Admission budgets: accepted. Setup commands, preparation, quiet, sizing and result cells all use stage and total admission. Started work is not killed. Provisioning remains in monetary admission, while the five-minute setup stage uses the shared SPEED_SETUP_STARTED_AT epoch. The controller dry-run covered stage and funds exhaustion.
8. Runtime estimates: accepted. Estimates scale by text count, rounds, calls and arm count, with stage matching. Classifier admission includes both measured encoder arms. Those observations are obtained first, without an additional search.
9. Disk leftovers: accepted. Exact prepared-input byte counts and conservative output allocation are checked before writing. Two GiB remain reserved. Failed unchecked outputs remain preserved and consume the next admission check's available space.
10. Pydantic blocker: accepted and fixed. The main closure contains all 65 packages, including Pydantic and its dependencies. Installed-package checks run after fse installation as well.
11. Build provenance: accepted. The official Linux image is bound by digest and Python patch version. Both Python environments require exact artifact hashes. The setup receipt records the actual C compiler and is copied into the result manifest. Rust compiler and library revision remain fixed. APT packages use the pinned image's official distribution repositories rather than a historical snapshot. Their later availability is not claimed to be immutable. The actual compiled package/binary hashes remain part of every arm's identity.

An additional functional audit caught a shadowed package-name variable introduced during refactoring. It was corrected. Separate metadata checks confirmed fse, Model2Vec, FastEmbed and sentence-transformers identify their own package names, paths and distinct content hashes. Original diagnostic logs remain unchanged.

Scope of local verification: function only. No local rate is eligible speed evidence. No benchmark test files are committed. The final steering proof is under .review/speed-implementation/control-dry-run-handoff, including cells.jsonl, progress.json, manifest.json and DONE for all four controller scenarios.
