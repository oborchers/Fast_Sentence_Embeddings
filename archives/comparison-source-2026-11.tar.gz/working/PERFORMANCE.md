# Performance evidence and interpretation

**Speed publication status:** All Apple M1 Pro timing results are **withdrawn: M1**. All Pod 2 timing cells and all Pod 3 small-input panel/scaling cells are invalid for speed publication, including cells that previously passed A/A. Earlier eligibility labels are superseded. MTEB, NanoBEIR, STS, numerical recall and classifier accuracy remain unchanged and valid. Current comparison speed evidence is limited to the large-input Pod 3 showcase and Pod 4c table cells that pass every gate.

## Current large-input comparison evidence

The [Pod 3 100M streamed showcase](benchmarks/baseline/dr151_pod3_showcase_20261101.json) retains its explicitly approved primary run and A/A repeat. The [Pod 4c summary](benchmarks/baseline/dr151_pod4c_summary_20261101.json) retains all completed table observations, including rejected cells. These studies use different pipelines and are not a same-model library speedup comparison. Their summaries cite exact archive commits. No eligible library-speedup or folded-classifier throughput claim is published from the withdrawn studies.

Pre-withdrawal M1 roofline, worker/tail-split, pooling, storage and dtype timing narratives are preserved only as withdrawn historical material in the [publication snapshot](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/52b575699fcc5dfec13b8c7b8bbbfbf41e359afc/benchmarks/baseline/results/dr151-withdrawn-publication-20261101/PERFORMANCE.md). Their rates, ratios, bandwidth measurements and cost projections are not current performance evidence. The original 1.1 baseline files remain unchanged for regression and quality comparisons. Linux probe observations likewise are not promoted to a controlled large-input library comparison.

The hardware model below remains a theoretical tool. The shipped M1 profile retains vendor specifications and topology, with measured M1 bandwidth observations removed. No local timing is authorized while the shared-machine restriction applies.

## The model in plain words

fse turns a text into a vector in a few steps: the strings are joined into one buffer, the buffer is cut into tasks, each task is tokenized and its token rows are averaged (pooled), and the result is normalized. The work grows with the tokens, so the model counts **tokens per second**. A text costs its tokens: texts per second are tokens per second divided by the tokens per text.

Three things limit the rate. Each gives a bound, the largest rate that this limit allows.

| bound | what limits | in one sentence |
|---|---|---|
| per core | the work of the workers | N cores do N times the work of one core. |
| Amdahl | the serial part | Work in the calling thread does not get faster with more cores. |
| memory | reading the table | Each token reads one row of the table from memory, and memory has a bandwidth. |

The **combined bound** puts them together: the serial part, then the parallel part at the slowest of its limits (the work of the workers, memory, or what the calling thread does while they run). Measured throughput divided by a bound is the **share**: how close fse comes to that limit.

```
tokens/s
   ^
   |              memory roof (BW / bytes per token)
   |  ------------------------------------------------
   |                         ___________ Amdahl: serial part + work / C(N)
   |                    ____/
   |               ____/    measured
   |          ____/    ....''''''''''''
   |     ____/ ...'''
   |   _/..''
   +-------------------------------------------------> workers
```

## The formulas

Measured at one worker, in seconds per token: `t_ser`, what the calling thread does before and after the run (join, scan, the rest of `encode`); `t_call`, what it does while the workers run (reserving rows for the tasks and committing them), which overlaps their work; and `t_par`, the stages of the workers (tokenize and lookup, pool, normalize, the rest of the tasks). `C(N)` is the summed speed of the cores N workers use, counted in performance cores:

    C(N)          = min(N, P) + r_E * min(max(N - P, 0), E)        (Hill and Marty 2008)
    per core      = C(N) / t_par
    Amdahl        = 1 / (t_ser + max(t_par / C(N), t_call))          (Amdahl 1967)
    memory        = BW / bytes_per_token                             (Williams et al. 2009)
    combined      = 1 / (t_ser + max(t_par / C(N), t_call, bytes_per_token / BW))

    bytes_per_token = row + weight (4) + id (4) [+ scale (4) for int8]
                      + 4 * dim / tokens_per_text  (the output row, written once)

P and E are the performance and efficiency cores, `r_E` the speed of an efficiency core relative to a performance core, BW a memory bandwidth in bytes per second. A rest below zero (stage times are differences of measured times) counts as zero.

How the stages are timed: `t_par` is the measured time of the tasks themselves (`Pipeline._work`, summed over the tasks of one run), so the bounds use the real path. Since PR 136 a task runs its stages in one native call; the split of `t_par` into tokenize, pool and normalize comes from running the same stages one by one over the whole corpus (`Task.batch`, the pooling kernel, `normalize@1`), which copies the token ids into a `Batch` and meets other cache states. The split attributes the time; it does not enter the bounds except through its sum.

## Assumptions

Each bound holds only under its assumptions. A share above 100 % (the tool flags it from 102 % on, the noise of the stage times) means an assumption failed, and the report says which.

1. **A core works as fast as it did alone.** The per-core and Amdahl bounds scale the time of one worker. With all cores busy a core can run slower (a lower clock, shared L2 caches) or wait (for the GIL, other processes, the scheduler). The tool measures the effect, not its cause: the summed wall and CPU time of the tasks at N workers against one worker.
2. **Threads fill the performance cores first, and an efficiency core counts as a performance core** (`r_E = 1`) unless a profile or `--e-core-ratio` says otherwise. This gives the largest C(N), so the bound stays a ceiling. The real ratio on fse's work is not measured; it matters only for more workers than performance cores.
3. **The calling thread is not counted as a core** for the parallel part.
4. **Every byte comes from memory** in the memory bound. Repeated rows of frequent tokens hit the caches, so real traffic is lower, and a measured rate can exceed this bound. The report prints the rate of row bytes read (tokens per second times row bytes) next to it, and notes when the distinct rows of the corpus fit the L2 cache of one cluster.
5. **Work and memory overlap within a core** in the combined bound (`max`, not the sum).
6. **The scan at N workers is measured at N**, every other stage of the calling thread at one worker.
7. **The calling thread's part during the run overlaps the workers** (`max` with their work, not the sum).

Not in the model: waits of the tasks (they show as the gap between their wall and CPU time), imbalance at the end of a call (measured by `benchmarks/runtime_timeline.py`, "Where the workers idle"), and the system level cache, whose size Apple does not publish.

## Sources

- S. Williams, A. Waterman, D. Patterson, "Roofline: An Insightful Visual Performance Model for Multicore Architectures", Communications of the ACM 52(4), 2009, doi:10.1145/1498765.1498785. The roof is the sustained bandwidth a benchmark measures, not the vendor peak.
- G. M. Amdahl, "Validity of the single processor approach to achieving large scale computing capabilities", AFIPS 1967, doi:10.1145/1465482.1465560.
- M. D. Hill, M. R. Marty, "Amdahl's Law in the Multicore Era", IEEE Computer 41(7), 2008, doi:10.1109/MC.2008.209: on asymmetric cores the parallel part runs at the summed speed of the cores.
- J. D. McCalpin, STREAM, https://www.cs.virginia.edu/stream/: sustained memory bandwidth measured, not quoted.
- Apple Newsroom, "Introducing M1 Pro and M1 Max", 18.10.2021, https://www.apple.com/newsroom/2021/10/introducing-m1-pro-and-m1-max-the-most-powerful-chips-apple-has-ever-built/: "up to 200GB/s of memory bandwidth", "10-core CPU, including eight high-performance cores and two high-efficiency cores".
- Apple Newsroom, "Apple introduces M4 Pro and M4 Max", 30.10.2024, https://www.apple.com/newsroom/2024/10/apple-introduces-m4-pro-and-m4-max/: "273GB/s of memory bandwidth", "up to 14-core CPU consisting of up to 10 performance cores and four efficiency cores".


## Quality checkpoints, unchanged

The dated quality checkpoints below retain their original scores and provenance cohorts. Their local encoding/evaluation times do not support speed claims. The final MIND scope remains not computed, 40 of 41 English tasks.

### First completed non-deferred quality configuration (01.11.2026)

POTION-8M float32 completed all 40 non-deferred English tasks and all 13 NanoBEIR
tasks using unmodified MTEB 2.26.25. Its unweighted mean over the 40 English task
main scores is **53.9527 points**. This excludes the explicitly deferred
MindSmallReranking task and is not a complete 41-task MTEB mean. Its full
13-task NanoBEIR mean is **43.8485 points**. Other model/precision results remain
pending, so these numbers establish no quality ranking.

The run used two CPU workers at nice 10, source commit `265e70d`, and encoder
fingerprint `xxh3-128:7aed2ca9bf7f9073ffa6778672a7575f`, matching the pinned
POTION-8M artifact in the bound source manifest. Source revisions, dataset
metadata, package versions and every task main score are retained in the
[raw quality journal](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/results/dr151-quality-primary.jsonl)
and [coverage summary](benchmarks/baseline/dr151_quality_primary_20261101.json).
Quality-run encode times are not used for speed or cost claims.


### POTION-32M quality checkpoint (01.11.2026)

POTION-32M float32 completed the same 40 non-deferred English tasks and all
13 NanoBEIR tasks with unmodified MTEB 2.26.25. The English 40-task mean is
**55.2573 points**, excluding MIND. The complete 13-task NanoBEIR mean is
**46.1754 points**. The full 41-task English mean remains unavailable.

The model revision is `1e5a03f8eeb2c98b928fbbd846f22f816360919f`, and the
finished encoder fingerprint is `xxh3-128:99737b0f0d2dc7cfb4ee240faa2e278f`.
The run began from source `0de9c3d`. Its method and runtime fingerprints differ
from the first POTION-8M invocation because provenance checks and the installed
extension changed between runs. These checkpoints therefore do not establish
a controlled model ranking. A same-method POTION-8M confirmation remains queued.
[Raw task records](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/results/dr151-quality-potion32-float32.jsonl)
and the [complete coverage summary](benchmarks/baseline/dr151_quality_potion32_20261101.json)
were first pushed in `7bb78dd`.

### POTION-retrieval-32M quality checkpoint (01.11.2026)

POTION-retrieval-32M float32 completed all 53 non-deferred tasks with unmodified
MTEB 2.26.25. Its English 40-task mean is **54.5098 points** and its complete
13-task NanoBEIR mean is **50.3872 points**. MIND alone remains deferred, so the
full 41-task English mean is unavailable. The pinned revision is
`6fc8051fab2a1e0ee76689cf08c853792ac285e7`, and the encoder fingerprint is
`xxh3-128:6f78af26bab53a3d464e97d9189f5b20`.

This is the first completed configuration under the normalized result-writer
method and current runtime fingerprint. The raw measured checkout is
`300bde8`. Earlier POTION-8M and POTION-32M checkpoints use different method or
runtime identities. Both confirmations remain queued, so these checkpoints
still establish no controlled model ranking. [Raw task records](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/results/dr151-quality-retrieval32-float32.jsonl)
and [coverage summary](benchmarks/baseline/dr151_quality_retrieval32_20261101.json).

### Quality on tasks with longer inputs (partial, 01.11.2026)

The document-task diagnostic joins full task scores to length statistics
packaged with unmodified MTEB 2.26.25. It selects every measured task with a
reported evaluation input stream averaging at least 1,000 characters.
Nineteen tasks qualify for the POTION-32M checkpoint. No evaluation rows are
sampled or removed, and no new aggregate score combines different metrics.
Where subset statistics exist, the report uses mapped English subsets.

Examples below use POTION-32M float32 from raw-source commit `7bb78dd`.
Scores are the complete task main scores multiplied by 100.

| Task | Upstream mean input characters | Main metric | Score (points) |
|---|---:|---|---:|
| ArguAna | 1,029.5 documents | nDCG@10 | 42.864 |
| BiorxivClusteringP2P.v2 | 1,664.0 texts | V-measure | 35.1222 |
| ImdbClassification | 1,293.8 texts | accuracy | 70.126 |
| SCIDOCS | 1,204.4 documents | nDCG@10 | 13.587 |
| SummEvalSummarization.v2 | 2,100.3 source texts | cosine Spearman | 24.7281 |
| Touche2020Retrieval.v3 | 2,096.4 documents | nDCG@10 | 48.228 |

These lengths are upstream descriptive metadata, not fresh measurements of
this run's inputs. They can precede the pinned task revision. They do not
measure model token lengths or truncation frequency. Scores use each model's
native input limits. The report retains the actual encoder description and
separate input streams. Other models remain pending, so this is no quality
ranking or evidence of full-document context retention.
[All 19 task breakouts and source-statistics digests](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/dr151_document_tasks_potion32_20261101.json).


### Comparison profiles (01.11.2026)

[The compact profile table](docs/benchmarks/dr151-profiles.md) records the hottest functions and memory peaks. Complete CPU samples, native allocation traces/HTML, RSS logs and original profile metadata live in the [pinned evidence archive](https://github.com/oborchers/Fast_Sentence_Embeddings/commit/ae79c80c5736706a1e39df2f69a18e5801ae82d3). Instrumented durations are not speed evidence. The table preserves the original runtime-attribution and allocation-versus-resident-memory caveats.


### Additional quality checkpoint  (01.11.2026)

POTION-multilingual-128M float32 completed all 53 non-deferred tasks with
unmodified MTEB 2.26.25. The 40-task English mean is 49.9565 points and the
complete 13-task NanoBEIR mean is 36.6528 points. MIND remains deferred because
it needs more than 16 GiB RAM on the M1. This is not a full 41-task English mean.
[Raw scores](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/results/dr151-quality-multilingual128-float32.jsonl)
and [coverage summary](benchmarks/baseline/dr151_quality_multilingual128_20261101.json)
retain the measured method and runtime. Earlier checkpoints use different
method cohorts, so these figures establish no controlled cross-model ranking.

Long-input breakouts are also available for the other completed checkpoints:
[POTION-8M](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/dr151_document_tasks_potion8_20261101.json),
[POTION-retrieval-32M](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/dr151_document_tasks_retrieval32_20261101.json)
and [POTION-multilingual-128M](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/dr151_document_tasks_multilingual128_20261101.json).
Each retains 19 full-task scores and the corresponding packaged length
statistics. Every score matches its raw completed task record. The same
limitations apply: these statistics describe upstream text streams, not
measured model token counts or truncation frequency. Separate method cohorts
remain separate. MiniLM and other counterparts are pending.


### Static-retrieval checkpoint 

Static-retrieval-mrl-en-v1 float32 completed all 53 non-deferred tasks. Its
40-task English mean is 51.8893 points, explicitly not a full 41-task mean.
The complete 13-task NanoBEIR mean is 50.3072 points. MIND alone remains deferred
because it needs more than 16 GiB RAM on the M1. The invocation took 17.4 minutes,
including setup, evaluation, waits and cooldowns. Every executed runtime record
reports actual process priority 10. The parent's earlier startup probe observed
priority 0 before `nice` took effect and is retained separately.
[Raw quality records](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/results/dr151-quality-staticretr-float32.jsonl)
and [coverage summary](benchmarks/baseline/dr151_quality_staticretr_20261101.json).
Separate method cohorts remain separate and establish no controlled ranking.

MiniLM and native multilingual POTION cache lookups failed before encoding
because unused repository exports or evaluation files were absent. The harness
now requests its pinned inference files. The existing required-file cache was
verified for all seven Hub models. Model revisions and complete input sets are
unchanged. This changes no MTEB package or loader.


Static-similarity-mrl-multilingual-v1 float32 also completed all 53 non-deferred
tasks. The English40 mean is 51.4292 points, not a full English41 mean. The
complete NanoBEIR13 mean is 43.5178 points. MIND alone is deferred.
The invocation took 17.59 minutes including setup and waits,
with actual process priority 10 throughout its runtime records.
[Raw records](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/results/dr151-quality-staticsim-float32.jsonl)
and [coverage summary](benchmarks/baseline/dr151_quality_staticsim_20261101.json).
Six unique configurations are complete. Twenty-eight static configurations
plus MiniLM remain. The uniform static scenario is now 9.98 hours,
with endpoints 8.11 and 23.83 hours.
MiniLM, classifiers, search and required same-method confirmations are additional.
These checkpoints use separate method cohorts and establish no controlled ranking.

## Complete local MiniLM and ParaNMT quality

MiniLM-L6-v2 and plain-mean fse/paranmt-300 have completed all 40 local English tasks and all 13 NanoBEIR tasks with unmodified MTEB 2.26.25. MIND remains separately deferred, so these are not official full 41-task English scores. Their quality summaries share the same recorded setup. Native scores are multiplied by 100 in this table.

| Model | English 40-task mean, MIND excluded | NanoBEIR 13-task mean | Source |
|---|---:|---:|---|
| all-MiniLM-L6-v2 | 59.8863 | 56.2214 | [Full task summary](benchmarks/baseline/dr151_quality_minilm_20261101.json) |
| fse/paranmt-300, plain mean | 50.6940 | 39.3910 | [Full task summary](benchmarks/baseline/dr151_quality_paranmt_20261101.json) |

ParaNMT loads the pinned fse Hub KeyedVectors through `KeyedVectors.load(mmap='r')`, `fse.gensim.from_gensim` and the normal 2.0 Encoder path. Its recorded encoder uses `fse_words@1` and `normalize@1`; no SIF fit is applied. The [artifact receipt](benchmarks/baseline/dr151_classic_fitted_artifacts_20261101.json) binds its source revision and fingerprint. Other model cohorts retain their own setup identities and do not form a single controlled ranking.

Raw quality `seconds` sums encode calls, not complete task evaluation. Earlier intermediate reports mislabelled that field as task elapsed; those duration scenarios are withdrawn. The [MiniLM elapsed report](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/dr151_quality_minilm_time_20261101.json) and [ParaNMT elapsed report](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/ae79c80c5736706a1e39df2f69a18e5801ae82d3/benchmarks/baseline/dr151_quality_paranmt_time_20261101.json) preserve invocation boundaries, overlapping retries, waits and calendar gaps explicitly. These completion-time diagnostics are not speed evidence.


## GloVe SIF-10 partial local configuration

The [GloVe SIF-10 float32 summary](benchmarks/baseline/dr151_quality_glove_20261101.json) now covers all forty non-deferred English tasks with a mean of 49.7864 points. MIND remains deferred; the official English41 mean is null. NanoBEIR is still pending in this raw snapshot, so the 53-task local configuration is incomplete and no NanoBEIR mean is reported. The committed fitted artifact receipt binds the seed-zero WikiText-103 training fit and encoder fingerprint. This does not establish a matched SIF improvement or CPU speed.
