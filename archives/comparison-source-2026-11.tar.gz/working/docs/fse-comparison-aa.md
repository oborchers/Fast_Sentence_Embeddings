# DR-151 historical A/A audit, withdrawn speed evidence

**Speed publication status:** All Apple M1 Pro timing results are **withdrawn: M1**. All Pod 2 timing cells and all Pod 3 small-input panel/scaling cells are invalid for speed publication, including cells that previously passed A/A. Earlier eligibility labels are superseded. MTEB, NanoBEIR, STS, numerical recall and classifier accuracy remain unchanged and valid. Current comparison speed evidence is limited to the large-input Pod 3 showcase and Pod 4c table cells that pass every gate.

The complete historical per-cell A/A audit is preserved in the [withdrawn publication snapshot](https://github.com/oborchers/Fast_Sentence_Embeddings/blob/52b575699fcc5dfec13b8c7b8bbbfbf41e359afc/benchmarks/baseline/results/dr151-withdrawn-publication-20261101/docs/fse-comparison-aa.md). Its diagnostic bands do not authorize a rate, speedup or cost claim. No old speed table is reproduced here.
