---
library_name: "fse"
license: "other"
base_model: "fse/word2vec-google-news-300"
base_model_relation: "quantized"
language:
- "en"
pipeline_tag: "feature-extraction"
tags:
- "fse"
- "static-embeddings"
- "sentence-embeddings"
- "gensim"
- "word2vec"
- "word-embeddings"
license_name: "word2vec-google-news-research-only"
license_link: "https://code.google.com/archive/p/word2vec/"
---

# fse/word2vec-google-news-300-raw-int8

A static embedding model for fse: the mean of the token rows of a text, normalized to unit length.

## Model

- rows (vocabulary): 3000000
- dimensions of the table: 300 (int8)
- table stored by `quantize_rows@1` from the float32 table `xxh3-128:82ba9ce3dc01894279dccda982d3ae83`
- tokenizer: `fse_words@1`
- steps per row: normalize@1
- fingerprint: `xxh3-128:1535b380564e1ce4a7dbd553eaddec01`

## Usage

This model requires fse 2.0 or later.

```
pip install "fse>=2.0"
```

```python
import fse

encoder = fse.Encoder.from_pretrained("fse/word2vec-google-news-300-raw-int8")
vectors = encoder.encode(["A sentence."])
```

## Source and license

Converted from the gensim model fse/word2vec-google-news-300 at revision `4274c2efa75c99a64e3f83eabfc5b34d1acabe70`.

The vectors fse computes are those of the quantized table: on the cpu backend bit for bit as its reference computes them, not those of the model before quantization. How close they come to it is measured, not promised by this file.

License: other. The license of the source model applies to its use.

## About fse

Made with [fse](https://github.com/oborchers/Fast_Sentence_Embeddings), fast sentence embeddings.

<!-- fse-classic-card@1 -->

## Choosing a method and storage format

On the 1,379 STS-B test pairs, raw float32 scored 61.54132 Pearson x100 and SIF-10 float32 scored 70.88642. Use raw for a plain mean of the source vectors. Use SIF-10 to apply the fixed frequency weighting and training-corpus component removal measured here. Evaluate the choice on your own data.

Use float32 to retain the prepared table without storage rounding. Use float16 or int8 when the measured size reduction and neighbour changes below meet your needs. fse computes all three in float32.

| This model | Measured value |
|---|---:|
| Model file bytes | 977259798 |
| STS-B Pearson x100 | 61.54394 |
| Difference from same-method float32, points | +0.00262 |
| Recall@10 against same-method float32 | 0.996483 |
| Default tokenizer Pearson x100 | 61.54394 |

The controlled STS-B comparison uses the 1.x notebook's NLTK preprocessing through an external-tokenizer view of this same table. The default-tokenizer row uses the saved `fse_words@1` tokenizer on raw text. Recall@10 compares each of the 2,758 STS-B sentence rows against all other rows, excludes self, and resolves equal similarities by row index. No load-time or speed claim is made.

## Source terms and attribution

The [original word2vec project](https://code.google.com/archive/p/word2vec/) states that the project is 'released for research purposes only'. The card therefore uses `license: other`. Apache-2.0 covers the word2vec code, not these pretrained vectors. No broader permission is asserted here.
