# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): unabhängige Ergebnisprüfung Stufe 1

Stufe 1 ist als gültige Ablation angenommen. Die Normpartition erklärt einen großen Teil des MLX-Verlusts auf MRL1024/MASSIVE. Ein CPU-Sieg ist damit nicht erreicht.

## Selbst nachgeprüft

- SHA256 aller drei freigegebenen Runnerdateien sowie Bericht, Zusammenfassung und Offline-Parser stimmen mit dem Abschlusscheckpoint überein.
- Den vorhandenen Offline-Parser vollständig im Speicher ausgeführt. Ausschließlich seine Dateiausgabe durch einen Vergleich ersetzt. Das Ergebnis stimmt exakt mit der gesamten gespeicherten Zusammenfassung überein. Keine Datei, kein Modell und keine Messung wurden dadurch erzeugt.
- Alle 3840 akzeptierten Passdauern und Bitvalidierungen stimmen mit den rohen Seitenminima überein. 64 vollständige Blöcke, je Zelle 16, jeweils fünf Pässe pro Seite. ABBA/BAAB und alternierende Backendfolge separat geprüft.
- Kein abgeschlossener Block wurde erneut gemessen. Die zwei verworfenen Blöcke haben exakt bestätigte endliche Laststopps. Ihre 62 validierten Pässe bleiben verworfen. Akzeptierte Pass- und Seitenguards liegen strikt unter fünf.
- Alle zwölf Speicherresultate bestehen volle Bits, Fallbackfreiheit und beide nachträglichen Diagnosegrenzen. Beide Abbruchzeugen bestehen Condition-Lockhandshake, KeyboardInterrupt und Quieszenz im angegebenen engen Umfang.
- Die historische Buchführung stimmt per Hash. Tatsächlicher Verbrauch Stufe 1: 241.51859470899944 s. Gesamt: 837.7134202509988 s, ohne Cap. Keine Zeitgrenze wieder eingeführt.
- Worktree sauber auf ef4d6a7bb33ac65a711458365312a5c0faf0b96a. bench.lock bei Prüfung abwesend. Finder-Freigabe ist durch die Workerbelege dokumentiert, von mir nicht als eigene Finder-Aktion ausgegeben.

## Urteil und verbleibende Unsicherheit

MASSIVE Norm: MLX B/A beträgt gepaart 0.5040713740011795, Spanne 0.4485 bis 0.5558. Alle Paare zeigen einen großen Gewinn. CPU10 B/A 1.0023 und CPU12 B/A 0.9993 zeigen keinen entsprechenden Gewinn. Die Daten erlauben keine Zerlegung des MLX-Gewinns in Dispatch, Kopie, Queue und Belegung.

MLX-B/CPU12-B beträgt 1.3151925127000865. Zum Gleichstand wären weitere 23.9655 Prozent der jetzigen MLX-Zeit einzusparen. Der Zeitaufschlag von 31.5193 Prozent und die notwendige Einsparung von 23.9655 Prozent haben verschiedene Nenner.

MASSIVE Raw: MLX-B/CPU12-B 1.6042661551732922, notwendige Einsparung 37.6662 Prozent. Die Raw-B-Seite ist eine No-op-Kontrolle. Ihr Medianvorteil ist kein kausaler Patchgewinn. WikiText zeigt große MLX-A/A-Spannen. Kleine dortige Unterschiede gelten nicht als belastbarer Effekt.

MASSIVE Norm: erster Prozesspeak steigt um 211795968 Bytes (201.984375 MiB). Workspacekapazität ist kein vollständiger Window-Speichervertrag. Die Diagnose erlaubt daher keine ungeprüfte Produktionsänderung oder Zusage für Streams und andere Shapes.

## Fortsetzung

Stufe 2 darf ausschließlich als Scratch-Plan und Runner ausgearbeitet werden. Vor dem Modelllauf prüft fse-codex den Runner. Hypothese: wiederholte Eingabeimporte und kleine Dummyarrays vermeiden. Der Plan muss ursprünglichen Pfad, Stufe-1-Partition und zusätzliche Stufe-2-Änderung eindeutig trennen. Kein stiller Vorteil durch eine langsamere CPU-Vergleichsseite.

Die Chance eines CPU-Siegs bleibt eine Hypothese. Die bisherigen Daten schließen eine gemeinsame Verringerung der Übergabe- und Taskkosten nicht aus. Sie belegen weder, dass zwei Importe allein die restlichen 24 bis 38 Prozent sparen, noch dass eine spätere Fusion gewinnen wird. Vor dem nächsten Lauf muss der Worker für diesen Rest eine konkrete Kostenrechnung und eine Stoppregel vorlegen. Größere Pack- oder Metal-Änderungen gehören nicht in Stufe 2.

Zero-Copy darf nur bei tatsächlich belegter Speicherübernahme so heißen. Keine verdeckte Kopie über einen Fallback von asarray, keine Mutation noch benutzter Puffer. Besitzer, Lebensdauer, Wiederverwendung und Abbruch müssen geprüft sein. Zahlenvertrag und Fallbackprüfung unverändert.

Kein src-Edit, Commit, Push oder Merge. Kein Linear-Zugriff, auch nicht lesend. PR #176 (2.0: DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen)) bleibt Draft.

Fertig: unabhängige Ergebnisprüfung und Annahme der Stufe-1-Evidenz.
Offen: Stufe-2-Plan und Runnerprüfung vor Ausführung.
Von dir: nichts. Olivers Go gilt weiterhin.

Prüfzeitpunkt: 2026-10-31T17:37:44.533192+01:00
