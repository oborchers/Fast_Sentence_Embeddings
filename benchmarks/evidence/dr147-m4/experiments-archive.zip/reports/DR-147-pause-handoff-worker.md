# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): Worker-Pausenübergabe

Stand: 2026-10-31T19:45:50.169947+01:00. Oliver hat ausdrücklich pausiert. Keine Fortsetzung bis zu seinem neuen Go.

## Sicherer Endzustand

Der letzte Messlauf war bereits vor dem Pausemarker durch einen endlichen Laststopp beendet. Tatsächlicher Stoppgrund: `load 5.03955078125 is not strictly below 5`. Dies war kein durch den Pauseguard ausgelöster Stopp. Bei der Pause lief nur noch die eigene Finderfreigabe. Keine neue Invocation oder Lastfortsetzung nach der Pause. Keine Prozesse für die Pause hart beendet.

Der zentrale Pausemarker `/Users/oliver.borchers/Desktop/Code/fse-m4-scratch/pause-local.marker` wurde vom Koordinator gesetzt und bleibt unverändert vorhanden. Eigener bench.lock über Finder nach exakter PID-/Tokenprüfung freigegeben. Unmittelbare und verzögerte Dublettenprüfungen sauber. Kein eigener Python-Messprozess im abschließenden Prozessstatus.

## Erhaltener Messstand

MRL1024, float32, volle Korpora, CPU10/12 A/B und MLX B/D. 16 feste ABBA/BAAB-Blöcke je Zelle, fünf Pässe je Seite. D baut auf B mit Originalimporten auf. Keine C-Kumulation.

| Zelle | gültige Blöcke | Soll | akzeptierte Zeitpässe |
|---|---:|---:|---:|
| WikiText Raw | 16 | 16 | 960 |
| WikiText Norm | 16 | 16 | 960 |
| MASSIVE Raw | 3 | 16 | 180 |
| MASSIVE Norm | 0 | 16 | 0 |

Insgesamt 35 vollständige Blöcke und 2100 akzeptierte Zeitpässe. Deren Rohjournale nochmals rein lesend auf volle Bits, keine Fallbacks und Last vor/nach Pass strikt unter fünf geprüft. Vier reale Pack-/Bit-/CPU-Fehler-/Lease-Audits, acht frische B/D-Speicherjobs und zwei echte Multi-Pack-Abbruchzeugen bestanden bereits vor Timing. Diese fertigen Jobs werden nicht wiederholt.

## Laststopps und verworfene Daten

| Root | tatsächlicher Stopp | aktive Sekunden |
|---|---|---:|
| run-4b6fbee1b9fe | load 5.16357421875 is not strictly below 5 | 46.2697462080032 |
| run-05904b4cfde7 | load 5.162109375 is not strictly below 5 | 16.049904082996363 |
| run-f36ad415762a | load 5.25341796875 is not strictly below 5 | 21.947201541996037 |
| run-45ce18886774 | load 5.03955078125 is not strictly below 5 | 5.254779124996276 |

| Root / Zelle | unvollständiger Blockindex | verworfene Zeitpässe / volle Bitprüfungen |
|---|---:|---:|
| run-4b6fbee1b9fe / WikiText Norm | 7 | 18 / 18 |
| run-f36ad415762a / MASSIVE Raw | 3 | 48 / 48 |
| run-45ce18886774 / MASSIVE Raw | 3 | 42 / 42 |

Vier exakt bestätigte endliche Laststopps. Insgesamt 108 verworfene, vollständig bitvalidierte Zeitpässe ohne beobachteten Fallback. Der zweite Stopp lag im MASSIVE-Raw-Warmup und hatte keinen begonnenen Zeitblock. Ganze unvollständige Blöcke bleiben verworfen. Keine Auswahl nach Packfüllung oder Vorteil, keine Wiederholung vollständiger gültiger Blöcke. Alle Teilversuche bleiben erhalten.

## Echte Buchführung

Stufe 3 tatsächlich **89.52163095799187 Sekunden**. Aktueller globaler tatsächlicher Stand **1275.997860708987 Sekunden**. Historischer Matrixverbrauch **523.0340705840008 Sekunden** unverändert.

Der gemeinsame neue Ledger ist `/Users/oliver.borchers/Desktop/Code/fse-m4-scratch/budget.jsonl`. Historischer Übertrag 596.1948255419993 Sekunden. Alter `mlx-gate-budget.jsonl` unverändert. Keine Zeitcaps seit Olivers ausdrücklicher Entscheidung, Empfangsbeleg vom 31.10.2026 um 16:41:07 MEZ. Pause ist eine gesonderte ausdrückliche Anweisung und gilt unabhängig davon. Keine neue Messbuchung durch diese Cleanup-/Dateiauswertung.

## Letzte Root und spätere Wiederaufnahme

Letzte unverzweigte Root und einzige dokumentierte Resumequelle: `/Users/oliver.borchers/Desktop/fse-m4/dr147-stage3/run-45ce18886774`.

Der folgende Befehl dient nur der Dokumentation. Er wurde nach der Pause nicht ausgeführt. Erst nach Olivers ausdrücklicher Fortsetzung und koordinierter Freigabe des weiterhin vorhandenen Pausemarkers erneut frische Guards prüfen. Jetzt keine Anpassung für Resume.

Arbeitsverzeichnis: `/Users/oliver.borchers/Desktop/Code/fse-m4-scratch/dr147-mlx-m4`.

`.venv/bin/python /Users/oliver.borchers/Desktop/fse-m4/dr147-stage3/dr147-stage3.py run --resume /Users/oliver.borchers/Desktop/fse-m4/dr147-stage3/run-45ce18886774`

Der gespeicherte maschinelle Stopp ist lastbedingt und retryable. Das ist derzeit keine Autorisierung zur Wiederaufnahme. Oliver hat alle Lastfortsetzungen pausiert. Der Runner übernimmt die gültigen Präfixe und fertigen Jobs erst bei einer später erlaubten Invocation.

## Exakt freigegebene, unveränderte Skripthashes

- dr147-stage3.py: `37fb27f4dbb3a740421062588e3b07beb024966657750edf38c210bfbcb4d57a`.
- dr147_stage3_pack.py: `c96ca336aa15a7a58fefb39faace09a38a924de600a2453d557cef34cf3d1c99`.
- dr147_stage3_control.py: `d637dc9b3dc6f9553a8d217efdae23f4a0ee504563f9681f369f77ddfbd4984a`.
- dr147_stage3_checks.py: `912c8d035b74dd1d7f07983e769e39f6624c900033033ddb6d6cf594f4195c5a`.

Alle Skripte liegen unter `/Users/oliver.borchers/Desktop/fse-m4/dr147-stage3/`. Git sauber auf `ef4d6a7bb33ac65a711458365312a5c0faf0b96a`. Native Identität in den Jobbelegen `xxh3-128:2d9d0a93859e347a5220443fab372260`. Keine src-/Repo-Änderung, kein Commit, Push oder Merge. Keinerlei Linear-Zugriff. PR #176 (2.0: DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen)) wurde nicht geändert und bleibt gemäß Auftrag Draft.

## Prozess-, Lock- und Dublettenbelege

Letzter Owner PID 8115, Token `3ef7dfff9f764512b6f923021a359e39`. Letzter über das Aufsichtsjournal identifizierter Kindprozess PID 8134. Beide bei der Endkontrolle nicht mehr vorhanden. Keine eigenen Python-Prozesse mit den Stage1/2/3-Messskripten in ps gefunden. Unabhängige Python-Prozesse anderer Aufgaben sind nicht Teil dieser Aussage.

Finder verifizierte die letzte Freigabe und legte ausschließlich den eigenen Lockinhalt in `/Users/oliver.borchers/.Trash/owner 19.41.38.json`. Der Papierkorb wurde nicht geleert. Keine neuen Dubletten. Letzte verzögerte Kontrolle nach 122.67301201820374 Sekunden: dataless [], numbered [], Lock abwesend. Auch alle drei vorherigen eigenen terminalen Freigaben sind durch unmittelbare und verzögerte Prüfungen belegt.

- `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-pause-worker-status.json`: Zählungen, Ledger, tatsächliche Stopps, terminale PIDs und ps-Prüfumfang.
- `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage3-load-stop-1.json` bis `-4.json`: genaue Guardbelege.
- `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage3-lock-cleanup-4-immediate.json` und `DR-147-stage3-lock-cleanup-4-delayed.json`: letzte Finderfreigabe.
- Entsprechende Cleanupbelege 1 bis 3 im gleichen Ergebnisordner.
- `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage3-start-checkpoint.json`: Freigabehashes und Startbedingungen.
- `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage3-owner-fix-preflight.json`: korrigierter modellfreier Ownernachweis.

## Offen und nächster Schritt

MASSIVE Raw fehlen 13 vollständige Blöcke. MASSIVE Norm ist noch nicht als Zeitjob gestartet, dort fehlen alle 16. Kein vollständiges Stufe-3-Ergebnis und kein abschließender CPU-Vergleich für MASSIVE. Eine komplette Stufe-3-Summary existiert noch nicht. Der vorbereitete Offlineparser wird dafür erst nach einem späteren vollständigen Abschluss verwendet. Keine Stufe 4 implementiert oder gestartet. Keine Kontrollen mit anderen Dimensionen oder Modellen gestartet.

Nach ausdrücklichem Go von Oliver: Koordinator prüft die Fortsetzung, Markerfreigabe und frische Guards, danach nur fehlende Stufe-3-Blöcke aus obiger letzter Root. Nach vollständiger Stufe 3 Ergebnisprüfung, erst dann eine Entscheidung über Stufe 4. Jetzt keine Beobachtungsserie, kein Modelllauf und kein Startprompt.

Wichtig: Eine noch ausstehende alte Herdr-Laststoppmeldung wurde automatisch wegen der inzwischen geltenden Pause abgelehnt. Sie wurde nicht erneut gesendet. Stattdessen folgt ausschließlich die ausdrücklich angeforderte Pausenbestätigung. Dies blockiert weder Cleanup noch Handoff.

Dies ist die Worker-Zulieferung. Die zentrale Datei `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-pause-handoff.md` schreibt laut letzter Anweisung der Root-Koordinator. Ihren aktuellen Inhalt habe ich nicht geprüft.

Fertig: sichere Pause, Prozesse beendet, eigener Lock freigegeben, verzögerte Dublettenprüfung und Worker-Übergabe.
Offen: Stufe 3 unvollständig, weitere Ergebnis- und Fortsetzungsprüfung.
Von dir: ausdrückliches neues Go von Oliver. Bis dahin untätig.
