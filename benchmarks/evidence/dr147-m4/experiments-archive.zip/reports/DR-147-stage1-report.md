# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): Stufe 1

## Ergebnis zuerst

Das Speicherbudget erklärt einen großen Teil des MLX-Normverlusts auf MRL1024/MASSIVE. Norm mit Raw-Partition senkt den absoluten MLX-Median von **94,321 auf 47,953 ms**. Der Median der gepaarten B/A-Quotienten beträgt **0,5041**, die ganze Spanne **0,4485 bis 0,5558**. Alle 32 Vergleiche zeigen damit einen deutlichen Gewinn. Die Normarithmetik, der eigene Kernel und die vollständige Ausgabe bleiben unverändert.

Die CPU profitiert hier nicht entsprechend: Norm-B/A beträgt CPU10 **1,0023**, CPU12 **0,9993**. Damit erklärt die alte Taskkonstante den CPU-Normabstand nicht. Auf WikiText bleibt die tatsächliche Taskzahl unverändert. Dort zeigt der Patch keinen belastbaren Vorteil und MLX streut stark.

**Stufe 1 schlägt die CPU noch nicht.** MASSIVE Norm bleibt gepaart MLX-B/CPU10-B **1,2739**, MLX-B/CPU12-B **1,3152**. Auf Raw bleibt ebenfalls eine Lücke. Das widerlegt keinen möglichen späteren GPU-Entwurf. Stufe 2 ist weder implementiert noch gestartet. Die Ergebnisprüfung entscheidet die Fortsetzung.

Kosten: Die erste Prozess-RSS-Spitze von MASSIVE/MLX/Norm steigt von **1392803840 auf 1604599808 Bytes**, also rund **202 MiB**. Die beobachteten Workspaces bleiben klein. Alle zwölf Speicherjobs, beide Abbruchzeugen und alle 3840 akzeptierten zeitgemessenen Ausgaben bestehen ihre Prüfungen. Keine beobachteten Fallbacks.

## Auftrag, Zeitentscheidung und Umfang

Oliver hob alle 1800/900/300/200-Sekunden-Grenzen, Meldeschwellen und die etwa 30-Minuten-Faustregel für diese Untersuchung ausdrücklich auf. Zentraler Empfangsbeleg: `DR-147-time-limit-removal.json`, **31.10.2026, 16:41:07 MEZ**. Keine Budgetgrenze löste einen Stopp aus. Der alte Ledger wurde nicht verändert. Der neue `budget.jsonl` übernimmt die tatsächlichen historischen 596,1948255419993 Sekunden und ergänzt den echten Verbrauch je Invocation.

Ausschließlich der freigegebene Scratch-Patch von `Pipeline._row_bytes`: bei Norm den Zuschlag `12*dim` abziehen. Keine Änderung an src, nativer Arithmetik, den 60 historischen Zellen oder gespeicherten Referenzarrays. Kein Commit, Push oder Merge. Der bestehende PR bleibt Draft. Keinerlei Linear-Zugriffe, auch nicht lesend.

Hardware: **M4 Pro mit 8P+4E, 48 GiB**, Default zwölf Worker. MRL1024, Float32-Tabelle und -Ausgabe, volle WikiText- beziehungsweise MASSIVE-Korpora. CPU10, CPU12 und MLX12. Alle vier CPU-Konfigurationen Original/Patch bleiben im Vergleich sichtbar.

## Protokoll und Begriffe

**A** ist der unveränderte Pfad. **B** ist der Normbudget-Patch. Bei Raw verändert B keine Partition und dient als No-op-Kontrolle. Plain-Seiten verwenden vollständig restaurierte Originalmethoden. Es gibt keine Tracingmarker in den Zeitmessungen.

Je Zelle **16 vollständige Blöcke**, abwechselnd ABBA/BAAB. Je Backend A1,B1,B2,A2 beziehungsweise B1,A1,A2,B2, fünf Pässe pro Seite. Seitenstatistik: Minimum der fünf Encode-Dauern. Die Backendfolge CPU10/CPU12/MLX kehrt sich pro Block um. Vollständige Bitprüfung und Fallbackdeltas nach jedem Pass außerhalb der Encode-Uhr.

B1/A1 und B2/A2 ergeben 32 Quotienten in **16 Clustern**, keine 32 unabhängigen Runden. Alle vollständigen gültigen Blöcke bleiben erhalten. A2/A1 und B2/B1 werden getrennt berichtet. Absolute Werte unten aggregieren die 32 Seitenminima einer festen Konfiguration. Quotienten entstehen zuerst innerhalb desselben Blocks und derselben Position. Ein Quotient der absoluten Mediane ist deshalb nicht identisch mit dem gepaarten Median.

Last: erster Wert der 1-Minuten-Last, strikt unter fünf vor/nach jedem Pass und jeder Seite. Nur exakt bestätigte endliche Lastabbrüche wurden wiederholt. Ganze unvollständige Blöcke bleiben verworfen. Kein Retry für numerische, Fallback-, Layout-, Speicher-, Abbruch-, Identitäts- oder Aufsichtsfehler. Es gibt keinen solchen Nichtlastfehler.

## Taskteilung und tatsächliche Starts

Bei MLX12 bestätigt: Raw 8328 Budgetbytes/Zeile und maximal 2686 Taskzeilen, Norm 20616 und maximal 1085. Verhältnis der Maximalzeilen: 2,4765. Das ist keine gemessene Startlatenz. Die tatsächlich geplanten Tasks und unbezeitigt beobachteten GPU-Starts sind getrennt erfasst.

| Zelle | CPU10 A/B Tasks | CPU12 A/B Tasks | MLX A/B Tasks und GPU-Starts |
|---|---:|---:|---:|
| WikiText Raw | 20 / 20 | 24 / 24 | 24 / 24 |
| WikiText Norm | 20 / 20 | 24 / 24 | 24 / 24 |
| MASSIVE Raw | 63 / 63 | 63 / 63 | 89 / 89 |
| MASSIVE Norm | 139 / 63 | 169 / 63 | 208 / 89 |

Die größere Normpartition ändert auf MASSIVE sowohl Taskzahl als auch Übergaben und GPU-Arbeitsverteilung. Der Versuch identifiziert diese Planungsänderung als wirksamen Hebel. Er trennt deren einzelne Kosten nicht nach Kopie, Dispatch, Queue oder Kernel-Auslastung.

## Absolute Zeiten und Durchsatz

| Zelle | feste Konfiguration | ms, Median (Minimum bis Maximum) | Texte/s, Median (Minimum bis Maximum) |
|---|---|---:|---:|
| WikiText Raw | cpu10:A | 8,582 (8,350 bis 9,390) | 623616 (569971 bis 640936) |
| WikiText Raw | cpu10:B | 8,520 (8,169 bis 8,897) | 628154 (601531 bis 655143) |
| WikiText Raw | cpu12:A | 7,491 (7,329 bis 8,528) | 714497 (627549 bis 730212) |
| WikiText Raw | cpu12:B | 7,576 (7,358 bis 9,255) | 706496 (578274 bis 727404) |
| WikiText Raw | mlx:A | 10,806 (7,724 bis 16,640) | 495280 (321643 bis 692905) |
| WikiText Raw | mlx:B | 11,132 (7,838 bis 15,742) | 480861 (339971 bis 682853) |
| WikiText Norm | cpu10:A | 8,935 (8,718 bis 9,482) | 598999 (564455 bis 613888) |
| WikiText Norm | cpu10:B | 8,962 (8,690 bis 9,841) | 597163 (543868 bis 615851) |
| WikiText Norm | cpu12:A | 7,888 (7,620 bis 8,478) | 678492 (631265 bis 702393) |
| WikiText Norm | cpu12:B | 7,779 (7,651 bis 9,546) | 688023 (560681 bis 699505) |
| WikiText Norm | mlx:A | 9,853 (8,255 bis 13,712) | 543166 (390315 bis 648321) |
| WikiText Norm | mlx:B | 10,034 (8,332 bis 14,829) | 533469 (360925 bis 642340) |
| MASSIVE Raw | cpu10:A | 30,369 (29,296 bis 34,065) | 4994494 (4452455 bis 5177368) |
| MASSIVE Raw | cpu10:B | 30,307 (29,115 bis 31,523) | 5004553 (4811541 bis 5209472) |
| MASSIVE Raw | cpu12:A | 29,501 (27,893 bis 30,722) | 5141259 (4936916 bis 5437765) |
| MASSIVE Raw | cpu12:B | 29,211 (27,852 bis 30,454) | 5192289 (4980368 bis 5445746) |
| MASSIVE Raw | mlx:A | 48,282 (43,859 bis 54,976) | 3141410 (2758926 bis 3458186) |
| MASSIVE Raw | mlx:B | 46,377 (43,376 bis 54,803) | 3270458 (2767633 bis 3496720) |
| MASSIVE Norm | cpu10:A | 37,138 (36,682 bis 38,026) | 4084118 (3988640 bis 4134886) |
| MASSIVE Norm | cpu10:B | 37,325 (36,754 bis 38,233) | 4063568 (3967066 bis 4126730) |
| MASSIVE Norm | cpu12:A | 36,070 (35,214 bis 36,797) | 4205033 (4121935 bis 4307177) |
| MASSIVE Norm | cpu12:B | 35,994 (34,921 bis 37,840) | 4213895 (4008250 bis 4343331) |
| MASSIVE Norm | mlx:A | 94,321 (88,979 bis 102,197) | 1608057 (1484134 bis 1704608) |
| MASSIVE Norm | mlx:B | 47,953 (42,373 bis 53,417) | 3162954 (2839440 bis 3579503) |

## Gepaarter Patcheffekt einschließlich CPU-Gegenprobe

B/A kleiner als eins bedeutet kürzere Zeit mit Patch. Die Raw-B-Seite ist eine No-op-Kontrolle, keine Runtimeoptimierung.

| Zelle | CPU10 B/A | CPU12 B/A | MLX B/A |
|---|---:|---:|---:|
| WikiText Raw | 0,9924 (0,9349 bis 1,0523) | 1,0074 (0,9564 bis 1,1548) | 1,0257 (0,4908 bis 1,4178) |
| WikiText Norm | 1,0030 (0,9409 bis 1,0840) | 1,0001 (0,9081 bis 1,1719) | 1,0711 (0,6076 bis 1,4388) |
| MASSIVE Raw | 1,0013 (0,8996 bis 1,0689) | 0,9982 (0,9527 bis 1,0629) | 0,9605 (0,8094 bis 1,1725) |
| MASSIVE Norm | 1,0023 (0,9721 bis 1,0295) | 0,9993 (0,9694 bis 1,0532) | 0,5041 (0,4485 bis 0,5558) |

MASSIVE Norm: Alle MLX-Paare sind schneller. CPU10/12 zeigen dagegen Medianquotienten nahe eins. Weniger CPU-Tasks allein beseitigen dort die Normarbeit nicht. Auf WikiText sowie in Raw streut die MLX-No-op-Kontrolle deutlich. Kleine dortige Differenzen werden nicht als Wirkung des Budgets ausgegeben.

## Vergleich mit allen festen CPU-Varianten

Jeweils MLX-Zeit/CPU-Zeit. Keine pro Paar ausgewählte günstige CPU-Minimumseite.

### MLX A

| Zelle | CPU10 A | CPU10 B | CPU12 A | CPU12 B |
|---|---:|---:|---:|---:|
| WikiText Raw | 1,2540 (0,8724 bis 1,9545) | 1,2447 (0,9053 bis 1,8877) | 1,4317 (1,0258 bis 2,0477) | 1,4377 (1,0040 bis 2,0946) |
| WikiText Norm | 1,1186 (0,9233 bis 1,5185) | 1,0847 (0,8778 bis 1,5128) | 1,2436 (1,0530 bis 1,7058) | 1,2326 (0,9782 bis 1,7810) |
| MASSIVE Raw | 1,5942 (1,3869 bis 1,8240) | 1,5984 (1,3915 bis 1,7905) | 1,6324 (1,4615 bis 1,9612) | 1,6635 (1,4743 bis 1,9317) |
| MASSIVE Norm | 2,5187 (2,3459 bis 2,7761) | 2,5341 (2,3866 bis 2,7338) | 2,6214 (2,4553 bis 2,8390) | 2,6074 (2,4156 bis 2,7984) |

### MLX B

| Zelle | CPU10 A | CPU10 B | CPU12 A | CPU12 B |
|---|---:|---:|---:|---:|
| WikiText Raw | 1,3061 (0,9228 bis 1,8515) | 1,2813 (0,9219 bis 1,8850) | 1,4525 (1,0050 bis 2,0143) | 1,4305 (1,0280 bis 2,0629) |
| WikiText Norm | 1,1183 (0,9227 bis 1,6620) | 1,1261 (0,9157 bis 1,6395) | 1,2641 (0,9828 bis 1,8791) | 1,2490 (0,9951 bis 1,8754) |
| MASSIVE Raw | 1,5576 (1,3361 bis 1,8257) | 1,5553 (1,3961 bis 1,8294) | 1,5783 (1,4402 bis 1,8911) | 1,6043 (1,4317 bis 1,8764) |
| MASSIVE Norm | 1,2866 (1,1157 bis 1,4471) | 1,2739 (1,1397 bis 1,4423) | 1,3294 (1,1636 bis 1,4872) | 1,3152 (1,1485 bis 1,5036) |

Die schnellste feste CPU-Konfiguration nach den absoluten Medianen ist auf MASSIVE CPU12-B. Auf WikiText Raw ist es CPU12-A, auf WikiText Norm CPU12-B. Alle Konfigurationen stehen oben. Kein einzelnes vorteilhaftes CPU-Paar wurde ausgewählt.

## A/A und B/B

| Zelle | Backend | A2/A1 | B2/B1 |
|---|---|---:|---:|
| WikiText Raw | cpu10 | 1,0051 (0,9660 bis 1,0457) | 0,9877 (0,9387 bis 1,0230) |
| WikiText Raw | cpu12 | 0,9895 (0,9435 bis 1,0412) | 0,9859 (0,8384 bis 1,0906) |
| WikiText Raw | mlx | 1,0885 (0,6538 bis 1,8644) | 0,9970 (0,5584 bis 1,5730) |
| WikiText Norm | cpu10 | 0,9840 (0,9483 bis 1,0150) | 0,9923 (0,9191 bis 1,0320) |
| WikiText Norm | cpu12 | 0,9809 (0,9231 bis 1,0335) | 0,9553 (0,8096 bis 1,0688) |
| WikiText Norm | mlx | 1,0238 (0,6392 bis 1,2991) | 1,0890 (0,6831 bis 1,5441) |
| MASSIVE Raw | cpu10 | 1,0222 (0,9363 bis 1,1348) | 1,0030 (0,9628 bis 1,0708) |
| MASSIVE Raw | cpu12 | 0,9985 (0,9272 bis 1,1014) | 0,9911 (0,9467 bis 1,0839) |
| MASSIVE Raw | mlx | 0,9918 (0,8620 bis 1,2102) | 0,9792 (0,8165 bis 1,0784) |
| MASSIVE Norm | cpu10 | 1,0001 (0,9730 bis 1,0159) | 1,0079 (0,9880 bis 1,0301) |
| MASSIVE Norm | cpu12 | 0,9991 (0,9822 bis 1,0138) | 1,0088 (0,9400 bis 1,0461) |
| MASSIVE Norm | mlx | 1,0107 (0,9599 bis 1,0631) | 1,0117 (0,8687 bis 1,1639) |

Insbesondere WikiText/MLX zeigt große A/A-Bereiche. Diese Werte bleiben vollständig erhalten. Sie rechtfertigen weder Paarselektion noch eine Behauptung kleiner kausaler Vorteile. Der MASSIVE-Normgewinn liegt hingegen in jedem der 32 Paare deutlich außerhalb von Gleichstand.

## Lasten, verworfene Blöcke und volle Bits

| Akzeptierte Zelle | kleinste Last | größte Last | vollständige Blöcke | validierte zeitgemessene Pässe |
|---|---:|---:|---:|---:|
| WikiText Raw | 3.38525390625 | 4.0556640625 | 16 | 960 |
| WikiText Norm | 3.38525390625 | 4.95556640625 | 16 | 960 |
| MASSIVE Raw | 3.400390625 | 4.80126953125 | 16 | 960 |
| MASSIVE Norm | 3.58203125 | 4.8798828125 | 16 | 960 |

| Versuch / Zelle | verworfener Blockindex | Passdauern / Bitvalidierungen darin | Stopp |
|---|---:|---:|---|
| dr147-stage1-d3b40d48f474 / WikiText Norm | 13 | 56 / 56 | load 5.02685546875 is not strictly below 5 |
| dr147-stage1-d81a86e61948 / MASSIVE Norm | 12 | 6 / 6 | load 5.5791015625 is not strictly below 5 |

Beide Lastabbrüche waren endlich und exakt im Guardjournal bestätigt. Es gingen keine gültigen Präfixe verloren. Fertige Jobs und vollständige Blöcke wurden nicht wiederholt. Der Offline-Replay prüfte alle **3840 akzeptierten Einzelpässe** gegen ihre rohen Minima, vollständigen Bitvalidierungen und Pass-/Seitenlasten. Die 62 Pässe der verworfenen Blöcke bleiben separat und wurden ebenfalls bitvalidiert. Es gab keinen beobachteten Fallback.

## Speicher, getrennt von den Zeitreihen

Zwölf frische Prozesse, jeweils ein voller Norm-Encode mit Original- oder Raw-Partition. Die Tabelle zeigt Bytes, damit keine Rundung einen Grenzwert versteckt.

| Korpus / Backend / Variante | Prozesspeak vor Workspace-Reader und Bits | Sicherheitspeak einschließlich Reader und Bits | beobachtete Workspacekapazität |
|---|---:|---:|---:|
| wikitext-cpu10-A | 348717056 | 370343936 | 2150152 |
| wikitext-cpu10-B | 346243072 | 367869952 | 2150152 |
| wikitext-cpu12-A | 347275264 | 368836608 | 2593934 |
| wikitext-cpu12-B | 347996160 | 369557504 | 2538840 |
| wikitext-mlx-A | 516882432 | 538394624 | 2487040 |
| wikitext-mlx-B | 517046272 | 538591232 | 2459096 |
| massive-cpu10-A | 906428416 | 1682718720 | 2745992 |
| massive-cpu10-B | 906412032 | 1682702336 | 3694592 |
| massive-cpu12-A | 906805248 | 1683030016 | 2801664 |
| massive-cpu12-B | 908673024 | 1684897792 | 4563780 |
| massive-mlx-A | 1392803840 | 2169028608 | 1972184 |
| massive-mlx-B | 1604599808 | 2380824576 | 3600184 |

Der erste RSS-Wert umfasst Prozessstart, Modell-/Pipelinevorbereitung und Encode. Der zweite umfasst zusätzlich Reader und vollständigen Referenzvergleich. Er ist kein weiterer Inferenzpeak. Die 512-MiB-Prüfung betrifft nur beobachtete native Workspacekapazitäten, nicht den vollständigen Windowvertrag. Die 8-GiB-RSS-Prüfung erfolgt nachträglich. Sie verhindert keine vorherige Spitze. Beide Diagnosegrenzen bestanden in allen Prozessen.

MASSIVE/MLX/B benötigt 202 MiB mehr ersten Prozesspeak als A. Die Workspacekapazität steigt nur von 1972184 auf 3600184 Bytes. Der Reader belegt damit keinen großen separaten Vektor-Normworkspace. Der Buffername `norm` bezeichnet einen Text-/Tokenizerpuffer. Der historische Zuschlag war bereits ein indirekter Schutz gegen größere Tasks und längere Pufferlebensdauer. Ein späteres Produkturteil muss deshalb auch Streams und andere Shapes prüfen.

## Abbruchzeugen und ihre Aussagegrenze

CPU12 und MLX12, MASSIVE Norm mit Raw-Partition. Beide Zeugen erreichten einen echten Runtime-Conditionwait. Der Observer übernahm dessen Lock erst nach dem Eintritt in `Condition.wait`. Ein eigener blockierter Arbeitspunkt hielt die älteste CPU-Arbeit beziehungsweise den GPU-Abschluss fest. SIGINT wurde im Signalhandler bestätigt, erst danach gab der Controller den Arbeitspunkt frei.

- cancel-cpu: KeyboardInterrupt bestätigt, Lockhandshakes wahr, Writer nach Exceptioncleanup [], Queuezustand None. Puffer blieben vom Snapshot nach Cleanup bis zum abschließenden Flush unverändert.
- cancel-mlx: KeyboardInterrupt bestätigt, Lockhandshakes wahr, Writer nach Exceptioncleanup [], Queuezustand True. Puffer blieben vom Snapshot nach Cleanup bis zum abschließenden Flush unverändert.

Der GPU-Zeuge heißt submitted-before-complete. Er behauptet nicht, die GPU sei zum Signalzeitpunkt noch beschäftigt. Die Prüfung belegt Quieszenz nach Exceptioncleanup und Stabilität vom Snapshot bis Flush. Sie liefert keine zusätzliche Zeitmessung und keine unbelegte Attribution am exakten Returnzeitpunkt.

## Was aus den historischen 0,2 ms folgt

Commit `40d9ee78c71f4f23ba61e7a837ade8fac7fab8d3`, 28.10.2026, verglich auf M1 Pro Runtime und Handloop bei Last 5 bis 6. Das war vor dem heutigen WordPiece-/CPU-Fusionspfad. Der Kommentar ist kein M4- oder device_rows-Messwert. Der spätere 12-Byte-Zuschlag blieb nach M1-Stream-RSS-Messungen erhalten. Bezug: [PR #123 (2.0: finished models only, training leaves the library)](https://github.com/oborchers/Fast_Sentence_Embeddings/pull/123). [Historischer Task-Kommentar im Commit](https://github.com/oborchers/Fast_Sentence_Embeddings/commit/40d9ee78c71f4f23ba61e7a837ade8fac7fab8d3).

Die neue Gegenprobe zeigt, warum `ZusatzTasks * 0,2 ms` keine Wandzeitrechnung ist. CPU10 verliert mit B 76 Tasks, CPU12 106 Tasks, ohne vergleichbaren Zeitgewinn. MLX verliert 119 Tasks und gewinnt absolut etwa 46,368 ms. Aufgaben laufen parallel, Partitionen beeinflussen mehrere Kosten und die historischen Voraussetzungen sind andere. Auch 46,368/119 ist deshalb keine neu gemessene Launchlatenz.

Auf MASSIVE liegt Norm mit B absolut ungefähr auf Raw-Niveau: 47,953 ms gegen Raw-B 46,377 ms. Das ist ein Vergleich getrennter Zellen und keine zweite kontrollierte Normarithmetik-Ablation. Er stützt die enge Aussage, dass der zusätzliche MLX-Normverlust dieser Konfiguration überwiegend an der Taskplanung hing. Er beweist keinen allgemeinen Anteil für andere Dimensionen oder Korpora.

## Buchführung, Provenienz und Lockfreigabe

Aktive Stufe-1-Invocations zusammen: **241.518594708999444 Sekunden**. Neuer tatsächlicher Gesamtstand: **837.713420250998752 Sekunden**, ohne Cap. Historischer Matrixverbrauch unverändert **523,0340705840008 Sekunden**. Eintrittswarten und Finder-Synchronisationspausen sind keine aktiven Messinvocations. Reine anschließende Dokumentationsarbeit ist davon getrennt.

| Versuch | aktive Sekunden | Ergebnis |
|---|---:|---|
| dr147-stage1-d3b40d48f474 | 53.947313624998060 | incomplete |
| dr147-stage1-d81a86e61948 | 161.979450916998758 | incomplete |
| dr147-stage1-2ee5cf67c15f | 25.591830167002627 | complete |

Gefrorener HEAD `ef4d6a7bb33ac65a711458365312a5c0faf0b96a`, native Identität `xxh3-128:2d9d0a93859e347a5220443fab372260`. Geprüfte Runner-Hashes:

- script_sha256: `eba55b15b3b29b458b82f9700509d68e1af4e226a005500986afabf8c10bd0ff`
- supervision_sha256: `a47212a90eadb6daad4316df4c371c7a1df55f2986ba6047b9179272048fa5a9`
- cancel_sha256: `944b6f6e30093272a2f529f9cb983529226e6fa1addccabb8f8d49dfacb2f1da`

Der eigene bench.lock wurde nach jeder terminalen Invocation nur nach PID-/Tokenprüfung über Finder freigegeben. Sofortige und verzögerte Dublettenprüfungen bestanden. Nach Abschluss ist kein eigener Lock vorhanden. Es gab keine Änderung der Services und keine konkurrierenden Tests oder Builds.

Reproduzierbare lokale Evidenz:

- Vollständige numerische Zusammenfassung samt Einzelquotienten: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage1-summary.json`.
- Reiner Parser bestehender Journale: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage1-offline-summary.py`.
- Startcheck und Hashcheckpoint: `DR-147-stage1-approved-start-check.json`, `DR-147-stage1-start-checkpoint.json` im Ergebnisordner.
- Je Versuch `DR-147-stage1-lock-cleanup-N-immediate.json` und `DR-147-stage1-lock-cleanup-N-delayed.json` im Ergebnisordner.
- Unveränderte Raw-Journale und Modelle folgen den ausdrücklich freigegebenen Runnerpfaden im vorhandenen Scratch. Ihre drei Wurzeln stehen vollständig in der JSON-Zusammenfassung. Keine Referenzarrays wurden kopiert oder in Git aufgenommen.

## Urteil und Übergabe nach Stufe 1

**Die Speicherbudget-Hypothese ist für MRL1024/MASSIVE/Norm klar bestätigt.** Die Raw-Partition halbiert die MLX-Zeit mit unveränderten Ergebnissen, jedoch für mehr Prozessspeicher. Die CPU-Gegenprobe bestätigt keinen entsprechenden Taskbudgetgewinn. WikiText liefert keine belastbare Budgetbeschleunigung.

**MLX schlägt die CPU in diesen Stufe-1-Vergleichen noch nicht.** Nach dem Patch bleiben auf MASSIVE ungefähr 27,4 Prozent gepaarter Zeitaufschlag gegenüber CPU10-B und 31,5 Prozent gegenüber CPU12-B. Bei Raw ist die Lücke größer. Das ist kein Ausschluss aller GPU-Fusionen und noch keine Grundlage, MLX endgültig zu entfernen.

Empfehlung: Dieses Ergebnis unabhängig prüfen. Danach ist Stufe 2 als nächste isolierte Eingabe-/Übergabeprobe plausibel. Die größere Stufe 3 könnte weitere Starts amortisieren. Ob diese Schritte die verbleibende Lücke schließen, ist ungemessen. Keine solche Stufe wurde implementiert oder gestartet. Eine Produktionsänderung am Budget wäre gesonderte Arbeit mit Speicher-/Streamingprüfung. Die MLX-Policyentscheidung bleibt bei Oliver.

Fertig: Stufe 1, vollständiger Offline-Abgleich und eigene terminale Finder-Lockfreigabe.
Offen: Ergebnisprüfung durch fse-codex und Entscheidung über die nächste Stufe.
Von dir: kein Handeln zum Bewahren des Checkpoints. Fortsetzung erst nach dem vereinbarten Inspektions-Prompt.
