# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): Stufe 2

## Ergebnis zuerst

Die öffentliche MLX-API übernimmt unsere echten Taskarrays ohne Hostkopie. Alle vier Alias-, Inhalts- und Lebensdauerprüfungen bestehen. Der getestete Importwechsel macht MLX jedoch nicht schneller. Die gepaarten C/B-Mediane liegen für WikiText Raw/Norm bei **1,0373/1,1080**, für MASSIVE Raw/Norm bei **1,0350/1,0628**. Jede Paarspanne enthält Werte unter und über eins.

**Kein CPU-Sieg durch Stufe 2.** Auf MASSIVE liegt C gegenüber CPU12-B bei Raw **1,7803**, Norm **1,4006**. Gegen CPU10-B sind es **1,7190** und **1,3614**. Alle MASSIVE-Paare dieser Vergleiche sind langsamer. Auf WikiText streut MLX stark. Auch dort zeigt C keinen stabilen Sieg gegen beide CPU-Konfigurationen.

Der starke Normgewinn aus Stufe 1 bleibt in der getrennten A/B-Kontrolle erhalten: MASSIVE MLX B/A **0,5103**. Der zusätzliche C-Importpfad ist daher kein belegter Rettungsweg. Dieses Urteil gilt für den getesteten Python-Proxy samt Übernahmeprüfungen, nicht für jede denkbare native Implementierung von asarray.

Alle **64 vollständigen Blöcke und 5120 akzeptierten Zeitpässe** bestehen die volle Bitprüfung ohne beobachteten Fallback. Sieben endliche Laststopps hinterlassen **264 weitere bitvalidierte, vollständig verworfene Zeitpässe**. Keine Nichtlastfehler. Die acht Speicherjobs und beide Abbruchzeugen bestehen. Der eigene Lock ist über Finder freigegeben, einschließlich verzögerter Dublettenprüfung.

## Abgeschlossene Stufe 1 bleibt eigenständig

Der angenommene Stufe-1-Bericht ist bytegleich gesichert unter `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage1-report.md`. SHA256: `398631d716d1f1bed1c3a96b49c5d79d59b3b41307ecff5bc9a7acff9f67744f`. Seine damaligen Fortsetzungs- und Buchführungsstände sind historische Phasenstände. Der versiegelte Forschungsbericht und die ursprünglichen 60 Zellen bleiben unverändert.

## Hypothese und unveränderte Teile

**A:** Originalpartition und Originalimporte. **B:** Raw-Partition auch für Norm, Originalimporte. **C:** dieselbe Raw-Partition wie B, zwei echte öffentliche `mx.asarray(host, copy=False)` je Task und drei vorab erzeugte unveränderliche Dummyarrays. Kein stiller Kopier- oder Stagingersatz. Kernel, Zahlenfolge, Bounds, Gruppierung, Rückkopie in den Worker und Zeilenvertrag bleiben gleich.

Je vollem MASSIVE-Aufruf bleiben **89 Kernelstarts**. Wiederholte Taskimporte sinken von **445 auf 178**, dazu drei Dummy-Erzeugungen einmal vor der Encode-Uhr. Auf WikiText bleiben 24 Starts, entsprechend 120 gegenüber 48 wiederholten Importen. Zwei reale Inputs pro Task wurden tatsächlich übernommen. Das bedeutet weder null Speicherverkehr noch eine gemessene physische GPU-Transferzeit von null.

Die Variante C enthält einen Python-Proxy und unveränderte Sicherheitsassertionen im Übernahmepfad. Pointer-, Hash- und Weakref-Protokolle laufen ausschließlich in den separaten Vorprüfungen. Die gemeinsame Wirkung der Importvermeidung und dieses Proxys wurde gemessen. Ihre Einzelkosten sind nicht identifiziert. Es wurde nichts nachträglich abgezogen oder angepasst.

Vorabrestlücke aus Stufe 1 gegen CPU12-B: Norm 23,9655 Prozent, Raw 37,6662 Prozent notwendige MLX-Einsparung. Die kleinen logischen Eingaben, rund 9,5 MB pro MASSIVE-Aufruf, bewiesen keine solche Einsparung. Die Annahme 273 GB/s ist keine gemessene nachhaltige Bandbreite. Das Laufzeitexperiment bestätigt keinen Importgewinn dieser Größenordnung.

## Protokoll und faire Anker

MRL1024, Float32, vollständige Korpora mit 5352 beziehungsweise 151674 Texten. M4 Pro **8P+4E**, 48 GiB. CPU10, CPU12 und MLX mit zwölf Workern. Je Zelle 16 feste vollständige ABBA/BAAB-Blöcke mit fünf Pässen je Seite. Seitenwert ist das Minimum dieser fünf Encode-Zeiten.

Unterblöcke: CPU10 A/B, MLX A/B, CPU12 A/B und MLX B/C. Ihre Reihenfolge kehrt sich pro Runde um. Innerhalb A/B: A1,B1,B2,A2 beziehungsweise B1,A1,A2,B2. Innerhalb B/C entsprechend B1,C1,C2,B2 beziehungsweise C1,B1,B2,C2. **C/B verwendet ausschließlich seinen eigenen B/C-Anker.** Der B-Anker aus MLX A/B wird nicht nachträglich eingesetzt.

32 Quotienten je Vergleich liegen in 16 Rundenclustern. Sie sind keine 32 unabhängigen Runden. Absolute Tabellen aggregieren 32 Seitenminima einer festen Konfiguration. Quotienten werden zuerst je Runde und Seitenposition berechnet. Kein Quotient absoluter Mediane ersetzt sie. Keine Paarselektion oder Aufstockung nach Ergebnissen. CPU10/12 A und B stehen vollständig nebeneinander.

Last1 vor und nach jedem Pass sowie jeder Seite strikt unter fünf. Vollständige Bits und Fallbackdeltas außerhalb der Encode-Uhr. Kein Tracing und keine daraus abgeleitete Wandzeitattribution. Nur bestätigte endliche Lastabbrüche wurden fortgesetzt. Ganze unvollständige Runden bleiben verworfen, gültige Präfixe und fertige Jobs unverändert. Alle Originalmethoden werden per finally restauriert.

## Absolute Zeiten und Durchsatz

Angabe jeweils Median (Minimum bis Maximum). Beide MLX-B-Anker bleiben getrennt.

| Zelle | feste Konfiguration | ms | Texte/s |
|---|---|---:|---:|
| WikiText Raw | cpu10:A | 8,650 (8,421 bis 9,413) | 618723 (568593 bis 635551) |
| WikiText Raw | cpu10:B | 8,702 (8,438 bis 9,926) | 615063 (539215 bis 634289) |
| WikiText Raw | mlx_AB:A | 9,248 (7,749 bis 15,490) | 578752 (345520 bis 690647) |
| WikiText Raw | mlx_AB:B | 9,049 (8,192 bis 14,754) | 591495 (362752 bis 653304) |
| WikiText Raw | cpu12:A | 7,706 (7,387 bis 9,072) | 694550 (589974 bis 724471) |
| WikiText Raw | cpu12:B | 7,812 (7,404 bis 8,857) | 685081 (604276 bis 722897) |
| WikiText Raw | mlx_BC:B | 10,693 (7,790 bis 14,935) | 500589 (358350 bis 687016) |
| WikiText Raw | mlx_BC:C | 11,657 (8,012 bis 17,293) | 459142 (309485 bis 667977) |
| WikiText Norm | cpu10:A | 9,007 (8,768 bis 9,702) | 594237 (551641 bis 610433) |
| WikiText Norm | cpu10:B | 9,018 (8,732 bis 10,377) | 593502 (515731 bis 612930) |
| WikiText Norm | mlx_AB:A | 9,611 (7,835 bis 14,921) | 556889 (358690 bis 683085) |
| WikiText Norm | mlx_AB:B | 9,503 (7,462 bis 14,644) | 563239 (365478 bis 717262) |
| WikiText Norm | cpu12:A | 8,054 (7,662 bis 9,144) | 664495 (585299 bis 698478) |
| WikiText Norm | cpu12:B | 8,085 (7,650 bis 9,849) | 662013 (543403 bis 699619) |
| WikiText Norm | mlx_BC:B | 10,075 (8,057 bis 15,899) | 531223 (336621 bis 664260) |
| WikiText Norm | mlx_BC:C | 11,417 (8,370 bis 16,281) | 468767 (328734 bis 639439) |
| MASSIVE Raw | cpu10:A | 30,090 (29,123 bis 31,392) | 5040625 (4831555 bis 5208041) |
| MASSIVE Raw | cpu10:B | 30,175 (29,269 bis 31,542) | 5026467 (4808573 bis 5182003) |
| MASSIVE Raw | mlx_AB:A | 48,316 (44,226 bis 54,182) | 3139229 (2799339 bis 3429524) |
| MASSIVE Raw | mlx_AB:B | 47,701 (43,996 bis 56,084) | 3179761 (2704396 bis 3447486) |
| MASSIVE Raw | cpu12:A | 29,497 (27,345 bis 30,894) | 5142033 (4909444 bis 5546580) |
| MASSIVE Raw | cpu12:B | 29,315 (27,482 bis 30,923) | 5173978 (4904939 bis 5519089) |
| MASSIVE Raw | mlx_BC:B | 50,075 (44,758 bis 56,606) | 3028921 (2679453 bis 3388726) |
| MASSIVE Raw | mlx_BC:C | 51,246 (47,304 bis 61,143) | 2959726 (2480632 bis 3206393) |
| MASSIVE Norm | cpu10:A | 37,326 (36,806 bis 38,169) | 4063455 (3973753 bis 4120951) |
| MASSIVE Norm | cpu10:B | 37,213 (36,631 bis 38,919) | 4075800 (3897179 bis 4140605) |
| MASSIVE Norm | mlx_AB:A | 95,752 (88,967 bis 102,515) | 1584043 (1479524 bis 1704831) |
| MASSIVE Norm | mlx_AB:B | 48,063 (43,812 bis 54,426) | 3155709 (2786787 bis 3461912) |
| MASSIVE Norm | cpu12:A | 36,170 (34,947 bis 37,817) | 4193385 (4010758 bis 4340146) |
| MASSIVE Norm | cpu12:B | 36,177 (34,897 bis 37,625) | 4192538 (4031234 bis 4346339) |
| MASSIVE Norm | mlx_BC:B | 47,806 (42,735 bis 52,694) | 3172898 (2878413 bis 3549154) |
| MASSIVE Norm | mlx_BC:C | 50,781 (43,541 bis 57,170) | 2986842 (2653046 bis 3483495) |

## Gepaarte Änderungen, alle Kontrollpfade

Kleiner als eins heißt kürzere Zeit mit der rechten Variante. Raw B/A ist eine No-op-Kontrolle.

| Zelle | CPU10 B/A | CPU12 B/A | MLX A/B: B/A | MLX B/C: C/B | C schneller, von 32 |
|---|---:|---:|---:|---:|---:|
| WikiText Raw | 1,0054 (0,9468 bis 1,1526) | 1,0057 (0,9022 bis 1,1068) | 0,9907 (0,6444 bis 1,4124) | 1,0373 (0,7007 bis 1,4995) | 11 |
| WikiText Norm | 1,0035 (0,9517 bis 1,1337) | 1,0059 (0,8929 bis 1,1614) | 1,0020 (0,6227 bis 1,7279) | 1,1080 (0,7782 bis 1,5870) | 8 |
| MASSIVE Raw | 1,0038 (0,9345 bis 1,0831) | 0,9958 (0,9008 bis 1,0695) | 0,9958 (0,8292 bis 1,1602) | 1,0350 (0,8743 bis 1,2581) | 9 |
| MASSIVE Norm | 0,9976 (0,9723 bis 1,0551) | 1,0035 (0,9349 bis 1,0477) | 0,5103 (0,4436 bis 0,5677) | 1,0628 (0,9099 bis 1,2270) | 6 |

Die C/B-Mediane sind in allen vier Zellen größer als eins. Wegen der Streuung wird daraus keine exakte kausale Proxy- oder API-Mehrzeit behauptet. Auf MASSIVE Norm ist der große B/A-Planungsgewinn erneut in jedem Paar sichtbar. CPU A/B zeigt keinen vergleichbaren Normgewinn.

## Vergleich jeder MLX-Variante mit allen festen CPU-Varianten

MLX-Zeit geteilt durch CPU-Zeit, gleiche Runde und Seitenposition. Keine Auswahl des günstigsten CPU-Werts pro Paar.

| Zelle | MLX-Anker:Variante | CPU10 A | CPU10 B | CPU12 A | CPU12 B |
|---|---|---:|---:|---:|---:|
| WikiText Raw | mlx_AB:A | 1,0706 (0,8998 bis 1,8083) | 1,0475 (0,8367 bis 1,8119) | 1,1941 (0,9244 bis 1,9977) | 1,1651 (0,9700 bis 1,9880) |
| WikiText Raw | mlx_AB:B | 1,0635 (0,8945 bis 1,6635) | 1,0576 (0,8511 bis 1,6906) | 1,1821 (1,0184 bis 1,9172) | 1,1793 (0,9869 bis 1,8909) |
| WikiText Raw | mlx_BC:B | 1,2183 (0,8873 bis 1,7560) | 1,1970 (0,8892 bis 1,7543) | 1,4224 (0,9829 bis 1,9994) | 1,3790 (0,9865 bis 1,9830) |
| WikiText Raw | mlx_BC:C | 1,3337 (0,9435 bis 2,0332) | 1,3115 (0,9044 bis 2,0313) | 1,5163 (1,0635 bis 2,3151) | 1,4530 (1,0579 bis 2,2961) |
| WikiText Norm | mlx_AB:A | 1,0539 (0,8369 bis 1,6777) | 1,0476 (0,7755 bis 1,6722) | 1,1874 (0,8739 bis 1,8980) | 1,1288 (0,8310 bis 1,9095) |
| WikiText Norm | mlx_AB:B | 1,0617 (0,8151 bis 1,5671) | 1,0544 (0,7190 bis 1,6277) | 1,1144 (0,9191 bis 1,8747) | 1,1628 (0,8602 bis 1,8900) |
| WikiText Norm | mlx_BC:B | 1,0854 (0,8359 bis 1,7837) | 1,0572 (0,8768 bis 1,7839) | 1,2577 (0,9149 bis 2,0368) | 1,2328 (0,9660 bis 1,9805) |
| WikiText Norm | mlx_BC:C | 1,2260 (0,9436 bis 1,7878) | 1,1738 (0,9260 bis 1,8149) | 1,3485 (0,9634 bis 2,0325) | 1,3187 (1,0160 bis 2,0538) |
| MASSIVE Raw | mlx_AB:A | 1,6012 (1,4648 bis 1,8268) | 1,5965 (1,4108 bis 1,7712) | 1,6366 (1,4833 bis 1,8506) | 1,6387 (1,4584 bis 1,9454) |
| MASSIVE Raw | mlx_AB:B | 1,5890 (1,4509 bis 1,8326) | 1,5811 (1,4343 bis 1,8878) | 1,6288 (1,4531 bis 1,8668) | 1,6130 (1,4922 bis 1,9545) |
| MASSIVE Raw | mlx_BC:B | 1,6461 (1,4760 bis 1,8913) | 1,6635 (1,4762 bis 1,9195) | 1,7002 (1,4970 bis 1,9605) | 1,6980 (1,5126 bis 1,9459) |
| MASSIVE Raw | mlx_BC:C | 1,7195 (1,5543 bis 2,0132) | 1,7190 (1,5523 bis 1,9975) | 1,7520 (1,5727 bis 2,0897) | 1,7803 (1,5492 bis 2,0808) |
| MASSIVE Norm | mlx_AB:A | 2,5607 (2,4036 bis 2,7146) | 2,5734 (2,3613 bis 2,7736) | 2,6646 (2,4157 bis 2,9118) | 2,6353 (2,4289 bis 2,8783) |
| MASSIVE Norm | mlx_AB:B | 1,2993 (1,1478 bis 1,4408) | 1,2881 (1,1776 bis 1,4818) | 1,3352 (1,1937 bis 1,5425) | 1,3263 (1,2119 bis 1,5451) |
| MASSIVE Norm | mlx_BC:B | 1,2879 (1,1300 bis 1,3964) | 1,2863 (1,1351 bis 1,4337) | 1,3270 (1,1766 bis 1,4967) | 1,3262 (1,1720 bis 1,4617) |
| MASSIVE Norm | mlx_BC:C | 1,3570 (1,1595 bis 1,5456) | 1,3614 (1,1542 bis 1,5565) | 1,3982 (1,2459 bis 1,5754) | 1,4006 (1,2088 bis 1,6230) |

## Noch notwendige Einsparung nach C

Rechnung aus dem Median der gepaarten Quotienten r: `100*(1-1/r)`. Das beschreibt die Lücke, nicht erreichbare Einsparung und keine Launchlatenz.

| Zelle | gegen CPU10 A | gegen CPU10 B | gegen CPU12 A | gegen CPU12 B |
|---|---:|---:|---:|---:|
| WikiText Raw | 25,0231 % | 23,7518 % | 34,0507 % | 31,1776 % |
| WikiText Norm | 18,4353 % | 14,8084 % | 25,8453 % | 24,1696 % |
| MASSIVE Raw | 41,8440 % | 41,8277 % | 42,9229 % | 43,8299 % |
| MASSIVE Norm | 26,3095 % | 26,5462 % | 28,4815 % | 28,6026 % |

Die schnellste feste CPU-Konfiguration nach absoluten Medianen ist CPU12-A auf beiden WikiText-Zellen und MASSIVE Norm. Auf MASSIVE Raw ist es CPU12-B. Das ist eine deskriptive Übersicht. Alle festen gepaarten Vergleichsreihen bleiben sichtbar. Der zusätzliche Importpfad schließt keine dieser Lücken.

## A/A, B/B und C/C vollständig

| Zelle | fester Anker | zweiter/erster Seitenwert |
|---|---|---:|
| WikiText Raw | cpu10:A2/A1 | 0,9858 (0,9259 bis 1,0379) |
| WikiText Raw | cpu10:B2/B1 | 0,9785 (0,8543 bis 1,0467) |
| WikiText Raw | mlx_AB:A2/A1 | 1,0250 (0,6288 bis 1,5156) |
| WikiText Raw | mlx_AB:B2/B1 | 1,1128 (0,7266 bis 1,7085) |
| WikiText Raw | cpu12:A2/A1 | 0,9692 (0,8547 bis 0,9987) |
| WikiText Raw | cpu12:B2/B1 | 0,9614 (0,8504 bis 1,0209) |
| WikiText Raw | mlx_BC:B2/B1 | 1,0775 (0,6276 bis 1,4663) |
| WikiText Raw | mlx_BC:C2/C1 | 1,1001 (0,8051 bis 1,6442) |
| WikiText Norm | cpu10:A2/A1 | 0,9895 (0,9135 bis 1,0307) |
| WikiText Norm | cpu10:B2/B1 | 0,9787 (0,8598 bis 1,0297) |
| WikiText Norm | mlx_AB:A2/A1 | 1,2083 (0,8447 bis 1,7865) |
| WikiText Norm | mlx_AB:B2/B1 | 1,0370 (0,8303 bis 1,8472) |
| WikiText Norm | cpu12:A2/A1 | 0,9309 (0,8613 bis 1,0084) |
| WikiText Norm | cpu12:B2/B1 | 0,9430 (0,8049 bis 1,0925) |
| WikiText Norm | mlx_BC:B2/B1 | 1,0418 (0,7205 bis 1,9435) |
| WikiText Norm | mlx_BC:C2/C1 | 0,9517 (0,6612 bis 1,5287) |
| MASSIVE Raw | cpu10:A2/A1 | 0,9996 (0,9550 bis 1,0489) |
| MASSIVE Raw | cpu10:B2/B1 | 0,9954 (0,9564 bis 1,0641) |
| MASSIVE Raw | mlx_AB:A2/A1 | 1,0170 (0,8728 bis 1,1127) |
| MASSIVE Raw | mlx_AB:B2/B1 | 0,9986 (0,8524 bis 1,2513) |
| MASSIVE Raw | cpu12:A2/A1 | 0,9988 (0,9515 bis 1,0739) |
| MASSIVE Raw | cpu12:B2/B1 | 0,9811 (0,9316 bis 1,0555) |
| MASSIVE Raw | mlx_BC:B2/B1 | 0,9491 (0,8275 bis 1,0933) |
| MASSIVE Raw | mlx_BC:C2/C1 | 0,9828 (0,8892 bis 1,1544) |
| MASSIVE Norm | cpu10:A2/A1 | 1,0043 (0,9677 bis 1,0228) |
| MASSIVE Norm | cpu10:B2/B1 | 1,0020 (0,9702 bis 1,0178) |
| MASSIVE Norm | mlx_AB:A2/A1 | 1,0029 (0,9353 bis 1,0685) |
| MASSIVE Norm | mlx_AB:B2/B1 | 1,0317 (0,8837 bis 1,1793) |
| MASSIVE Norm | cpu12:A2/A1 | 1,0010 (0,9609 bis 1,0316) |
| MASSIVE Norm | cpu12:B2/B1 | 1,0077 (0,9573 bis 1,0782) |
| MASSIVE Norm | mlx_BC:B2/B1 | 1,0208 (0,8451 bis 1,1991) |
| MASSIVE Norm | mlx_BC:C2/C1 | 1,0253 (0,9282 bis 1,1378) |

Die breiten WikiText-Spannen bleiben erhalten. Sie werden nicht zum Ausschluss ungünstiger Paare verwendet. Das Ergebnis ist kein Beleg, dass Speicherübernahme grundsätzlich nutzlos wäre. Es zeigt, dass der konkret geprüfte Pfad keinen belastbaren Ende-zu-Ende-Gewinn bringt.

## Tatsächliche öffentliche Übernahme

| Audit | ursprüngliche Tasks | reale Alias-/Inhaltsnachweise | alleiniger Owner gehalten und danach freigegeben | Bits |
|---|---:|---:|---|---|
| audit-wikitext-raw | 24 | 48 | ja | vollständig gleich |
| audit-wikitext-norm | 24 | 48 | ja | vollständig gleich |
| audit-massive-raw | 89 | 178 | ja | vollständig gleich |
| audit-massive-norm | 89 | 178 | ja | vollständig gleich |

Insgesamt 452 reale Arraynachweise. Jeweils Pointergleichheit, shares_memory, Dtype, Shape, Strides und unveränderte Inhalte bis Flush. Der separate Sole-owner-Zeuge entfernt übrige Task-/Hostreferenzen. MLX hält die Besitzer bis zur eigenen Freigabe. Der Inhaltszeuge hält bewusst starke Hostreferenzen und wird nicht als alleiniger Ownerbeweis verwendet. Keine öffentliche Importverweigerung.

Quellen für den öffentlichen Vertrag und dessen Implementierung: [MLX v0.32.4 asarray](https://github.com/ml-explore/mlx/blob/v0.32.4/python/src/ops.cpp#L1795-L1821), [CPU-Pufferübernahme und Owner](https://github.com/ml-explore/mlx/blob/v0.32.4/python/src/convert.cpp#L170-L216), [Metal make_buffer](https://github.com/ml-explore/mlx/blob/v0.32.4/mlx/backend/metal/allocator.cpp#L195-L218). Die tatsächliche Eignung unserer Inputs belegen die lokalen Audits, nicht allein diese Quellen.

## Speicher, jeweils frischer Prozess

| Zelle / Variante | Peak vor Reader und Bits, Bytes | Sicherheitspeak mit Reader und Bits, Bytes | native Workspacekapazität, Bytes | GPU-Starts |
|---|---:|---:|---:|---:|
| memory-wikitext-raw-B | 523665408 | 545177600 | 2584824 | 24 |
| memory-wikitext-raw-C | 521633792 | 543162368 | 2562136 | 24 |
| memory-wikitext-norm-B | 517931008 | 539475968 | 2459096 | 24 |
| memory-wikitext-norm-C | 515883008 | 537395200 | 2509728 | 24 |
| memory-massive-raw-B | 1690599424 | 2466824192 | 3446320 | 89 |
| memory-massive-raw-C | 1673936896 | 2450145280 | 3551648 | 89 |
| memory-massive-norm-B | 1572487168 | 2348695552 | 3591012 | 89 |
| memory-massive-norm-C | 1608695808 | 2384904192 | 3280476 | 89 |

Alle acht Prozesse bestehen die nachträglichen Prüfungen: Workspacekapazität höchstens 512 MiB, beobachteter Sicherheitspeak höchstens 8 GiB. Das ist kein vollständiger Windowvertrag und kein vorbeugendes RSS-Limit. Der erste Peak umfasst auch Start und Modellvorbereitung. Der zweite umfasst zusätzlich Reader und Bitvergleich. Einzelne Differenzen zwischen diesen frischen Prozessen sind kein wiederholter statistischer Speichergewinn.

## Abbruch und Besitzer

Beide C-Zeugen auf MASSIVE Raw und Norm erreichen einen echten Runtime-Conditionwait mit Lockhandshake. SIGINT-ACK kommt aus dem Signalhandler vor Freigabe des blockierten Arbeitspunkts. Alle beobachteten Eingabebesitzer leben vor dem kontrollierten Geräteabschluss. Nach Exceptioncleanup sind keine beobachteten Writer und Queuejobs übrig. Der Snapshot bleibt bis zum abschließenden Flush unverändert.

Die Aussage bleibt ausdrücklich Quieszenz nach Cleanup und Stabilität vom Snapshot bis Flush. Submitted-before-complete bedeutet nicht GPU-busy zum Signalzeitpunkt. Es gibt keine neue Aussage über den exakten Returnzeitpunkt oder eine kausale Wartezeit.

## Lasten, Stopps und verworfene Daten

| akzeptierte Zelle | kleinste Last1 | größte Last1 | vollständige Blöcke | akzeptierte Pässe |
|---|---:|---:|---:|---:|
| WikiText Raw | 3.13720703125 | 3.42333984375 | 16 | 1280 |
| WikiText Norm | 2.80078125 | 3.41552734375 | 16 | 1280 |
| MASSIVE Raw | 2.2548828125 | 4.96728515625 | 16 | 1280 |
| MASSIVE Norm | 2.2548828125 | 4.86865234375 | 16 | 1280 |

| Versuch | Zelle | verworfener Blockindex | Pässe / Bitvalidierungen | exakter Stopp |
|---|---|---:|---:|---|
| run-e9da9acd49cc | timing-wikitext-raw | 0 | 56 / 56 | load 5.5283203125 is not strictly below 5 |
| run-87ef5ff45420 | timing-massive-raw | 7 | 72 / 72 | load 5.455078125 is not strictly below 5 |
| run-0c286459b082 | timing-massive-raw | 7 | 34 / 34 | load 5.73974609375 is not strictly below 5 |
| run-92741d14e363 | timing-massive-raw | 9 | 54 / 54 | load 5.2353515625 is not strictly below 5 |
| run-da60135e3850 | timing-massive-raw | 10 | 26 / 26 | load 5.0068359375 is not strictly below 5 |
| run-cc5db65d96eb | timing-massive-raw | 15 | 19 / 19 | load 5.0498046875 is not strictly below 5 |
| run-cf63a0b2c9e1 | timing-massive-norm | 5 | 3 / 3 | load 5.03662109375 is not strictly below 5 |

Korrektur der ersten Kurzmeldung: Der erste Laststopp lag bereits im unvollständigen WikiText-Raw-Block 0 mit 56 bitvalidierten Zeitpässen. Er lag nicht vor allen Zeitpässen. Kein vollständiger Block wurde daraus akzeptiert. Diese 56 zählen zu den insgesamt 264 verworfenen Pässen. Alle rohen Stopps bleiben erhalten.

Der Offline-Replay berechnet alle gespeicherten absoluten Werte, Quotienten und Kontrollquotienten exakt aus den Rohpässen neu. Er prüft Reihenfolgen, eindeutige Passschlüssel, alle 5120 akzeptierten Bitvalidierungen, Lastgrenzen, unveränderte Ergebnis-Hashes und einmalig erhaltene gültige Blöcke. Alle gespeicherten Summaries stimmen exakt. Keine Modelle, Encodes oder neuen Messungen im Replay.

## Tatsächliche Buchführung und Provenienz

Stufe 2 insgesamt **348.76280949999637 Sekunden**, aktueller tatsächlicher Gesamtstand **1186.4762297509951 Sekunden**. Historischer Matrixverbrauch unverändert **523.0340705840008 Sekunden**. Keine Zeitcap. Eintrittswarten und Finder-Synchronisationspausen sind keine aktiven Messinvocations.

Oliver hob sämtliche alten Grenzen und die 30-Minuten-Faustregel auf. Empfangsbeleg: `DR-147-time-limit-removal.json`, **31.10.2026, 16:41:07 MEZ**. Der gemeinsame neue `budget.jsonl` übernimmt historisch 596.1948255419993 Sekunden und addiert den echten Verbrauch. Der alte `mlx-gate-budget.jsonl` bleibt bytegleich. Es gibt keinen versteckten alten Budgetvalidator. Fortschrittsstillstand und Owner-EOF bleiben Sicherheitswächter gegen Hänger, keine Mengenzeitgrenzen.

| Versuch | aktive Sekunden | Status |
|---|---:|---|
| run-e9da9acd49cc | 18.02940616699925 | incomplete |
| run-87ef5ff45420 | 114.91239862500152 | incomplete |
| run-0c286459b082 | 4.751112833000661 | incomplete |
| run-92741d14e363 | 21.43227658399701 | incomplete |
| run-da60135e3850 | 11.074289416999818 | incomplete |
| run-cc5db65d96eb | 39.69172266599708 | incomplete |
| run-cf63a0b2c9e1 | 50.77117262500178 | incomplete |
| run-c6f83ada81f2 | 88.10043058299925 | complete |

Gefrorener sauberer HEAD `ef4d6a7bb33ac65a711458365312a5c0faf0b96a`, fse-Baum `a9349076427d1811bcd85702f1dd7a9eed2639e0`. Alle Jobidentitäten bestätigen native `xxh3-128:2d9d0a93859e347a5220443fab372260`. Unveränderte freigegebene SHA256:

- Runner: `c8a80fbb589e8da57c1fb96fa47dbd969ad0ad48d573d7ea78f4988684090030`.
- Helper: `6dc9bc6800532483d635622c5148ed438707e1579f43ab8ecd90e177a95eed46`.

Nach jeder terminalen Invocation nur eigener Lock mit PID-/Tokenprüfung über Finder freigegeben. Sofortige und mindestens eine Minute verzögerte Dublettenprüfungen bestanden für alle acht Invocations. Abschließend Lock abwesend. Keine Services geändert, keine konkurrierenden Builds oder Tests gestartet. Kein src-/Repo-Edit, Commit, Push, Merge oder Linear-Zugriff. Der PR bleibt Draft.

## Reproduzierbare Evidenz

- Vollständige Zusammenfassung samt allen Einzelquotienten: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage2-summary.json`.
- Reiner Offline-Replay: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage2-offline-summary.py`.
- Geprüfte Runner und sämtliche Raw-Roots: `/Users/oliver.borchers/Desktop/fse-m4/dr147-stage2/`.
- Plan: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage2-plan.md`.
- Eigene Cleanupbelege: `DR-147-stage2-lock-cleanup-N-immediate.json` und `DR-147-stage2-lock-cleanup-N-delayed.json`, N=1..8, im Ergebnisordner.
- Abschlusscheckpoint: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage2-finish-checkpoint.md`.

## Urteil und Fortsetzungsschranke

**Stufe 2 rettet MLX nicht.** Echte öffentliche Übernahme funktioniert für die geprüften Inputs und Lebensdauern. Der getestete gemeinsame Importpfad liefert aber keinen konsistenten Laufzeitgewinn und schlägt beide CPUs nicht. Nicht behauptet wird, dass jede anders implementierte GPU-Fusion unmöglich wäre.

Empfehlung: C nicht in die nächste Variante übernehmen. Stufe 3 soll ausschließlich auf B mit Originalimporten aufbauen. Die freigegebene nächste Hypothese bündelt bereits wartende kompatible Tasks. Sie muss Packkosten, RSS, ursprüngliche Fehlerzuordnung, Bounds, Leases und Abbruch vollständig erhalten. Stufe 2 liefert keine kausale Zeit je Start. Auch die aus Stufe 1 abgeleiteten etwa 0,4 ms je gespartem Start sind nur ein gekoppelter Annahmewert.

Oliver hat die Vorbereitung von Stufe 3 ausdrücklich freigegeben. Ihr Modelllauf bleibt bis zur aktiven Skriptprüfung und dem Hash-Startprompt durch fse-codex gesperrt. Stufen 4 und 5 bleiben zusätzlich an die korrekte, rückfallfreie und plausibel schließbare Restlücke gebunden. Keine Umsetzung einer späteren Stufe im Stufe-2-Lauf. Die endgültige MLX-Policyentscheidung bleibt offen.

Fertig: Stufe 2, vollständiger Offline-Replay und terminale eigene Finderfreigabe.
Offen: unabhängige Stufe-2-Ergebnisprüfung und Vorbereitung von Stufe 3 auf B.
Von dir: keine neue Oliver-Rückfrage nötig. Vor Stufe-3-Messung bleibt der geprüfte Hash-Startprompt von fse-codex erforderlich.
