# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): Ergebnisprüfung Stufe 2 und Fortsetzung

Die Importhypothese liefert keinen belegten Gewinn. Die öffentliche Pufferübernahme funktioniert auf den geprüften echten Taskarrays. Das genügt nicht für schnellere vollständige Encodes.

Den gesamten vorhandenen Offline-Replay schreibfrei ausgeführt. Ausschließlich die finale Dateiausgabe im Arbeitsspeicher durch einen exakten Vergleich ersetzt. Alle gespeicherten Summaryfelder stimmen vollständig mit der Neuberechnung aus bestehenden Journaldaten überein. Keine Modellladung, Messung oder neue MLX-Operation.

Bestätigt: 5120 akzeptierte Pässe, 16 vorgegebene Blöcke je Zelle, fünf Pässe je Seite, getrennte B-Anker, komplette Bitvalidierungen, keine Rückfälle. Vier reale Owner-/Alias-/Inhaltsnachweise, acht Speicherjobs und zwei Abbruchzeugen bestanden. Sieben verworfene Blöcke und Wiederaufnahmen beruhen ausschließlich auf exakt bestätigten endlichen Laststopps. Keine Auswahl günstiger Blöcke und keine Wiederholung vollständiger Blöcke. Die freigegebenen Runnerhashes stimmen unverändert.

| Zelle | gepaart C/B, Median und Spanne | B/CPU12-B, Median | rechnerisch nötige weitere B-Einsparung |
|---|---:|---:|---:|
| timing-wikitext-raw | 1.037261 (0.700684 bis 1.499463) | 1.378983 | 27.48 % |
| timing-wikitext-norm | 1.107990 (0.778212 bis 1.587033) | 1.232757 | 18.88 % |
| timing-massive-raw | 1.034984 (0.874284 bis 1.258144) | 1.697968 | 41.11 % |
| timing-massive-norm | 1.062782 (0.909943 bis 1.226997) | 1.326246 | 24.60 % |

Die C/B-Spannen umfassen jeweils eins. Deshalb weder jeden Importwechsel als sicher langsameren Einzelaufruf noch einen kleinen kausalen Nachteil behaupten. Fest steht: kein belastbarer Rettungsgewinn. Keine universelle Aussage über GPU-Architekturen.

Stufe 2 verbrauchte tatsächlich 348.76280949999637 aktive Sekunden. Neuer Gesamtstand 1186.4762297509951 Sekunden, weiterhin ohne Cap. Historische Matrix 523.0340705840008 Sekunden und historischer Ledger bleiben unverändert. Letzte verzögerte Finder-Kontrolle meldet eigenen Lock abwesend.

## Fortsetzungsentscheidung

Oliver hat Stufen 3, 4 und 5 ausdrücklich ohne erneute Rückfrage freigegeben. Die Qualitäts- und Fortsetzungsregeln bleiben verbindlich. Stufe 3 darf jetzt als Plan und modellfreier Scratch-Runner vorbereitet werden. Ihr Datenlauf folgt erst nach meiner Prüfung und einem Startprompt mit Hashes.

Stufe 3 baut auf B auf, also Raw-Partition mit Originalimporten. C hat keinen belegten Nutzen und wird nicht still übernommen. Hypothese: wartende kompatible Tasks in einen Kernelstart bündeln. Bereits vorhandene Gruppen enthalten höchstens acht Tasks. Ein ideal vollständig gefüllter Pack mit acht Tasks könnte aus 89 Starts zwölf machen. Tatsächliche Gruppengrößen können kleiner sein. Weder zwölf Starts noch ein CPU-Sieg sind zugesagt.

Die etwa 0.4 ms pro gespartem Start aus Stufe 1 sind nur eine angenommene Aufteilung eines gekoppelten Partitionseffekts. Sie messen keine isolierte Launchlatenz. Ein plausibler Versuch prüft daher tatsächliche Starts und Packkosten gemeinsam, statt den Gewinn daraus vorherzusagen. Die erhebliche Stufe-1-Wirkung auf unveränderte Arithmetik und weiterhin viele Starts begründen diese nächste isolierte Probe. Stufe 2 widerlegt die reine Importrettung, entscheidet die Bündelung aber nicht.

Plan und Runner müssen ursprüngliche Taskgrenzen, Fehlerzuordnung, Zeilenreihenfolge, Bounds und Rückfallprüfung erhalten. Keine zusätzliche Wartefrist zum Füllen von Gruppen. Packarbeit und Ausgabeverteilung vollständig im Encode messen. RSS gegen Durchsatz ausweisen. CPU10 und CPU12 sowie alle festen CPU-A/B-Vergleiche sichtbar halten.

Stufen 4 und 5 folgen nur bei korrekten Ergebnissen, keinen Rückfällen und nachvollziehbar noch schließbarer Restlücke. Nach Erfolg auf allen vier MRL1024-Zellen folgen die autorisierten Kontrollen MRL512, MRL256 und Potion. Andernfalls die Stoppregel anwenden und die konkrete Grenze offen berichten.

Kein src-Edit, Commit, Push oder Merge. Keine Linear-Zugriffe, auch nicht lesend. PR #176 (2.0: DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen)) bleibt Draft. Der endgültige Gesamtbericht endet mit begründetem Urteil zum Behalten oder Entfernen, einschließlich Kosten für Code, Zahlenvertrag und Speicher.

Fertig: unabhängiger Rohdatenabgleich Stufe 2 und Freigabe der Stufe-3-Vorbereitung.
Offen: Stufe-3-Plan und Runner zur aktiven Prüfung.
Von dir: nichts. Keine weitere Oliver-Freigabe nötig.

Prüfzeitpunkt: 2026-10-31T18:56:08.734328+01:00
