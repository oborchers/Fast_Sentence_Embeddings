"""Model-free Stage3 controls. No model, encode, real MLX, lock or accounting write."""
import gc
import json
from pathlib import Path
from types import SimpleNamespace
import threading
import uuid
import weakref
import numpy as np
from dr147_stage3_pack import Packer, TAG, packed_task


class FakeMX:
    def __init__(self):
        self.fail_async = False
    def async_eval(self, *arrays):
        if self.fail_async:
            raise RuntimeError('CONTROL async evaluation')
    def eval(self, *arrays):
        pass
    def new_thread_unsafe_stream(self, device):
        return 'CONTROL stream'
    gpu = 'CONTROL GPU placeholder'


def check_packing():
    from fse._backends._mlx import _kernels as k, _device as d, _backend
    saved = d.Device.run, d.Device._launch, _backend.MlxBackend._device_rows, k.launch
    calls = []
    def fake_launch(mx, stream, table, task, normalize=False):
        calls.append((task.first_row, task.n_sentences))
        if getattr(table, 'fail', False):
            raise ValueError('CONTROL packed kernel dispatch')
        sums = np.array([sum(map(int, task.arrays[0][a:b])) for a, b in zip(task.arrays[1][:-1], task.arrays[1][1:])], np.float32)
        return (np.stack([sums, sums+1], axis=1), sums.astype(np.uint32).reshape(-1, 1), np.stack([sums+2, sums+3], axis=1))
    k.launch = fake_launch
    def task(first, tokens, offsets):
        return k.Task(len(offsets)-1, first, (np.array(tokens, np.uint32), np.array(offsets, np.uint32), *(np.zeros(1, np.uint32) for _ in range(3))), False)
    tasks = [task(90, [1, 2, 3], [0, 1, 3]), task(0, [5], [0, 0, 1]), task(42, [7, 8, 9], [0, 3])]
    originals = [[a.copy() for a in t.arrays] for t in tasks]
    table = SimpleNamespace(fasttext=False)
    mx = FakeMX()
    def make_job(device, t, table=table, normalize=False, finish=k.view, use_lease=True):
        def launch(mx, stream):
            return k.launch(mx, stream, table, t, normalize)
        setattr(launch, TAG, (device, table, t, normalize))
        job = d.Job(launch, finish, t.tokens, use_lease)
        job.state = 'running'
        return job
    def finish_jobs(done):
        lent = d.Device._settle(done, [], last=False)
        for job in done:
            d._used(job, lambda viewed: tuple(np.array(a, copy=True) for a in viewed))
            d._give_back(job)
        assert d._collect(lent, wait=False) == []
    try:
        joined, size = packed_task(k, tasks)
        assert joined.arrays[0].tolist() == [1, 2, 3, 5, 7, 8, 9]
        assert joined.arrays[1].tolist() == [0, 1, 3, 3, 4, 7] and size == 52
        assert all(np.array_equal(a,b) for t, before in zip(tasks, originals) for a,b in zip(t.arrays,before))
        expected = [k.view(fake_launch(mx, None, table, t)) for t in tasks]
        calls.clear()
        device, packer = d.Device(lambda: mx), Packer(audit=True)
        jobs = [make_job(device,t) for t in tasks]
        with packer.installed():
            launched, failed = device._launch(mx, jobs)
            assert not failed and len(calls) == 1 and packer.stats['dispatches'] == 1
            assert len({id(arrays) for _,arrays in launched}) == 1
            refs = [weakref.ref(a) for a in launched[0][1]]
            done = device._complete(mx, launched)
            for job,want in zip(done,expected):
                assert all(np.array_equal(a,b) for a,b in zip(job.result,want))
            lent = device._settle(done, [], last=False)
            for job in jobs[:2]:
                d._used(job, lambda viewed: tuple(np.array(a,copy=True)for a in viewed))
                d._give_back(job)
            lent = d._collect(lent, wait=False)
            assert lent == [jobs[2]] and jobs[0].arrays is jobs[1].arrays is None
            launched.clear()
            gc.collect()
            assert all(ref() is not None for ref in refs), 'shared output freed before last lease'
            d._used(jobs[2], lambda viewed: tuple(np.array(a,copy=True)for a in viewed))
            d._give_back(jobs[2])
            assert d._collect(lent, wait=False) == []
            gc.collect()
            assert all(ref() is None for ref in refs), 'shared output held after last lease'
            packer.assert_released()
        # Compatibility boundaries and input order remain exact.
        other = SimpleNamespace(fasttext=False)
        device, packer = d.Device(lambda: mx), Packer()
        jobs = [make_job(device,tasks[0]),make_job(device,tasks[1]),make_job(device,tasks[2],other),make_job(device,tasks[0],normalize=True)]
        calls.clear()
        with packer.installed():
            launched, failed = device._launch(mx,jobs)
            assert not failed and len(calls)==3 and [a for a,_ in launched]==jobs
            assert launched[0][1]is launched[1][1]and launched[2][1]is not launched[0][1]
            finish_jobs(device._complete(mx,launched))
        # Dispatch failure belongs to the original packed jobs, not an unrelated job.
        device, packer = d.Device(lambda: mx), Packer()
        bad = SimpleNamespace(fasttext=False,fail=True)
        jobs = [make_job(device,tasks[0],bad),make_job(device,tasks[1],bad),make_job(device,tasks[2],other)]
        with packer.installed():
            launched,failed=device._launch(mx,jobs)
            assert failed==jobs[:2]and [a for a,_ in launched]==jobs[2:]
            assert all(isinstance(j.error,ValueError)for j in failed)and jobs[2].error is None
            finish_jobs([*failed,*device._complete(mx,launched)])
        # A finish failure remains local after packed evaluation.
        def fail_finish(arrays):raise IndexError('CONTROL original finish42')
        device, packer = d.Device(lambda: mx), Packer()
        jobs=[make_job(device,tasks[0]),make_job(device,tasks[1],finish=fail_finish),make_job(device,tasks[2])]
        with packer.installed():
            launched,failed=device._launch(mx,jobs)
            done=device._complete(mx,launched)
            assert not failed and [isinstance(j.error,IndexError)for j in done]==[False,True,False]
            finish_jobs(done)
        # Evaluation failure keeps original group-wide semantics.
        device, packer = d.Device(lambda: mx), Packer()
        jobs=[make_job(device,t)for t in tasks]
        mx.fail_async=True
        with packer.installed():
            launched,failed=device._launch(mx,jobs)
            assert launched==[]and failed==jobs and all(isinstance(j.error,RuntimeError)for j in jobs)
            finish_jobs(failed)
        mx.fail_async=False
        # Restoration runs through an unrelated BaseException, not only normal return.
        packer=Packer()
        try:
            with packer.installed():raise KeyboardInterrupt('CONTROL restore')
        except KeyboardInterrupt:pass
        assert not packer.active
        threaded_leases(k,d,table,tasks,mx)
    finally:
        k.launch=saved[3]
    assert (d.Device.run,d.Device._launch,_backend.MlxBackend._device_rows,k.launch)==saved
    return {'pack_tokens_offsets_and_input_immutability':True,'noncontiguous_original_rows_preserved':True,
            'exact_rows_flags_bounds_slices':True,'last_shared_lease_lifetime':True,'compatibility_boundaries':True,
            'dispatch_finish_evaluation_error_mapping':True,'threaded_queue_lease_and_interrupt':True,'originals_restored':True}


def threaded_leases(k,d,table,tasks,mx):
    """Real Device.run/queue/lease waits, fake arrays. Conditions prove actual blocking."""
    device, packer = d.Device(lambda:mx),Packer(audit=True)
    gate=threading.Condition();entered=threading.Event();released=False
    hold=threading.Condition();holding=threading.Event();return_use=False
    used=[threading.Event()for _ in range(3)];errors=[]
    def starter(mx,stream):
        nonlocal released
        with gate:
            entered.set()
            while not released:gate.wait()
        return (np.array([0],np.float32),)
    def first():
        try:device.run(starter,lambda arrays:arrays[0])
        except BaseException as error:errors.append(error)
    def caller(index):
        def launch(mx,stream):return k.launch(mx,stream,table,tasks[index],False)
        setattr(launch,TAG,(device,table,tasks[index],False))
        def use(viewed):
            nonlocal return_use
            used[index].set()
            if index==0:
                with hold:
                    holding.set()
                    while not return_use:hold.wait()
                raise KeyboardInterrupt('CONTROL worker-use interrupt')
            return tuple(np.array(a,copy=True)for a in viewed)
        try:device.run(launch,k.view,tasks[index].tokens,use)
        except KeyboardInterrupt as error:
            if index!=0:errors.append(error)
        except BaseException as error:errors.append(error)
    with packer.installed():
        initial=threading.Thread(target=first);initial.start()
        assert entered.wait(10)
        with gate:assert gate._waiters  # acquire succeeds only after wait releases the lock
        workers=[threading.Thread(target=caller,args=(i,))for i in range(3)]
        # Enqueue acknowledgement uses the actual Device lock, no sleep-based readiness.
        original_enqueue=device._enqueue
        queued=threading.Condition();number=0
        def enqueue(job):
            nonlocal number
            original_enqueue(job)
            with queued:number+=1;queued.notify_all()
        device._enqueue=enqueue
        try:
            for worker in workers:worker.start()
            with queued:
                assert queued.wait_for(lambda:number==3,timeout=10)
            with device._lock:assert len(device._queue)==3
            with gate:released=True;gate.notify_all()
            assert holding.wait(10)
            with hold:assert hold._waiters
            assert used[1].wait(10)and used[2].wait(10)
            assert packer.stats['packed_jobs']==3 and packer.stats['packed_dispatches']==1
            with hold:return_use=True;hold.notify_all()
            for thread in [initial,*workers]:
                thread.join(10);assert not thread.is_alive()
            assert not errors and not device._queue and device._thread is None
            packer.assert_released()
        finally:
            with gate:released=True;gate.notify_all()
            with hold:return_use=True;hold.notify_all()
            device._enqueue=original_enqueue
            for thread in [initial,*workers]:thread.join(10)


def check_resume(api,root):
    records=[]
    for index in range(2):
        blocks=api.BLOCKS if index%2==0 else list(reversed(api.BLOCKS))
        records.append({'index':index,'blocks':[b[0]for b in blocks],
                        'orders':{n:api.side_order(index,c)for n,_,_,c in blocks},
                        'times':{n:{s:1.0 for s in api.side_order(index,c)}for n,_,_,c in blocks}})
    api.validate_rounds(records)
    prior=root/'prior.json'
    api.write(prior,{'protocol':api.protocol(),'job_id':'timing-wikitext-raw','corpus_name':'wikitext','mode':'raw','stop':{'retryable_load':True},'rounds':records})
    real_guard,real_setup=api.ProgressGuard,api.setup
    class FailBeforeSetup:
        def __init__(self,scratch,lock,journal):self.journal=journal
        def check(self,label):
            api.append(self.journal,{'event':'guard','label':'CONTROL early finite load','load':5.25,'finite_load':True,'synthetic_control_fixture':True})
            raise api.safety().StopError('load 5.25 is not strictly below 5')
    def no_model(*args):raise AssertionError('CONTROL setup must never be reached')
    api.ProgressGuard,api.setup=FailBeforeSetup,no_model
    try:
        for i in [1,2]:
            folder=root/f'early-{i}';folder.mkdir()
            config={'id':'timing-wikitext-raw','kind':'timing','corpus':'wikitext','mode':'raw','folder':str(folder),'lock':{},'resume_result':str(prior),'resume_result_sha256':api.digest(prior)}
            api.write(folder/'job.json',config);assert api.job(folder/'job.json')==2
            prior=folder/'result.json';result=api.read(prior)
            assert result['status']=='failed'and result['rounds']==records and result['stop']['retryable_load']is True
    finally:api.ProgressGuard,api.setup=real_guard,real_setup
    roots=[root/'root-a',root/'root-b']
    for path in roots:
        path.mkdir();api.write(path/'state.json',{'root':str(path),'status':'incomplete','retryable_load':True,'protocol':api.protocol()})
    events=[{'kind':'start','stage':3,'root':str(roots[0]),'parent_root':None},{'kind':'start','stage':3,'root':str(roots[1]),'parent_root':str(roots[0])}]
    assert api.lineage(events,str(roots[1]))['root']==str(roots[1])
    for changed,requested in[(events,str(roots[0])),(events,None),(events+[{'kind':'start','stage':3,'root':str(root/'fork'),'parent_root':str(roots[0])}],str(root/'fork'))]:
        try:api.lineage(changed,requested)
        except AssertionError:pass
        else:raise AssertionError('CONTROL ancestor/fork admitted')
    return {'early_stop_prefixes_preserved':True,'failed_status_after_exception':True,'ancestor_and_fork_rejected':True}


def check_memory_partition(api):
    from contextlib import nullcontext
    from fse._runtime._pipeline import Pipeline
    observed=[]
    original_memory,original_packer=api.BASE.memory,api.Packer
    class MemoryPacker:
        stats={'jobs':2,'dispatches':1}
        def installed(self):return nullcontext()
        def snapshot(self):return dict(self.stats)
    def inspect(config,result,*unused):
        dummy=SimpleNamespace(output_dim=1024,_device_rows=True,prepared=SimpleNamespace(steps=(1,)))
        with api.BASE.partition(config['patched']):
            observed.append(Pipeline._row_bytes(dummy,'float32'))
        result.update(plan={'tasks':2},gpu_launches=1 if config['variant']=='D'else 2)
    fake_pipe=SimpleNamespace(backend=SimpleNamespace(device=SimpleNamespace(_queue=[],_thread=None)))
    fake_encoder=SimpleNamespace(_pipeline=lambda name:fake_pipe)
    api.BASE.memory,api.Packer=inspect,MemoryPacker
    try:
        for variant in 'BD':api.memory({'variant':variant},{},None,fake_encoder,None,None)
    finally:api.BASE.memory,api.Packer=original_memory,original_packer
    assert observed==[8328,8328],'memory applied Raw partition more than once'
    return observed


def check_owner(api, root):
    """Actual delegated owner, isolated Fake API. No real lock, ledger or child."""
    from contextlib import redirect_stdout
    import io
    import dr147_stage3_control as control
    folder=root/'CONTROL-owner-fixture';folder.mkdir()
    here=folder/'roots';here.mkdir()
    ledger=folder/'empty-synthetic-ledger.jsonl';ledger.write_text('')
    repo=folder/'sentinel-checkout'
    calls, virtual_events, writes, admissions = [], [], {}, []
    def identity(got_repo, head):
        assert got_repo==repo and head=='CONTROL_HEAD'
        calls.append((str(got_repo),head))
        return {'native_checksum':'CONTROL_NATIVE','synthetic_control_fixture':True}
    def acquire(scratch, head, branch):
        assert scratch==folder/'scratch' and head=='CONTROL_HEAD' and branch=='dr147-mlx-m4'
        admissions.append(True)
        return {'pid':0,'token':'CONTROL_ONLY','synthetic_control_fixture':True}
    def fake_write(path,value):writes[str(path)]=json.loads(json.dumps(value))
    def fake_append(path,value):
        assert path==ledger
        virtual_events.append({**json.loads(json.dumps(value)),'synthetic_control_fixture':True})
    def no_child(*args,**kwargs):raise AssertionError('owner fixture must never launch a child')
    def lineage(events,requested):
        assert events==[] and requested is None
        return None
    fake=SimpleNamespace(S=folder/'scratch',HEAD='CONTROL_HEAD',HERE=here,DECISION=folder/'decision',LEDGER=ledger,
                         REPO=repo,NATIVE='CONTROL_NATIVE',__file__=folder/'not-executable.py',
                         clock_policy=lambda:0.0,lineage=lineage,protocol=lambda:{'synthetic_control_fixture':True},jobs=lambda:[],
                         read=no_child,write=fake_write,append=fake_append,digest=lambda path:'CONTROL_SHA',
                         safety=lambda:SimpleNamespace(acquire=acquire,identity=identity),
                         stop_record=lambda error,path:{'type':type(error).__name__,'reason':str(error),'retryable_load':False})
    old_os,old_run=control.os,control.run_job
    control.os=SimpleNamespace(getloadavg=lambda:(1.0,1.0,1.0),getpid=lambda:0)
    control.run_job=no_child
    try:
        with redirect_stdout(io.StringIO()):code=control.owner(fake,None)
    finally:control.os,control.run_job=old_os,old_run
    states=[value for path,value in writes.items()if Path(path).name=='state.json']
    assert code==0 and len(states)==1 and states[0]['status']=='complete',states
    assert calls==[(str(repo),'CONTROL_HEAD')]*2 and admissions==[True]
    assert [e['kind']for e in virtual_events]==['start','finish'] and virtual_events[-1]['status']=='complete'
    assert ledger.read_text()=='' and not(fake.S/'bench.lock').exists()
    return {'fake_owner_initial_final_identity':True,'fake_owner_identity_calls':len(calls),
            'fake_owner_repo_argument':str(repo),'fake_owner_no_real_lock_booking_or_child':True}


def check(api):
    import sys
    import subprocess
    paths=sorted(api.HERE.glob('*.py'))
    assert len(paths)==4
    names=subprocess.run([str(api.REPO/'.venv/bin/ruff'),'check','--isolated','--no-cache','--select','F821',*map(str,paths)],capture_output=True,text=True)
    assert names.returncode==0,names.stdout+names.stderr
    ledger_before=api.digest(api.LEDGER)
    from types import ModuleType
    stub=ModuleType('fse._backends._mlx._load')
    def no_core():raise AssertionError('CONTROL real MLX core must not be called')
    stub.core=no_core
    assert stub.__name__ not in sys.modules
    class BlockRealMLX:
        def find_spec(self,fullname,path=None,target=None):
            if fullname=='mlx'or fullname.startswith('mlx.'):
                raise AssertionError('CONTROL real MLX import blocked')
    blocker=BlockRealMLX()
    sys.meta_path.insert(0,blocker)
    sys.modules[stub.__name__]=stub
    try:
        values=check_packing()
    finally:
        sys.meta_path.remove(blocker)
        assert sys.modules.pop(stub.__name__)is stub
    root=api.RESULTS/('DR-147-stage3-controls-'+uuid.uuid4().hex[:12]);root.mkdir()
    values['F821_four_files']=True
    values.update(check_owner(api,root))
    values.update(check_resume(api,root))
    values['memory_partition_B_D']=check_memory_partition(api)
    assert len(api.jobs())==18 and api.ROUNDS==16 and api.PASSES==5
    assert 'mlx'not in sys.modules and 'mlx.core'not in sys.modules
    assert api.digest(api.LEDGER)==ledger_before and not(api.S/'bench.lock').exists()
    identity=api.safety().identity(api.REPO,api.HEAD)
    assert identity['native_checksum']==api.NATIVE
    print(json.dumps({'status':'model-free Stage3 controls passed','encodes':0,'models_loaded':False,'real_mlx_calls':0,
                      'checks':values,'control_root':str(root),'protocol':api.protocol(),'identity':identity,
                      'global_actual_seconds':api.clock_policy(),'ledger_unchanged':True}))
