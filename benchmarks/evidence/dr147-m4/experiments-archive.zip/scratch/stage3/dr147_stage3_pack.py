"""Scratch-only Stage3: pack already-taken compatible jobs, original kernel/imports.

No Linear access. No waiting policy, arithmetic, bounds or worker-output-copy change.
"""
from contextlib import contextmanager
import threading
import numpy as np

TAG = '_dr147_stage3_task'
MAX_PACK_BYTES = 128 << 20


def packed_task(kernels, tasks):
    """New host inputs. Original Task arrays remain unchanged and independently owned."""
    assert len(tasks) > 1
    rows = sum(t.n_sentences for t in tasks)
    tokens = sum(len(t.arrays[0]) for t in tasks)
    assert 0 < rows <= kernels.LIMIT and tokens <= kernels.LIMIT
    required = 4 * (tokens + rows + 1)  # three original dummy inputs are reused as inputs
    assert required <= MAX_PACK_BYTES, 'single host pack exceeds128MiB'
    for task in tasks:
        a, b = task.arrays[:2]
        assert not task.unknown and len(task.arrays) == 5 and task.n_sentences > 0
        assert a.dtype == b.dtype == np.uint32 and a.ndim == b.ndim == 1
        assert a.flags.c_contiguous and b.flags.c_contiguous
        assert len(b) == task.n_sentences + 1 and b[0] == 0 and b[-1] == len(a)
        assert not np.any(b[:-1] > b[1:])
    joined = np.concatenate([t.arrays[0] for t in tasks])
    offsets = np.empty(rows + 1, np.uint32)
    row, token = 0, 0
    for task in tasks:
        end = row + task.n_sentences
        np.add(task.arrays[1][:-1], np.uint32(token), out=offsets[row:end])
        row, token = end, token + len(task.arrays[0])
    offsets[-1] = token
    packed = kernels.Task(rows, tasks[0].first_row, (joined, offsets, *tasks[0].arrays[2:]), False)
    return packed, required


def piece_finish(original, begin, end):
    """No MLX slice nodes: original finish sees host views of its exact rows."""
    def finish(arrays):
        pieces = tuple(np.asarray(array)[begin:end] for array in arrays)
        return original(pieces)
    return finish


class Packer:
    def __init__(self, audit=False):
        self.local = threading.local()
        self.active = False
        self.audit = audit
        self.records, self.observed_jobs, self.task_map = [], [], []
        self.stats = dict(groups=0, jobs=0, dispatches=0, packed_dispatches=0, packed_jobs=0,
                          host_pack_bytes=0, largest_host_pack_bytes=0)

    def snapshot(self):
        return dict(self.stats)

    @staticmethod
    def change(after, before):
        return {k: after[k]-before[k] for k in after if k != 'largest_host_pack_bytes'}

    @staticmethod
    def compatible(meta):
        return meta is not None and not meta[1].fasttext and not meta[2].unknown

    def _segments(self, group):
        parts = []
        for job in group:
            meta = getattr(job.launch, TAG, None)
            if parts and self.compatible(meta):
                lastmeta = getattr(parts[-1][-1].launch, TAG, None)
                if self.compatible(lastmeta) and meta[0] is lastmeta[0] and meta[1] is lastmeta[1] and meta[3] == lastmeta[3]:
                    parts[-1].append(job)
                    continue
            parts.append([job])
        return parts

    def _shared_launch(self, kernels, mx, stream, metas):
        table, normalize = metas[0][1], metas[0][3]
        task, size = packed_task(kernels, [m[2] for m in metas])
        self.stats['host_pack_bytes'] += size
        self.stats['largest_host_pack_bytes'] = max(self.stats['largest_host_pack_bytes'], size)
        self.stats['dispatches'] += 1
        self.stats['packed_dispatches'] += 1
        self.stats['packed_jobs'] += len(metas)
        if self.audit:
            self.records.append({'job_ids': [m[4] for m in metas], 'group': self.stats['groups'],
                                 'device_thread': threading.get_ident(), 'original_tasks': [[m[2].first_row, m[2].n_sentences, m[2].tokens] for m in metas],
                                 'packed_rows': task.n_sentences, 'packed_tokens': task.tokens,
                                 'host_pack_bytes': size, 'normalize': normalize})
        return kernels.launch(mx, stream, table, task, normalize)

    def launch_group(self, original, kernels, device, mx, group):
        if not group:
            return original(device, mx, group)
        self.stats['groups'] += 1
        self.stats['jobs'] += len(group)
        if self.audit:
            self.observed_jobs.extend(group)
            for job in group:
                meta = getattr(job.launch, TAG, None)
                if meta is not None:
                    task = meta[2]
                    self.task_map.append({'job_id': id(job), 'first_row': task.first_row,
                                          'rows': task.n_sentences, 'tokens': task.tokens,
                                          'normalize': meta[3], 'group': self.stats['groups']})
        saved = []
        for jobs in self._segments(group):
            meta = getattr(jobs[0].launch, TAG, None)
            if len(jobs) == 1:
                if meta is not None:
                    first = jobs[0].launch
                    def single(mx, stream, first=first):
                        self.stats['dispatches'] += 1
                        return first(mx, stream)
                    saved.append((jobs[0], first))
                    jobs[0].launch = single
                continue
            assert self.compatible(meta)
            box = {}  # evaluated once, in the unchanged sequential original launch loop
            originals = [(job, job.launch) for job in jobs]
            metas = [(*getattr(first, TAG), id(job)) for job, first in originals]
            row = 0
            for index, (job, first) in enumerate(originals):
                n = getattr(first, TAG)[2].n_sentences
                job.finish = piece_finish(job.finish, row, row+n)
                row += n
                def shared(mx, stream, index=index, box=box, metas=metas):
                    if index == 0:
                        try:
                            box['arrays'] = self._shared_launch(kernels, mx, stream, metas)
                        except Exception as error:
                            box['error'] = error
                    if 'error' in box:
                        raise box['error']
                    return box['arrays']
                saved.append((job, first))
                job.launch = shared
        try:
            return original(device, mx, group)
        finally:
            for job, first in saved:
                job.launch = first

    @contextmanager
    def installed(self):
        from fse._backends._mlx import _device, _backend, _kernels
        assert not self.active
        device_class, backend_class = _device.Device, _backend.MlxBackend
        original_run, original_launch, original_rows = device_class.run, device_class._launch, backend_class._device_rows
        def rows(backend, batch, state, table, task, out):
            previous = getattr(self.local, 'meta', None)
            normalize = bool(state.host.steps) and _kernels.normalizes(table)
            self.local.meta = (backend.device, table, task, normalize)
            try:
                return original_rows(backend, batch, state, table, task, out)
            finally:
                self.local.meta = previous
        def run(device, launch, finish, tokens=0, use=None):
            meta = getattr(self.local, 'meta', None)
            if meta is None or meta[0] is not device:
                return original_run(device, launch, finish, tokens, use)
            assert not hasattr(launch, TAG)
            setattr(launch, TAG, meta)
            try:
                return original_run(device, launch, finish, tokens, use)
            finally:
                delattr(launch, TAG)
        def grouped(device, mx, group):
            return self.launch_group(original_launch, _kernels, device, mx, group)
        self.active = True
        device_class.run, device_class._launch, backend_class._device_rows = run, grouped, rows
        try:
            yield
        finally:
            device_class.run, device_class._launch, backend_class._device_rows = original_run, original_launch, original_rows
            self.active = False

    def assert_released(self):
        assert self.observed_jobs
        for job in self.observed_jobs:
            assert job.done.is_set() and job.returned.is_set() and job.arrays is None and job.result is None
        self.observed_jobs.clear()
