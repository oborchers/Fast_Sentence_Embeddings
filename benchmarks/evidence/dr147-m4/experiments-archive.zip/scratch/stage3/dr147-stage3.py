"""Stage3 scratch preparation. No Linear. No model run before hash start prompt."""
import sys
sys.dont_write_bytecode = True
import argparse
import importlib.util
import json
import math
import os
from pathlib import Path
import threading
import time
from contextlib import contextmanager, nullcontext

HERE = Path(__file__).resolve().parent
S = Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch')
REPO = S / 'dr147-mlx-m4'
RESULTS = Path('/Users/oliver.borchers/Desktop/fse-m4-results')
HEAD = 'ef4d6a7bb33ac65a711458365312a5c0faf0b96a'
NATIVE = 'xxh3-128:2d9d0a93859e347a5220443fab372260'
DECISION, LEDGER = S / 'DR-147-time-limit-removal.json', S / 'budget.jsonl'
ROUNDS, PASSES = 16, 5
sys.path.insert(0, str(S))
sys.path.insert(0, str(REPO / 'benchmarks'))
from dr147_stage1_supervision import ProgressGuard, pulse
from dr147_stage1_cancel import InterruptWitness
from dr147_stage3_pack import Packer
from dr147_stage3_control import owner, cancel_controller
spec = importlib.util.spec_from_file_location('stage1_frozen_for_stage3', S / 'dr147-stage1.py')
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
read, write, append, digest, safety = BASE.read, BASE.write, BASE.append, BASE.digest, BASE.safety
clock_policy, setup, stop_record, spread = BASE.clock_policy, BASE.setup, BASE.stop_record, BASE.spread
FROZEN = {'dr147-stage1.py': 'eba55b15b3b29b458b82f9700509d68e1af4e226a005500986afabf8c10bd0ff',
          'dr147_stage1_supervision.py': 'a47212a90eadb6daad4316df4c371c7a1df55f2986ba6047b9179272048fa5a9',
          'dr147_stage1_cancel.py': '944b6f6e30093272a2f529f9cb983529226e6fa1addccabb8f8d49dfacb2f1da'}
BLOCKS = [('cpu10', 'cpu', 10, 'AB'), ('cpu12', 'cpu', 12, 'AB'), ('mlx', 'mlx', 12, 'BD')]


def protocol():
    assert all(digest(S / name) == sha for name, sha in FROZEN.items())
    assert digest(RESULTS / 'DR-147-stage2-summary.json') == 'b95489ff543f772a9262f41796b2234b5dc2cd912e3baf85db9b5d87fd6d8011'
    return {'stage': 3, 'head': HEAD, 'rounds': ROUNDS, 'passes': PASSES,
            'scripts': {name: digest(HERE / name) for name in ['dr147-stage3.py', 'dr147_stage3_pack.py', 'dr147_stage3_control.py', 'dr147_stage3_checks.py']},
            'frozen_stage1': FROZEN, 'stage2_summary_sha256': digest(RESULTS / 'DR-147-stage2-summary.json'),
            'blocks': [list(b) for b in BLOCKS], 'variant': 'B plus compatible already-taken jobs packed; original imports/kernel'}


def side_order(index, comparison):
    a, b = comparison
    return [a+'1', b+'1', b+'2', a+'2'] if index % 2 == 0 else [b+'1', a+'1', a+'2', b+'2']


def validate_rounds(records):
    assert len(records) <= ROUNDS
    for index, record in enumerate(records):
        assert record['index'] == index
        expected = BLOCKS if index % 2 == 0 else list(reversed(BLOCKS))
        assert record['blocks'] == [b[0] for b in expected]
        assert set(record['times']) == {b[0] for b in BLOCKS}
        for name, _, _, comparison in BLOCKS:
            assert record['orders'][name] == side_order(index, comparison)
            assert set(record['times'][name]) == {v+str(i) for v in comparison for i in [1, 2]}
            assert all(type(t) in (int, float) and math.isfinite(t) and t > 0 for t in record['times'][name].values())


@contextmanager
def candidate(variant, packer):
    assert variant in ['A', 'B', 'D']
    with BASE.partition(variant != 'A'):
        with packer.installed() if variant == 'D' else nullcontext():
            yield


def error_witness(enc, texts, pipe, packer):
    import numpy as np
    from fse._contract import Batch
    from fse._text import StringSource, new_workspace
    with BASE.partition(True):
        plans, _, _ = pipe.plan_tasks(StringSource(texts), 12, None, pipe._row_bytes('float32'))
    tasks = iter(plans.tasks)
    next(tasks)
    original = next(tasks).batch(pipe.lookup, new_workspace())  # nonzero original row identity
    tokens = original.tokens.copy()
    assert len(tokens)
    tokens[0] = pipe.prepared.state.table.n_words
    bad = Batch(original.first_row, original.offsets, tokens)
    errors = {}
    cpu = enc._pipeline('cpu')
    for name, target in [('cpu', cpu), ('mlx_D', pipe)]:
        with candidate('D' if name == 'mlx_D' else 'B', packer):
            try:
                target.backend.rows(bad, target.prepared, np.empty((bad.n_sentences, 1024), np.float32))
            except Exception as error:
                errors[name] = {'type': type(error).__module__+'.'+type(error).__qualname__, 'text': str(error)}
            else:
                raise AssertionError('invalid token did not raise')
    assert errors['cpu'] == errors['mlx_D'], 'original input error changed'
    return {'first_row': bad.first_row, 'errors': errors}


def audit(config, result, guard, enc, texts, want):
    from fse._backends._mlx import _kernels
    from mlx_gate_parity import counts, delta, equal, launches
    pipe = enc._pipeline('mlx')  # original canary/table before the observer and candidate
    assert not pipe.prepared.state.table.fasttext
    packer = Packer(audit=True)
    before = counts(enc)
    cache = {k: id(v) for k, v in _kernels._KERNELS.items()}
    guard.check('before full packed corpus audit')
    with candidate('D', packer), launches() as seen:
        rows = enc.encode(texts, backend='mlx', workers=12)
    equal(rows, want)
    assert delta(counts(enc), before) == {}
    detail = BASE.plan_details(pipe, texts, 12, True)
    assert sorted([[a['first_row'], a['rows']] for a in packer.task_map]) == sorted(detail['spans'])
    assert packer.stats['jobs'] == detail['tasks']
    assert packer.stats['dispatches'] == len(seen) < detail['tasks']
    assert packer.stats['packed_dispatches'] > 0
    packer.assert_released()
    assert not pipe.backend.device._queue and pipe.backend.device._thread is None
    result.update(plan=detail, packing=packer.snapshot(), packs=packer.records, task_map=packer.task_map,
                  bits_equal=True, fallback_events={}, leases_released=True)
    guard.check('after packed corpus bits and leases')
    result['original_input_error'] = error_witness(enc, texts, pipe, packer)
    assert delta(counts(enc), before) == {}
    assert cache == {k: id(v) for k, v in _kernels._KERNELS.items()}
    result['kernel_cache_identity_unchanged'] = True
    guard.check('after original error witness')


def memory(config, result, guard, enc, texts, want):
    pipe = enc._pipeline('mlx')
    packer = Packer()
    # BASE.memory applies Raw partition exactly once; this context only installs packing.
    with packer.installed() if config['variant'] == 'D' else nullcontext():
        BASE.memory({**config, 'patched': True, 'backend': 'mlx', 'workers': 12}, result, guard, enc, texts, want)
    result['packing'] = packer.snapshot()
    if config['variant'] == 'D':
        assert packer.stats['jobs'] == result['plan']['tasks']
        assert 0 < packer.stats['dispatches'] == result['gpu_launches'] < result['plan']['tasks']
    else:
        assert result['gpu_launches'] == result['plan']['tasks']
    assert not pipe.backend.device._queue and pipe.backend.device._thread is None


def summarize(rounds, texts):
    absolute, ratios, aa = {}, {}, {}
    for name, _, _, comparison in BLOCKS:
        a, b = comparison
        ratios[name+':'+b+'/'+a] = spread([r['times'][name][b+str(i)]/r['times'][name][a+str(i)] for r in rounds for i in [1, 2]])
        for v in comparison:
            values = [r['times'][name][v+str(i)] for r in rounds for i in [1, 2]]
            absolute[name+':'+v] = {'seconds': spread(values), 'texts_per_s': spread([texts/t for t in values])}
            aa[name+':'+v+'2/'+v+'1'] = spread([r['times'][name][v+'2']/r['times'][name][v+'1'] for r in rounds])
    for mv in 'BD':
        for cpu in ['cpu10', 'cpu12']:
            for cv in 'AB':
                ratios[f'mlx:{mv}/{cpu}:{cv}'] = spread([r['times']['mlx'][mv+str(i)]/r['times'][cpu][cv+str(i)] for r in rounds for i in [1, 2]])
    return {'absolute': absolute, 'ratios': ratios, 'AA_BB_DD': aa, 'scope': '32 paired values in16 fixed round clusters'}


def originals():
    from fse._runtime._pipeline import Pipeline
    from fse._backends._mlx import _device, _backend, _kernels
    return Pipeline._row_bytes, _device.Device.run, _device.Device._launch, _backend.MlxBackend._device_rows, _kernels.launch


def timed(config, result, guard, enc, texts, want):
    from fse._backends._mlx import _kernels
    from mlx_gate_parity import counts, delta, equal, launches
    pipe = enc._pipeline('mlx')
    device, packer, plans = pipe.backend.device, Packer(), {}
    saved = originals()
    cache = {k: id(v) for k, v in _kernels._KERNELS.items()}
    for name, backend, workers, comparison in BLOCKS:
        target = enc._pipeline(backend)
        for variant in comparison:
            guard.check('before warm '+name+variant)
            detail = BASE.plan_details(target, texts, workers, variant != 'A')
            p0 = packer.snapshot()
            before = counts(enc)
            with candidate(variant, packer), launches() as seen:
                rows = enc.encode(texts, backend=backend, workers=workers)
            equal(rows, want)
            assert delta(counts(enc), before) == {}
            detail.update(gpu_launches=len(seen), packing=Packer.change(packer.snapshot(), p0))
            if backend == 'mlx':
                assert 0 < len(seen) <= detail['tasks']
                assert (len(seen) < detail['tasks']) if variant == 'D' else (len(seen) == detail['tasks'])
            plans[name+':'+variant] = detail
            assert originals() == saved
            guard.check('after warm '+name+variant)
    assert plans['mlx:B']['spans'] == plans['mlx:D']['spans']
    result['plans'] = plans
    baseline = counts(enc)
    for index in range(len(result['rounds']), ROUNDS):
        guard.check(f'round{index} before')
        blocks = BLOCKS if index % 2 == 0 else list(reversed(BLOCKS))
        record = {'index': index, 'times': {}, 'orders': {}, 'blocks': [b[0] for b in blocks]}
        result['incomplete_round'] = record
        for name, backend, workers, comparison in blocks:
            record['times'][name] = {}
            record['orders'][name] = side_order(index, comparison)
            for side in record['orders'][name]:
                variant = side[0]
                guard.check(f'{index}:{name}:{side} before side')
                assert originals() == saved
                with candidate(variant, packer):
                    values = []
                    for n in range(PASSES):
                        before = guard.check(f'{index}:{name}:{side}:{n} before pass')
                        logical0, groups0, p0 = device.launches, device.evaluations, packer.snapshot()
                        start = time.perf_counter_ns()
                        rows = enc.encode(texts, backend=backend, workers=workers)
                        elapsed = (time.perf_counter_ns()-start)/1e9
                        after_load = os.getloadavg()[0]
                        packing = Packer.change(packer.snapshot(), p0)
                        logical, groups = device.launches-logical0, device.evaluations-groups0
                        gpu_starts = packing['dispatches'] if variant == 'D' else logical
                        append(guard.journal, {'event': 'pass', 'round': index, 'block': name, 'side': side, 'pass': n,
                                              'seconds': elapsed, 'load_before': before['load'], 'load_after': after_load if math.isfinite(after_load) else None,
                                              'logical_gpu_jobs': logical, 'device_evaluations': groups, 'gpu_pool_starts': gpu_starts, 'packing': packing})
                        equal(rows, want)
                        assert delta(counts(enc), baseline) == {}, 'fallback event'
                        if backend == 'mlx':
                            assert logical == plans[name+':'+variant]['tasks'] and 0 < gpu_starts <= logical
                        else:
                            assert logical == gpu_starts == 0
                        append(guard.journal, {'event': 'pass_validated', 'round': index, 'block': name, 'side': side,
                                              'pass': n, 'bits_equal': True, 'fallback_events': {}})
                        guard.check(f'{index}:{name}:{side}:{n} after pass', sample=after_load)
                        values.append(elapsed)
                    record['times'][name][side] = min(values)
                assert originals() == saved and not packer.active
                guard.check(f'{index}:{name}:{side} after side')
        guard.check(f'round{index} after')
        result['rounds'].append(record)
        result.pop('incomplete_round')
        append(guard.journal, {'event': 'round_kept', **record})
    assert cache == {k: id(v) for k, v in _kernels._KERNELS.items()}
    result.update(summary=summarize(result['rounds'], len(texts)), bits_equal=True, fallback_events={}, kernel_cache_identity_unchanged=True)


def cancellation(config, result, guard, enc, texts, ready, release):
    import numpy as np
    from fse._runtime import _executor
    from fse._runtime._pipeline import Pipeline
    from fse._backends._mlx._device import Device
    from mlx_gate_parity import counts, delta
    pipe, packer, targets, shared = enc._pipeline('mlx'), Packer(audit=True), [], []
    before = counts(enc)
    work, descriptor, complete = Pipeline._work, vars(Device)['_complete'], Device._complete
    try:
        with candidate('D', packer), InterruptWitness(_executor, ready, release) as witness:
            def capture(self, local, task, target, base):
                targets.append(target[0])
                return work(self, local, task, target, base)
            def finish(mx, launched):
                ids = [id(arrays) for _, arrays in launched]
                if len(set(ids)) < len(ids):
                    shared.append({'original_jobs': [id(job) for job, _ in launched], 'shared_output_tuple_ids': ids})
                    witness.block_worker('gpu_multi_task_pack_submitted_before_complete')
                return complete(mx, launched)
            Pipeline._work, Device._complete = capture, staticmethod(finish)
            guard.check('before packed cancellation encode')
            try:
                try:
                    enc.encode(texts, backend='mlx', workers=12)
                except KeyboardInterrupt:
                    result['keyboard_interrupt'] = True
                else:
                    raise AssertionError('SIGINT witness did not interrupt encode')
            finally:
                Pipeline._work, Device._complete = work, descriptor
        assert witness.proof and shared and targets
        writers = [t.name for t in threading.enumerate() if t.name.startswith(('fse-worker', 'fse-mlx'))]
        assert not writers
        snapshots = [a.view(np.uint32).copy() for a in targets]
        snapshot_at = time.monotonic()
        device = pipe.backend.device
        assert not device._queue and device._thread is None
        device.core().synchronize(device._stream)
        assert all(np.array_equal(a.view(np.uint32), b) for a, b in zip(targets, snapshots, strict=True))
        packer.assert_released()
        assert delta(counts(enc), before) == {}
        result.update(blocked_wait_proof=witness.proof, shared_packs_at_completion=shared, packing=packer.snapshot(),
                      writer_threads_after_cleanup=writers, queue_empty_after_cleanup=True, leases_released=True,
                      snapshot_at=snapshot_at, unchanged_after_snapshot_through_final_flush=True, fallback_events={},
                      scope='post-exception quiescence and snapshot-to-flush stability only; no GPU-busy/return-boundary claim')
        guard.check('after packed cancellation cleanup')
    finally:
        Pipeline._work, Device._complete = work, descriptor


def jobs():
    cells = [(c, m) for c in ['wikitext', 'massive'] for m in ['raw', 'norm']]
    return ([{'id': f'audit-{c}-{m}', 'kind': 'audit', 'corpus': c, 'mode': m} for c, m in cells]
            + [{'id': f'memory-{c}-{m}-{v}', 'kind': 'memory', 'corpus': c, 'mode': m, 'variant': v} for c, m in cells for v in 'BD']
            + [{'id': f'cancel-massive-{m}', 'kind': 'cancel', 'corpus': 'massive', 'mode': m} for m in ['raw', 'norm']]
            + [{'id': f'timing-{c}-{m}', 'kind': 'timing', 'corpus': c, 'mode': m} for c, m in cells])


def job(path, ready=None, release=None):
    config = read(path)
    folder = Path(config['folder'])
    journal = folder / 'guards.jsonl'
    result = {'status': 'incomplete', 'protocol': protocol(), 'kind': config['kind'], 'job_id': config['id'],
              'corpus_name': config['corpus'], 'mode': config['mode'], 'rounds': [],
              'resume_result': config.get('resume_result'), 'resume_result_sha256': config.get('resume_result_sha256')}
    try:
        result['rounds'] = inherited_rounds(config)
        pulse('resume prefix validated')
        guard = ProgressGuard(S, config['lock'], journal)
        guard.check('before child setup')
        enc, texts, want = setup(config, result, guard)
        if config['kind'] == 'audit': audit(config, result, guard, enc, texts, want)
        elif config['kind'] == 'memory': memory(config, result, guard, enc, texts, want)
        elif config['kind'] == 'cancel': cancellation(config, result, guard, enc, texts, ready, release)
        elif config['kind'] == 'timing':
            timed(config, result, guard, enc, texts, want)
            assert len(result['rounds']) == ROUNDS
        else: raise ValueError('unknown fixed Stage3 job')
        assert safety().identity(REPO, HEAD) == result['identity']
        result['status'] = 'complete'
        pulse('job complete')
    except BaseException as error:
        result['status'] = 'failed'
        result['stop'] = stop_record(error, journal)
    finally:
        write(folder / 'result.json', result)
    return 0 if result['status'] == 'complete' else 2


def inherited_rounds(config):
    path, visited, combined = config.get('resume_result'), set(), []
    expected_digest = config.get('resume_result_sha256')
    while path:
        resolved = str(Path(path).resolve())
        assert resolved not in visited, 'cyclic resume result chain'
        visited.add(resolved)
        assert expected_digest == digest(path), 'immutable resume result changed'
        previous = read(path)
        assert previous['protocol'] == protocol()
        assert previous['job_id'] == config['id']
        assert previous['corpus_name'] == config['corpus'] and previous['mode'] == config['mode']
        assert previous['stop']['retryable_load'] is True
        records = previous['rounds']
        validate_rounds(records)
        overlap = min(len(records), len(combined))
        assert records[:overlap] == combined[:overlap], 'conflicting retained rounds'
        if len(records) > len(combined):
            combined = records
        path = previous.get('resume_result')
        expected_digest = previous.get('resume_result_sha256')
    return list(combined)



def lineage(events, requested):
    starts = [e for e in events if e['kind'] == 'start' and e.get('stage') == 3]
    seen, previous = set(), None
    for event in starts:
        root = str(Path(event['root']).resolve())
        assert root not in seen
        assert event.get('parent_root') == previous, 'branched or skipped lineage'
        seen.add(root)
        previous = root
    if previous is None:
        assert requested is None, 'resume root is not in ledger'
        return None
    assert requested is not None and str(Path(requested).resolve()) == previous, 'only latest terminal root may resume'
    prior = read(Path(previous) / 'state.json')
    assert prior['root'] == previous and prior['status'] != 'complete' and prior['retryable_load'] is True
    assert prior['protocol'] == protocol()
    return prior



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['check', 'run', '_job', '_cancel'])
    parser.add_argument('config', nargs='?')
    parser.add_argument('--resume')
    parser.add_argument('--ready', type=int)
    parser.add_argument('--release', type=int)
    args = parser.parse_args()
    os.chdir(REPO)
    os.environ.update(TMPDIR=str(S), GIT_CEILING_DIRECTORIES=str(S), UV_NO_SYNC='1', UV_OFFLINE='1', HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    api = sys.modules[__name__]
    if args.action == 'check':
        from dr147_stage3_checks import check
        check(api)
    else:
        raise SystemExit(owner(api, args.resume) if args.action == 'run' else cancel_controller(api, args.config) if args.action == '_cancel' else job(args.config, args.ready, args.release))
