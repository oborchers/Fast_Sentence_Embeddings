"""Reviewed Stage2 owner/controller mechanics copied for Stage3, callback API only.
No Linear. No caps. No model action until the separate hash start prompt.
"""
import json
import math
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time
import uuid
from dr147_stage1_supervision import ProgressGuard, pulse, progress_fds, run_job

def cancel_controller(api, path):
    S, __file__ = api.S, api.__file__
    read, write, stop_record = api.read, api.write, api.stop_record
    config = read(path)
    folder = Path(config['folder'])
    guard = ProgressGuard(S, config['lock'], folder / 'controller-guards.jsonl')
    ready_r, ready_w = os.pipe()
    release_r, release_w = os.pipe()
    process = None
    try:
        guard.check('before cancellation witness subprocess')
        child_folder = folder / 'child'
        child_folder.mkdir()
        child_config = {**config, 'folder': str(child_folder)}
        write(child_folder / 'job.json', child_config)
        with (folder / 'cancel-child.log').open('x') as log:
            process = subprocess.Popen([sys.executable, __file__, '_job', str(child_folder / 'job.json'), '--ready', str(ready_w), '--release', str(release_r)],
                                       stdout=log, stderr=subprocess.STDOUT, pass_fds=(ready_w, release_r, *progress_fds()))
            os.close(ready_w)
            ready_w = -1
            os.close(release_r)
            release_r = -1
            data = b''
            while b'\n' not in data:
                if process.poll() is not None:
                    if (child_folder / 'result.json').exists():
                        outcome = read(child_folder / 'result.json')
                        assert outcome['status'] != 'complete'
                        write(folder / 'result.json', outcome)
                        return 2
                    raise RuntimeError('cancel child exited before blocked-call witness')
                available, _, _ = select.select([ready_r], [], [], .25)
                if available:
                    part = os.read(ready_r, 256)
                    if not part:
                        raise RuntimeError('witness pipe EOF')
                    data += part
            proof = json.loads(data.split(b'\n', 1)[0])
            assert proof['event'] == 'blocked_wait_witness' and proof['lock_handshakes']
            guard.check('before SIGINT at witnessed runtime condition wait')
            sent_at = time.monotonic()
            process.send_signal(signal.SIGINT)
            buffered = data.split(b'\n', 1)[1]
            while b'\n' not in buffered:
                if process.poll() is not None:
                    raise RuntimeError('child exited without signal-handler ACK')
                available, _, _ = select.select([ready_r], [], [], .25)
                if available:
                    more = os.read(ready_r, 256)
                    if not more:
                        raise RuntimeError('ACK pipe EOF')
                    buffered += more
            acknowledgement = json.loads(buffered.split(b'\n', 1)[0])
            assert acknowledgement['event'] == 'signal_ack' and acknowledgement['from_sigint_handler'] is True
            assert acknowledgement['pid'] == process.pid and acknowledgement['at'] >= sent_at
            release_at = time.monotonic()
            os.write(release_w, b'R')
            write(folder / 'cancel-witness.json', {'witness': proof, 'signal_sent_at': sent_at,
                                                  'signal_handler_ack': acknowledgement, 'release_at': release_at})
            pulse('signal handler ACK observed and worker released')
            code = process.wait()  # progress supervisor handles concrete stalls, no absolute job cap
            outcome = read(child_folder / 'result.json')
            if code or outcome['status'] != 'complete':
                write(folder / 'result.json', outcome)
                return 2
            guard.check('after cancellation subprocess')
            write(folder / 'result.json', outcome)
            return 0
    except BaseException as error:
        if not (folder / 'result.json').exists():
            write(folder / 'result.json', {'status': 'failed', 'stop': stop_record(error, guard.journal)})
        return 2
    finally:
        for fd in [ready_r, ready_w, release_r, release_w]:
            if fd >= 0:
                os.close(fd)
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)



def owner(api, resume):
    S, HEAD, HERE, DECISION, LEDGER = api.S, api.HEAD, api.HERE, api.DECISION, api.LEDGER
    REPO = api.REPO
    clock_policy, lineage, protocol, jobs = api.clock_policy, api.lineage, api.protocol, api.jobs
    read, write, append, digest, safety = api.read, api.write, api.append, api.digest, api.safety
    stop_record, __file__, NATIVE = api.stop_record, api.__file__, api.NATIVE
    resume = str(Path(resume).resolve()) if resume else None
    from mlx_gate_process import controlled_termination
    assert not (S / 'bench.lock').exists() and not (S / 'pause-local.marker').exists()
    total = clock_policy()
    events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
    prior = lineage(events, resume)
    while True:
        assert not (S / 'pause-local.marker').exists() and not (S / 'bench.lock').exists()
        load = os.getloadavg()[0]
        assert math.isfinite(load), 'nonfinite entry load'
        if load < 5:
            break
        print(f'entry waiting without lock or accounting: load={load}', flush=True)
        time.sleep(15)
    started = time.monotonic()
    lock = safety().acquire(S, HEAD, 'dr147-mlx-m4')
    token = uuid.uuid4().hex
    root = HERE / ('run-' + token[:12])
    root.mkdir()
    state = {'stage': 3, 'root': str(root), 'lock': lock, 'script_sha256': digest(__file__),
             'protocol': protocol(), 'status': 'incomplete', 'decision': str(DECISION),
             'global_before': total, 'matrix_fixed_s': 523.0340705840008,
             'jobs': dict(prior['jobs']) if prior else {}, 'retryable_load': False, 'resume': resume}
    admitted = False
    try:
        # Recheck latest lineage under exclusive bench.lock, immediately before ledger append.
        total = clock_policy()
        events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
        prior = lineage(events, resume)
        append(LEDGER, {'kind': 'start', 'id': token, 'stage': 3, 'root': str(root), 'parent_root': resume,
                        'protocol': protocol(), 'pid': os.getpid(), 'at': time.time(), 'policy': 'no cap'})
        admitted = True
        write(root / 'invocation.json', state)
        with controlled_termination():
            state['identity'] = safety().identity(REPO, HEAD)
            assert state['identity']['native_checksum'] == NATIVE
            for spec in jobs():
                old = state['jobs'].get(spec['id'])
                if old:
                    assert digest(old['result']) == old['result_sha256'], 'immutable result changed'
                if old and old['status'] == 'complete':
                    continue
                folder = root / spec['id']
                folder.mkdir()
                guard = ProgressGuard(S, lock, root / 'parent.jsonl')
                guard.check('before ' + spec['id'])
                config = {**spec, 'folder': str(folder), 'lock': lock}
                if old and spec['kind'] == 'timing':
                    config['resume_result'] = old['result']
                    config['resume_result_sha256'] = old['result_sha256']
                write(folder / 'job.json', config)
                action = '_cancel' if spec['kind'] == 'cancel' else '_job'
                with (folder / 'worker.log').open('x') as log:
                    code = run_job([sys.executable, __file__, action, str(folder / 'job.json')], log,
                                   journal=folder / 'supervision.jsonl')
                outcome = read(folder / 'result.json')
                state['jobs'][spec['id']] = {'status': outcome['status'], 'result': str(folder / 'result.json'),
                                            'result_sha256': digest(folder / 'result.json')}
                if code or outcome['status'] != 'complete':
                    state['stop'] = outcome.get('stop', {'type': 'ProcessFailure', 'reason': f'exit={code}', 'retryable_load': False})
                    state['retryable_load'] = state['stop'].get('retryable_load') is True
                    return 2
                guard.check('after ' + spec['id'])
                print('complete ' + spec['id'], flush=True)
            assert len(state['jobs']) == len(jobs())
            assert safety().identity(REPO, HEAD) == state['identity']
            state['status'] = 'complete'
            return 0
    except BaseException as error:
        state['stop'] = stop_record(error, root / 'parent.jsonl')
        state['retryable_load'] = admitted and state['stop']['retryable_load']
        return 2
    finally:
        elapsed = time.monotonic() - started
        state['active_seconds'] = elapsed
        event = {'kind': 'finish' if admitted else 'admission_rejected', 'id': token, 'stage': 3,
                 'at': time.time(), 'active_seconds': elapsed, 'status': state['status'], 'root': str(root)}
        append(LEDGER, event)
        write(root / 'state.json', state)
        print('Stage3 evidence: ' + str(root) + '; own lock retained for verified Finder cleanup.', flush=True)

