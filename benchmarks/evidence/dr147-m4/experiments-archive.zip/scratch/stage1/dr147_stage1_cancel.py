"""Scratch-only cancellation witness. Actual runtime Condition wait and signal ACK."""
import json
import os
import signal
import threading
import time

HANDSHAKE_SECONDS = 10  # specific lock/witness handshake, no encode amount limit


def send(fd, value):
    data = (json.dumps(value) + '\n').encode()
    assert len(data) <= 4096
    os.write(fd, data)


class InterruptWitness:
    def __init__(self, executor, ready, release):
        self.executor, self.ready, self.release = executor, ready, release
        self.main = threading.current_thread()
        assert self.main is threading.main_thread()
        self.gate_condition = threading.Condition()
        self.gate_reached, self.main_reached, self.cancelled = (threading.Event() for _ in range(3))
        self.released, self.inside_wait = False, False
        self.condition, self.kind = None, None
        self.errors, self.proof = [], {}

    def block_worker(self, kind):
        with self.gate_condition:
            if self.kind is not None:
                return
            self.kind = kind
            self.gate_reached.set()
            while not self.released:
                self.gate_condition.wait()

    def _handler(self, number, frame):
        send(self.ready, {'event': 'signal_ack', 'pid': os.getpid(), 'from_sigint_handler': True,
                          'at': time.monotonic()})
        raise KeyboardInterrupt

    def _observe(self):
        try:
            if not self.gate_reached.wait(HANDSHAKE_SECONDS):
                raise TimeoutError('worker gate not reached')
            if self.cancelled.is_set():
                return
            with self.gate_condition:
                assert not self.released and self.gate_condition._waiters
                worker_proven = time.monotonic()  # acquire only succeeds after worker wait released its lock
            deadline = time.monotonic() + HANDSHAKE_SECONDS
            while True:
                if not self.main_reached.wait(max(0, deadline - time.monotonic())):
                    raise TimeoutError('main runtime wait not reached')
                if self.cancelled.is_set():
                    return
                condition = self.condition
                if not condition.acquire(timeout=max(0, deadline - time.monotonic())):
                    raise TimeoutError('main runtime condition lock unavailable')
                try:
                    waiting = len(condition._waiters)
                    if waiting:
                        self.proof = {'event': 'blocked_wait_witness', 'pid': os.getpid(),
                                      'worker_kind': self.kind, 'worker_gate_wait_proven_at': worker_proven,
                                      'main_runtime_condition_wait_proven_at': time.monotonic(),
                                      'main_condition_waiters': waiting, 'lock_handshakes': True,
                                      'gpu_busy_claim': False}
                        break
                    self.main_reached.clear()
                finally:
                    condition.release()
            send(self.ready, self.proof)
            assert os.read(self.release, 1) == b'R', 'release pipe EOF'
        except BaseException as error:
            self.errors.append({'type': type(error).__name__, 'reason': str(error)})
        finally:
            with self.gate_condition:
                self.released = True
                self.gate_condition.notify_all()

    def __enter__(self):
        self.original_wait = self.executor.wait
        self.original_condition_wait = threading.Condition.wait
        self.original_signal = signal.getsignal(signal.SIGINT)
        def runtime_wait(*args, **kwargs):
            if threading.current_thread() is not self.main:
                return self.original_wait(*args, **kwargs)
            self.inside_wait = True
            try:
                return self.original_wait(*args, **kwargs)
            finally:
                self.inside_wait = False
        def condition_wait(condition, *args, **kwargs):
            if threading.current_thread() is self.main and self.inside_wait:
                self.condition = condition
                self.main_reached.set()  # caller still owns this condition's lock
            return self.original_condition_wait(condition, *args, **kwargs)
        self.executor.wait, threading.Condition.wait = runtime_wait, condition_wait
        signal.signal(signal.SIGINT, self._handler)
        self.observer = threading.Thread(target=self._observe, name='scratch-wait-witness')
        self.observer.start()
        return self

    def __exit__(self, error_type, error, traceback):
        self.cancelled.set()
        self.gate_reached.set()
        self.main_reached.set()
        with self.gate_condition:
            self.released = True
            self.gate_condition.notify_all()
        self.observer.join(timeout=HANDSHAKE_SECONDS)
        self.executor.wait = self.original_wait
        threading.Condition.wait = self.original_condition_wait
        signal.signal(signal.SIGINT, self.original_signal)
        assert not self.observer.is_alive(), 'witness observer did not terminate'
        if self.errors:
            raise RuntimeError(f'witness failed: {self.errors}')
