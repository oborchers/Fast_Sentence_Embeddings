"""Scratch-only stage 1. No model/encode in check. No old Budget validator."""
import time
import argparse
import ctypes as ct
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import select
import signal
import statistics as st
import subprocess
import sys
import threading
import uuid
from contextlib import contextmanager

S = Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch')
REPO = S / 'dr147-mlx-m4'
HEAD = 'ef4d6a7bb33ac65a711458365312a5c0faf0b96a'
NATIVE = 'xxh3-128:2d9d0a93859e347a5220443fab372260'
DECISION = S / 'DR-147-time-limit-removal.json'
LEDGER = S / 'budget.jsonl'
ROUNDS, PASSES = 16, 5
RSS_LIMIT, WORKSPACE_LIMIT = 8 << 30, 512 << 20
from dr147_stage1_supervision import ProgressGuard, pulse, progress_fds, run_job
from dr147_stage1_cancel import InterruptWitness
sys.path.insert(0, str(REPO / 'benchmarks'))


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def append(path, value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value, allow_nan=False) + '\n')
        f.flush()
        os.fsync(f.fileno())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safety():
    import mlx_gate_safety
    return mlx_gate_safety


def clock_policy():
    d = read(DECISION)
    assert d['authorized_by'] == 'Oliver' and all(d['time_limits_removed'].values())
    assert d['received_at'] == '2026-10-31T16:41:07+01:00'
    events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
    assert events[0]['kind'] == 'historical_carry'
    assert events[0]['seconds'] == 596.1948255419993
    assert events[0]['source_sha256'] == digest(S / 'mlx-gate-budget.jsonl')
    starts, ends = set(), set()
    total = events[0]['seconds']
    for e in events[1:]:
        if e['kind'] == 'start':
            assert e['id'] not in starts
            starts.add(e['id'])
        elif e['kind'] == 'finish':
            assert e['id'] in starts and e['id'] not in ends
            assert math.isfinite(e['active_seconds']) and e['active_seconds'] >= 0
            ends.add(e['id'])
            total += e['active_seconds']
        elif e['kind'] == 'admission_rejected':
            assert math.isfinite(e['active_seconds']) and e['active_seconds'] >= 0
            total += e['active_seconds']
        else:
            raise ValueError('unknown accounting event')
    assert starts == ends, 'unresolved accounting start, needs inspection'
    return total


@contextmanager
def partition(patched):
    from fse._runtime._pipeline import Pipeline, STEP_ROW_BYTES
    original = Pipeline._row_bytes
    if patched:
        def raw_partition(self, dtype, inverse=False):
            value = original(self, dtype, inverse)
            return value - STEP_ROW_BYTES * self.output_dim if self.prepared.steps else value
        Pipeline._row_bytes = raw_partition
    try:
        yield
    finally:
        Pipeline._row_bytes = original


class Buffer(ct.Structure):
    _fields_ = [('data', ct.c_void_p), ('size', ct.c_ssize_t), ('capacity', ct.c_ssize_t)]


BUFFER_NAMES = 'cand starts ends word tokens offsets ngram_offsets ngrams norm run lattice cands'.split()


class WorkspaceLayout(ct.Structure):
    _fields_ = [('refcount', ct.c_ssize_t), ('type', ct.c_void_p)] + [
        (n, Buffer) for n in BUFFER_NAMES
    ] + [('busy', ct.c_int), ('tokens_seen', ct.c_int64)]


_LAYOUT_VALIDATED = False


def validate_layout():
    global _LAYOUT_VALIDATED
    if _LAYOUT_VALIDATED:
        return
    from fse import _native
    assert ct.sizeof(ct.c_void_p) == 8
    assert ct.sizeof(WorkspaceLayout) == _native.Workspace.__basicsize__
    generated = (REPO / 'src/fse/_native.c').read_text()
    body = generated.split('struct __pyx_obj_3fse_7_native_Workspace {', 1)[1].split('};', 1)[0]
    fields = [line.strip().split()[-1].rstrip(';') for line in body.splitlines() if '_Buffer ' in line]
    assert fields == BUFFER_NAMES, 'generated C workspace layout changed'
    _LAYOUT_VALIDATED = True


def capacities(ws):
    from fse import _native
    assert _LAYOUT_VALIDATED, 'layout must be parsed once before encode'
    assert type(ws) is _native.Workspace
    layout = WorkspaceLayout.from_address(id(ws))  # object fields only, no buffer data dereference
    assert layout.type == id(type(ws)) and layout.busy == 0
    assert layout.tokens_seen == ws.tokens_seen
    values = {}
    for name in BUFFER_NAMES:
        b = getattr(layout, name)
        assert 0 <= b.size <= b.capacity and (b.data is not None or b.capacity == 0)
        values[name] = {'size': b.size, 'capacity': b.capacity}
    return values


def protocol():
    return {'head': HEAD, 'rounds': ROUNDS, 'passes': PASSES, 'script_sha256': digest(__file__),
            'supervision_sha256': digest(S / 'dr147_stage1_supervision.py'),
            'cancel_sha256': digest(S / 'dr147_stage1_cancel.py')}


def validate_rounds(records):
    assert len(records) <= ROUNDS
    for index, record in enumerate(records):
        assert record['index'] == index
        expected = ['A1', 'B1', 'B2', 'A2'] if index % 2 == 0 else ['B1', 'A1', 'A2', 'B2']
        assert record['order'] == expected
        assert set(record['times']) == {'cpu10', 'cpu12', 'mlx'}
        for sides in record['times'].values():
            assert set(sides) == {'A1', 'A2', 'B1', 'B2'}
            assert all(type(x) in (int, float) and math.isfinite(x) and x > 0 for x in sides.values())


def inherited_rounds(config):
    path, visited, combined = config.get('resume_result'), set(), []
    expected_digest = config.get('resume_result_sha256')
    while path:
        resolved = str(Path(path).resolve())
        assert resolved not in visited, 'cyclic resume result chain'
        visited.add(resolved)
        assert expected_digest == digest(path), 'immutable resume result changed'
        previous = read(path)
        assert previous['protocol'] == protocol()
        assert previous['job_id'] == config['id']
        assert previous['corpus_name'] == config['corpus'] and previous['mode'] == config['mode']
        assert previous['stop']['retryable_load'] is True
        records = previous['rounds']
        validate_rounds(records)
        overlap = min(len(records), len(combined))
        assert records[:overlap] == combined[:overlap], 'conflicting retained rounds'
        if len(records) > len(combined):
            combined = records
        path = previous.get('resume_result')
        expected_digest = previous.get('resume_result_sha256')
    return list(combined)


def lineage(events, requested):
    starts = [e for e in events if e['kind'] == 'start' and e.get('stage') == 1]
    seen, previous = set(), None
    for event in starts:
        root = str(Path(event['root']).resolve())
        assert root not in seen
        assert event.get('parent_root') == previous, 'branched or skipped lineage'
        seen.add(root)
        previous = root
    if previous is None:
        assert requested is None, 'resume root is not in ledger'
        return None
    assert requested is not None and str(Path(requested).resolve()) == previous, 'only latest terminal root may resume'
    prior = read(Path(previous) / 'state.json')
    assert prior['root'] == previous and prior['status'] != 'complete' and prior['retryable_load'] is True
    assert prior['protocol'] == protocol()
    return prior


def stop_record(error, journal):
    from mlx_gate_safety import StopError
    records = [json.loads(x) for x in Path(journal).read_text().splitlines()] if Path(journal).exists() else []
    guards = [x for x in records if x.get('event') == 'guard']
    last = guards[-1] if guards else {}
    load = last.get('load')
    retry = (isinstance(error, StopError) and type(load) in (int, float) and math.isfinite(load)
             and load >= 5 and str(error) == f'load {load} is not strictly below 5')
    return {'type': type(error).__name__, 'reason': str(error), 'retryable_load': retry}


def setup(config, result, guard):
    import numpy as np
    from mlx_gate_data import Cell, encoder, corpus, describe
    ident = safety().identity(REPO, HEAD)
    assert ident['native_checksum'] == NATIVE and ident['default_workers'] == 12
    cell = Cell('static-retrieval-mrl-en-v1', 1024, config['corpus'], config['mode'], 'float32')
    guard.check('before model and corpus')
    receipt = read(S / 'dr147-cache-receipt.json')
    enc = encoder(cell, receipt)
    texts, data = corpus(cell, receipt)
    evidence = read(REPO / 'benchmarks/evidence/dr147-m4/matrix.json')
    accepted = next(c for c in evidence['cells'] if c['key'] == cell.key)
    assert data['checksum'] == evidence['corpora'][cell.corpus]['checksum']
    ref_path = S / accepted['root'] / cell.key / 'cpu.npy'
    want = np.load(ref_path, mmap_mode='r', allow_pickle=False)
    assert want.shape == (len(texts), 1024) and want.dtype == np.float32
    result.update(identity=ident, cell=describe(cell, enc), corpus=data,
                  reference=str(ref_path), reference_source_commit=accepted['driver_commit'])
    guard.check('after model and corpus')
    return enc, texts, want


def plan_details(pipe, texts, workers, patched):
    from fse._text import StringSource
    with partition(patched):
        rb = pipe._row_bytes('float32')
        plans, window, _ = pipe.plan_tasks(StringSource(texts), workers, None, rb)
        spans = [[t.first_row, t.n_rows] for t in plans.tasks]
    return {'row_bytes': rb, 'window': window, 'task_rows_limit': min(pipe.task_rows, (1 << 29) // (window * rb)),
            'tasks': len(spans), 'spans': spans}


def spread(values):
    return {'values': values, 'median': st.median(values), 'min': min(values), 'max': max(values)}


def summarize(rounds, texts):
    ratios, throughput, absolute = {}, {}, {}
    for backend in ['cpu10', 'cpu12', 'mlx']:
        for numerator, denominator in [('B1', 'A1'), ('B2', 'A2'), ('A2', 'A1'), ('B2', 'B1')]:
            name = f'{backend}:{numerator}/{denominator}'
            ratios[name] = spread([r['times'][backend][numerator] / r['times'][backend][denominator] for r in rounds])
        ratios[f'{backend}:all_B/A'] = spread([
            r['times'][backend][b] / r['times'][backend][a]
            for r in rounds for b, a in [('B1', 'A1'), ('B2', 'A2')]])
        for side in ['A1', 'B1', 'B2', 'A2']:
            values = [r['times'][backend][side] for r in rounds]
            throughput[f'{backend}:{side}'] = spread([texts / value for value in values])
            absolute[f'{backend}:{side}'] = spread(values)
    for cpu in ['cpu10', 'cpu12']:
        for mvariant in ['A', 'B']:
            for cvariant in ['A', 'B']:
                ratios[f'mlx:{mvariant}/{cpu}:{cvariant}'] = spread([
                    r['times']['mlx'][mvariant + str(i)] / r['times'][cpu][cvariant + str(i)]
                    for r in rounds for i in [1, 2]])
    return {'ratios': ratios, 'texts_per_s': throughput, 'absolute_seconds': absolute,
            'scope': '32 ratios clustered in16 alternating blocks; not32 independent rounds'}


def timed(config, result, guard, enc, texts, want):
    import numpy as np
    from fse._runtime._pipeline import Pipeline
    from mlx_gate_parity import counts, delta, equal, launches
    original = Pipeline._row_bytes
    backends = [('cpu10', 'cpu', 10), ('cpu12', 'cpu', 12), ('mlx', 'mlx', 12)]
    plans = {}
    for label, backend, workers in backends:
        pipe = enc._pipeline(backend)  # includes MLX canary before launch observation
        for patched in [False, True]:
            guard.check('before warm structural observation')
            detail = plan_details(pipe, texts, workers, patched)
            with partition(patched), launches() as seen:
                before = counts(enc)
                rows = enc.encode(texts, backend=backend, workers=workers)
            equal(rows, want)
            assert delta(counts(enc), before) == {}
            detail['gpu_launches'] = len(seen)
            if backend == 'mlx':
                assert len(seen) == detail['tasks'] > 0
            plans[f'{label}:{"B" if patched else "A"}'] = detail
            guard.check('after warm structural observation')
        b = plans[f'{label}:B']
        raw_rb = plans[f'{label}:A']['row_bytes'] - (12288 if config['mode'] == 'norm' else 0)
        expected, _, _ = pipe.plan_tasks(__import__('fse._text', fromlist=['StringSource']).StringSource(texts), workers, None, raw_rb)
        assert b['spans'] == [[t.first_row, t.n_rows] for t in expected.tasks]
    result['plans'] = plans
    baseline = counts(enc)
    result.setdefault('rounds', [])
    for index in range(len(result['rounds']), ROUNDS):
        guard.check(f'round{index} before')
        order = ['A1', 'B1', 'B2', 'A2'] if index % 2 == 0 else ['B1', 'A1', 'A2', 'B2']
        block = backends if index % 2 == 0 else list(reversed(backends))
        record = {'index': index, 'times': {}, 'order': order, 'backends': [b[0] for b in block]}
        result['incomplete_round'] = record
        for label, backend, workers in block:
            record['times'][label] = {}
            for side in order:
                guard.check(f'{index}:{label}:{side} before side')
                if side.startswith('A'):
                    assert Pipeline._row_bytes is original
                with partition(side.startswith('B')):
                    durations = []
                    for n in range(PASSES):
                        before = guard.check(f'{index}:{label}:{side}:{n} before pass')
                        start = time.perf_counter_ns()
                        rows = enc.encode(texts, backend=backend, workers=workers)
                        elapsed = (time.perf_counter_ns() - start) / 1e9
                        load_after = os.getloadavg()[0]
                        event = {'event': 'pass', 'round': index, 'backend': label, 'side': side, 'pass': n,
                                 'seconds': elapsed, 'load_before': before['load'], 'load_after': load_after if math.isfinite(load_after) else None}
                        append(guard.journal, event)
                        equal(rows, want)  # outside encode clock, even if the load guard will reject
                        assert delta(counts(enc), baseline) == {}, 'fallback event'
                        append(guard.journal, {'event': 'pass_validated', 'round': index, 'backend': label,
                                               'side': side, 'pass': n, 'bits_equal': True, 'fallback_events': {}})
                        guard.check(f'{index}:{label}:{side}:{n} after pass', sample=load_after)
                        durations.append(elapsed)
                    record['times'][label][side] = min(durations)
                assert Pipeline._row_bytes is original
                guard.check(f'{index}:{label}:{side} after side')
        guard.check(f'round{index} after')
        result['rounds'].append(record)
        result.pop('incomplete_round')
        append(guard.journal, {'event': 'round_kept', **record})
    result['summary'] = summarize(result['rounds'], len(texts))
    result['bits_equal'], result['fallback_events'] = True, delta(counts(enc), baseline)


def memory(config, result, guard, enc, texts, want):
    from fse._runtime import _pipeline as module
    from mlx_gate_parity import equal, counts, delta, launches
    pipe = enc._pipeline(config['backend'])
    objects, original = [], module.new_workspace
    def capture():
        ws = original()
        objects.append(ws)
        return ws
    validate_layout()
    result['plan'] = plan_details(pipe, texts, config['workers'], config['patched'])
    result['memory_scope'] = 'first RSS includes startup/encode but excludes reader/bits; second includes instrumentation; posthoc stopping checks only, not an enforced live memory limit'
    result['capacity_scope'] = 'observed native Workspace buffers only, not the complete runtime window contract'
    before = counts(enc)
    guard.check('before memory encode')
    module.new_workspace = capture
    try:
        with partition(config['patched']), launches() as seen:
            rows = enc.encode(texts, backend=config['backend'], workers=config['workers'])
    finally:
        module.new_workspace = original
    result['rss_peak_before_reader_and_bits_bytes'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    values = [capacities(w) for w in objects]
    result['workspace_buffers'] = values
    result['workspace_capacity_bytes'] = sum(b['capacity'] for w in values for b in w.values())
    assert result['workspace_capacity_bytes'] <= WORKSPACE_LIMIT, 'workspace safety bound'
    assert result['rss_peak_before_reader_and_bits_bytes'] <= RSS_LIMIT, 'process RSS safety bound'
    assert objects, 'no real workspaces observed'
    equal(rows, want)
    result['fallback_events'] = delta(counts(enc), before)
    assert result['fallback_events'] == {}
    result['gpu_launches'], result['bits_equal'] = len(seen), True
    result['rss_safety_peak_with_reader_and_bits_bytes'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    assert result['rss_safety_peak_with_reader_and_bits_bytes'] <= RSS_LIMIT, 'verification RSS safety bound'
    guard.check('after memory encode and bits')


def cancellation(config, result, guard, enc, texts, ready, release):
    import numpy as np
    from fse._runtime import _executor
    from fse._runtime._pipeline import Pipeline
    from fse._backends._mlx._device import Device
    from mlx_gate_parity import counts, delta
    pipe = enc._pipeline(config['backend'])
    baseline = counts(enc)
    original_work, original_complete = Pipeline._work, vars(Device)['_complete']
    complete, targets = Device._complete, []
    with InterruptWitness(_executor, ready, release) as witness:
        def work(self, local, task, target, base):
            targets.append(target[0])
            if config['backend'] == 'cpu' and task.first_row == 0:
                witness.block_worker('cpu_oldest_work_gate')
            return original_work(self, local, task, target, base)
        def finish(mx, launched):
            if launched:
                witness.block_worker('gpu_submitted_before_complete')
            return complete(mx, launched)
        Pipeline._work, Device._complete = work, staticmethod(finish)
        guard.check('before cancellation encode')
        try:
            with partition(True):
                try:
                    enc.encode(texts, backend=config['backend'], workers=12)
                except KeyboardInterrupt:
                    result['keyboard_interrupt'] = True
                else:
                    raise AssertionError('SIGINT witness did not interrupt encode')
        finally:
            Pipeline._work, Device._complete = original_work, original_complete
    assert witness.proof and targets
    writers = [t.name for t in threading.enumerate() if t.name.startswith(('fse-worker', 'fse-mlx'))]
    assert not writers, 'runtime writer still live after exception cleanup'
    snapshots = [a.view(np.uint32).copy() for a in targets]
    snapshot_at = time.monotonic()
    queue_empty = None
    if config['backend'] == 'mlx':
        device = pipe.backend.device
        queue_empty = not device._queue and device._thread is None
        assert queue_empty
        device.core().synchronize(device._stream)
    assert all(np.array_equal(a.view(np.uint32), b) for a, b in zip(targets, snapshots, strict=True)), 'buffer changed after snapshot through final GPU flush'
    result.update(targets_observed=len(targets), writer_threads_after_cleanup=writers,
                  queue_empty_after_cleanup=queue_empty, snapshot_at=snapshot_at,
                  unchanged_after_snapshot_through_final_flush=True, blocked_wait_proof=witness.proof,
                  scope='post-exception quiescence plus snapshot-to-flush stability; not exact return-boundary write attribution',
                  fallback_events=delta(counts(enc), baseline), witness_is_not_duration_measurement=True)
    assert result['fallback_events'] == {}
    guard.check('after cancellation cleanup')


def job(path, ready=None, release=None):
    config = read(path)
    folder = Path(config['folder'])
    journal = folder / 'guards.jsonl'
    result = {'status': 'incomplete', 'script_sha256': digest(__file__), 'protocol': protocol(),
              'kind': config['kind'], 'job_id': config['id'], 'corpus_name': config['corpus'],
              'mode': config['mode'], 'rounds': [], 'resume_result': config.get('resume_result'),
              'resume_result_sha256': config.get('resume_result_sha256')}
    try:
        # Retain the immutable prefix before any guard, import, setup or warmup can stop.
        result['rounds'] = inherited_rounds(config)
        pulse('resume prefix validated')
        guard = ProgressGuard(S, config['lock'], journal)
        guard.check('before child setup')
        enc, texts, want = setup(config, result, guard)
        if config['kind'] == 'timing':
            timed(config, result, guard, enc, texts, want)
            assert len(result['rounds']) == ROUNDS
        elif config['kind'] == 'memory':
            memory(config, result, guard, enc, texts, want)
        elif config['kind'] == 'cancel':
            cancellation(config, result, guard, enc, texts, ready, release)
        else:
            raise ValueError('unknown fixed stage1 job')
        assert safety().identity(REPO, HEAD) == result['identity'], 'identity changed'
        result['status'] = 'complete'
        pulse('job complete')
    except BaseException as error:
        result['status'] = 'failed'
        result['stop'] = stop_record(error, journal)
    finally:
        write(folder / 'result.json', result)
    return 0 if result['status'] == 'complete' else 2


def cancel_controller(path):
    config = read(path)
    folder = Path(config['folder'])
    guard = ProgressGuard(S, config['lock'], folder / 'controller-guards.jsonl')
    ready_r, ready_w = os.pipe()
    release_r, release_w = os.pipe()
    process = None
    try:
        guard.check('before cancellation witness subprocess')
        child_folder = folder / 'child'
        child_folder.mkdir()
        child_config = {**config, 'folder': str(child_folder)}
        write(child_folder / 'job.json', child_config)
        with (folder / 'cancel-child.log').open('x') as log:
            process = subprocess.Popen([sys.executable, __file__, '_job', str(child_folder / 'job.json'), '--ready', str(ready_w), '--release', str(release_r)],
                                       stdout=log, stderr=subprocess.STDOUT, pass_fds=(ready_w, release_r, *progress_fds()))
            os.close(ready_w)
            ready_w = -1
            os.close(release_r)
            release_r = -1
            data = b''
            while b'\n' not in data:
                if process.poll() is not None:
                    if (child_folder / 'result.json').exists():
                        outcome = read(child_folder / 'result.json')
                        assert outcome['status'] != 'complete'
                        write(folder / 'result.json', outcome)
                        return 2
                    raise RuntimeError('cancel child exited before blocked-call witness')
                available, _, _ = select.select([ready_r], [], [], .25)
                if available:
                    part = os.read(ready_r, 256)
                    if not part:
                        raise RuntimeError('witness pipe EOF')
                    data += part
            proof = json.loads(data.split(b'\n', 1)[0])
            assert proof['event'] == 'blocked_wait_witness' and proof['lock_handshakes']
            guard.check('before SIGINT at witnessed runtime condition wait')
            sent_at = time.monotonic()
            process.send_signal(signal.SIGINT)
            buffered = data.split(b'\n', 1)[1]
            while b'\n' not in buffered:
                if process.poll() is not None:
                    raise RuntimeError('child exited without signal-handler ACK')
                available, _, _ = select.select([ready_r], [], [], .25)
                if available:
                    more = os.read(ready_r, 256)
                    if not more:
                        raise RuntimeError('ACK pipe EOF')
                    buffered += more
            acknowledgement = json.loads(buffered.split(b'\n', 1)[0])
            assert acknowledgement['event'] == 'signal_ack' and acknowledgement['from_sigint_handler'] is True
            assert acknowledgement['pid'] == process.pid and acknowledgement['at'] >= sent_at
            release_at = time.monotonic()
            os.write(release_w, b'R')
            write(folder / 'cancel-witness.json', {'witness': proof, 'signal_sent_at': sent_at,
                                                  'signal_handler_ack': acknowledgement, 'release_at': release_at})
            pulse('signal handler ACK observed and worker released')
            code = process.wait()  # progress supervisor handles concrete stalls, no absolute job cap
            outcome = read(child_folder / 'result.json')
            if code or outcome['status'] != 'complete':
                write(folder / 'result.json', outcome)
                return 2
            guard.check('after cancellation subprocess')
            write(folder / 'result.json', outcome)
            return 0
    except BaseException as error:
        if not (folder / 'result.json').exists():
            write(folder / 'result.json', {'status': 'failed', 'stop': stop_record(error, guard.journal)})
        return 2
    finally:
        for fd in [ready_r, ready_w, release_r, release_w]:
            if fd >= 0:
                os.close(fd)
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)


def jobs():
    result = []
    for corpus in ['wikitext', 'massive']:
        for label, backend, workers in [('cpu10', 'cpu', 10), ('cpu12', 'cpu', 12), ('mlx', 'mlx', 12)]:
            for patched in [False, True]:
                result.append({'id': f'memory-{corpus}-{label}-{"B" if patched else "A"}', 'kind': 'memory',
                               'corpus': corpus, 'mode': 'norm', 'backend': backend, 'workers': workers, 'patched': patched})
    for backend in ['cpu', 'mlx']:
        result.append({'id': f'cancel-{backend}', 'kind': 'cancel', 'corpus': 'massive', 'mode': 'norm', 'backend': backend})
    for corpus in ['wikitext', 'massive']:
        for mode in ['raw', 'norm']:
            result.append({'id': f'timing-{corpus}-{mode}', 'kind': 'timing', 'corpus': corpus, 'mode': mode})
    return result


def owner(resume):
    resume = str(Path(resume).resolve()) if resume else None
    from mlx_gate_process import controlled_termination
    assert not (S / 'bench.lock').exists() and not (S / 'pause-local.marker').exists()
    total = clock_policy()
    events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
    prior = lineage(events, resume)
    while True:
        assert not (S / 'pause-local.marker').exists() and not (S / 'bench.lock').exists()
        load = os.getloadavg()[0]
        assert math.isfinite(load), 'nonfinite entry load'
        if load < 5:
            break
        print(f'entry waiting without lock or accounting: load={load}', flush=True)
        time.sleep(15)
    started = time.monotonic()
    lock = safety().acquire(S, HEAD, 'dr147-mlx-m4')
    token = uuid.uuid4().hex
    root = S / ('dr147-stage1-' + token[:12])
    root.mkdir()
    state = {'stage': 1, 'root': str(root), 'lock': lock, 'script_sha256': digest(__file__),
             'protocol': protocol(), 'status': 'incomplete', 'decision': str(DECISION),
             'global_before': total, 'matrix_fixed_s': 523.0340705840008,
             'jobs': dict(prior['jobs']) if prior else {}, 'retryable_load': False, 'resume': resume}
    admitted = False
    try:
        # Recheck latest lineage under exclusive bench.lock, immediately before ledger append.
        total = clock_policy()
        events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
        prior = lineage(events, resume)
        append(LEDGER, {'kind': 'start', 'id': token, 'stage': 1, 'root': str(root), 'parent_root': resume,
                        'protocol': protocol(), 'pid': os.getpid(), 'at': time.time(), 'policy': 'no cap'})
        admitted = True
        write(root / 'invocation.json', state)
        with controlled_termination():
            state['identity'] = safety().identity(REPO, HEAD)
            assert state['identity']['native_checksum'] == NATIVE
            for spec in jobs():
                old = state['jobs'].get(spec['id'])
                if old:
                    assert digest(old['result']) == old['result_sha256'], 'immutable result changed'
                if old and old['status'] == 'complete':
                    continue
                folder = root / spec['id']
                folder.mkdir()
                guard = ProgressGuard(S, lock, root / 'parent.jsonl')
                guard.check('before ' + spec['id'])
                config = {**spec, 'folder': str(folder), 'lock': lock}
                if old and spec['kind'] == 'timing':
                    config['resume_result'] = old['result']
                    config['resume_result_sha256'] = old['result_sha256']
                write(folder / 'job.json', config)
                action = '_cancel' if spec['kind'] == 'cancel' else '_job'
                with (folder / 'worker.log').open('x') as log:
                    code = run_job([sys.executable, __file__, action, str(folder / 'job.json')], log,
                                   journal=folder / 'supervision.jsonl')
                outcome = read(folder / 'result.json')
                state['jobs'][spec['id']] = {'status': outcome['status'], 'result': str(folder / 'result.json'),
                                            'result_sha256': digest(folder / 'result.json')}
                if code or outcome['status'] != 'complete':
                    state['stop'] = outcome.get('stop', {'type': 'ProcessFailure', 'reason': f'exit={code}', 'retryable_load': False})
                    state['retryable_load'] = state['stop'].get('retryable_load') is True
                    return 2
                guard.check('after ' + spec['id'])
                print('complete ' + spec['id'], flush=True)
            assert len(state['jobs']) == len(jobs())
            assert safety().identity(REPO, HEAD) == state['identity']
            state['status'] = 'complete'
            return 0
    except BaseException as error:
        state['stop'] = stop_record(error, root / 'parent.jsonl')
        state['retryable_load'] = admitted and state['stop']['retryable_load']
        return 2
    finally:
        elapsed = time.monotonic() - started
        state['active_seconds'] = elapsed
        event = {'kind': 'finish' if admitted else 'admission_rejected', 'id': token, 'stage': 1,
                 'at': time.time(), 'active_seconds': elapsed, 'status': state['status'], 'root': str(root)}
        append(LEDGER, event)
        write(root / 'state.json', state)
        print('Stage1 evidence: ' + str(root) + '; own lock retained for verified Finder cleanup.', flush=True)


def check():
    from types import SimpleNamespace
    from fse import _native
    from fse._runtime._pipeline import Pipeline
    checks = []
    original = Pipeline._row_bytes
    for device in [False, True]:
        dummy = SimpleNamespace(output_dim=1024, _device_rows=device, prepared=SimpleNamespace(steps=(1,)))
        a = Pipeline._row_bytes(dummy, 'float32')
        with partition(True):
            b = Pipeline._row_bytes(dummy, 'float32')
        assert Pipeline._row_bytes is original and a - b == 12288
        checks.append({'device': device, 'original': a, 'raw_partition': b})
    validate_layout()
    assert all(v['capacity'] == 0 for v in capacities(_native.Workspace()).values())
    assert len(jobs()) == 18 and ROUNDS >= 15 and PASSES == 5
    print(json.dumps({'status': 'scalar/layout/identity preflight only', 'models_loaded': False, 'encodes': 0,
                      'partitions': checks, 'identity': safety().identity(REPO, HEAD), 'global_actual_seconds': clock_policy(),
                      'rounds': ROUNDS, 'passes': PASSES, 'jobs': jobs(), 'script_sha256': digest(__file__)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['check', 'run', '_job', '_cancel'])
    parser.add_argument('config', nargs='?')
    parser.add_argument('--resume')
    parser.add_argument('--ready', type=int)
    parser.add_argument('--release', type=int)
    args = parser.parse_args()
    os.chdir(REPO)
    os.environ.update(TMPDIR=str(S), GIT_CEILING_DIRECTORIES=str(S), UV_NO_SYNC='1', UV_OFFLINE='1', HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    if args.action == 'check':
        check()
    else:
        raise SystemExit(owner(args.resume) if args.action == 'run' else cancel_controller(args.config) if args.action == '_cancel' else job(args.config, args.ready, args.release))
