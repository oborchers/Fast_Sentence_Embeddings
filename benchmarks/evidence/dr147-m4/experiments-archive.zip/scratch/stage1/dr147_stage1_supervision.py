"""Scratch-only owner-EOF and real-progress supervision. No absolute job deadline."""
import json
import math
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time

POLL_SECONDS = .25
TERM_GRACE = .25
CLEANUP_SECONDS = 3
STALL_SECONDS = 120  # no observed phase/pass progress for this interval


def pulse(label):
    """Call only at real phase/pass transitions, never from a periodic heartbeat."""
    descriptor = os.environ.get('DR147_PROGRESS_FD')
    if descriptor is not None:
        value = {'event': 'progress', 'pid': os.getpid(), 'label': label, 'at': time.monotonic()}
        data = (json.dumps(value) + '\n').encode()
        assert len(data) <= 4096
        os.write(int(descriptor), data)


def progress_fds():
    descriptor = os.environ.get('DR147_PROGRESS_FD')
    return () if descriptor is None else (int(descriptor),)


class ProgressGuard:
    def __init__(self, scratch, lock, journal):
        from mlx_gate_safety import Guard
        self.original = Guard(scratch, lock, 5, float('inf'), journal)
        self.journal = journal

    def check(self, label, **kwargs):
        value = self.original.check(label, **kwargs)
        pulse(label)
        return value


def stall_expired(last_progress, now, interval):
    return now - last_progress >= interval


def kill_group(child):
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        child.wait(timeout=TERM_GRACE)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait(timeout=CLEANUP_SECONDS)


def watch(child, owner_fd, progress_fd, interval, journal):
    last, buffered = time.monotonic(), b''
    with Path(journal).open('x') as stream:
        while True:
            code = child.poll()
            if code is not None:
                return code if code >= 0 else 128 - code
            now = time.monotonic()
            if stall_expired(last, now, interval):
                stream.write(json.dumps({'event': 'progress_stall', 'at': now, 'seconds_without_progress': now - last}) + '\n')
                stream.flush()
                return 124
            ready, _, _ = select.select([owner_fd, progress_fd], [], [], min(POLL_SECONDS, interval - (now - last)))
            if owner_fd in ready and not os.read(owner_fd, 1):
                stream.write(json.dumps({'event': 'owner_eof', 'at': time.monotonic()}) + '\n')
                stream.flush()
                return 125
            if progress_fd in ready:
                data = os.read(progress_fd, 65536)
                if not data:
                    try:
                        code = child.wait(timeout=POLL_SECONDS)
                        return code if code >= 0 else 128 - code
                    except subprocess.TimeoutExpired:
                        stream.write(json.dumps({'event': 'progress_pipe_lost', 'at': time.monotonic()}) + '\n')
                        stream.flush()
                        return 126
                buffered += data
                while b'\n' in buffered:
                    line, buffered = buffered.split(b'\n', 1)
                    event = json.loads(line)
                    if event.get('event') != 'progress' or not isinstance(event.get('label'), str):
                        raise ValueError('invalid progress record')
                    if not math.isfinite(event['at']) or event['at'] > time.monotonic():
                        raise ValueError('invalid progress time')
                    # A transition already queued is not a new transition at read time.
                    last = max(last, event['at'])
                    stream.write(json.dumps(event) + '\n')
                    stream.flush()


def supervise(owner_fd, progress_r, progress_w, interval, journal, command):
    from mlx_gate_process import controlled_termination
    assert math.isfinite(interval) and interval > 0
    if select.select([owner_fd], [], [], 0)[0] and not os.read(owner_fd, 1):
        return 125
    environment = dict(os.environ, DR147_PROGRESS_FD=str(progress_w))
    child = None
    with controlled_termination():
        try:
            child = subprocess.Popen(command, env=environment, pass_fds=(progress_w,), start_new_session=True)
            os.close(progress_w)
            progress_w = -1
            return watch(child, owner_fd, progress_r, interval, journal)
        finally:
            if progress_w >= 0:
                os.close(progress_w)
            if child is not None:
                kill_group(child)


def run_job(command, log, *, journal, stall_seconds=STALL_SECONDS):
    from mlx_gate_process import controlled_termination
    owner_r, owner_w = os.pipe()
    progress_r, progress_w = os.pipe()
    supervisor = None
    try:
        with controlled_termination():
            supervisor = subprocess.Popen([sys.executable, __file__, '_supervise', str(owner_r), str(progress_r), str(progress_w), str(stall_seconds), str(journal), *command],
                                          stdout=log, stderr=subprocess.STDOUT,
                                          pass_fds=(owner_r, progress_r, progress_w), start_new_session=True)
            for fd in (owner_r, progress_r, progress_w):
                os.close(fd)
            owner_r = progress_r = progress_w = -1
            return supervisor.wait()  # no amount-of-work deadline
    finally:
        for fd in (owner_w, owner_r, progress_r, progress_w):
            if fd >= 0:
                os.close(fd)
        if supervisor is not None:
            try:
                supervisor.wait(timeout=CLEANUP_SECONDS)
            except subprocess.TimeoutExpired:
                supervisor.terminate()
                try:
                    supervisor.wait(timeout=CLEANUP_SECONDS)
                except subprocess.TimeoutExpired:
                    supervisor.kill()
                    supervisor.wait(timeout=CLEANUP_SECONDS)


if __name__ == '__main__':
    root = Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch/dr147-mlx-m4')
    sys.path.insert(0, str(root / 'benchmarks'))
    assert sys.argv[1] == '_supervise'
    raise SystemExit(supervise(*(int(x) for x in sys.argv[2:5]), float(sys.argv[5]), sys.argv[6], sys.argv[7:]))
