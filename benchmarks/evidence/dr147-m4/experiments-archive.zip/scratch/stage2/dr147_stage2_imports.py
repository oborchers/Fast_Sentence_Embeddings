"""Stage2-only public imports. Never pad, realign, stage, copy-fallback or change shaders."""
import gc
import hashlib
import json
import os
import weakref
from contextlib import contextmanager

import numpy as np


class PublicImportUnavailable(RuntimeError):
    def __init__(self, details):
        self.details = details
        super().__init__(json.dumps(details, sort_keys=True))


def content_hash(array):
    return hashlib.sha256(memoryview(array).cast('B')).hexdigest()


class LaunchProxy:
    __slots__ = ('mx', 'expected', 'imports', 'index', 'owner_records')
    def __init__(self, mx, expected, imports):
        self.mx, self.expected, self.imports = mx, expected, imports
        self.index, self.owner_records = 0, []
    def __getattr__(self, name):
        return getattr(self.mx, name)
    def array(self, host):
        index = self.index
        self.index += 1
        assert index < 5 and host is self.expected[index]
        if index < 2:
            result, record = self.imports.adopt(self.mx, host, ['tokens', 'offsets'][index],
                                                proof=self.imports.mode != 'none', hold=self.imports.mode == 'content')
            if record is not None:
                self.imports.records.append(record)
                self.owner_records.append(record)
            return result
        return self.imports.dummies[index - 2]


class TaskImports:
    def __init__(self):
        self.dummies = None
        self.records = []
        self.registry = {}
        self.active = False
        self.last_refusal = None
        self.dummy_identity = None
        self.mode = 'none'

    def prepare(self, mx):
        assert self.dummies is None and not self.active
        self.dummies = tuple(mx.array(np.zeros(1, np.uint32)) for _ in range(3))
        mx.eval(*self.dummies)
        self.dummy_identity = tuple(map(id, self.dummies))
        self.check_dummies()

    def check_dummies(self):
        assert self.dummy_identity == tuple(map(id, self.dummies))
        for dummy in self.dummies:
            view = np.asarray(dummy)
            assert view.dtype == np.uint32 and view.shape == (1,) and not view[0]

    def adopt(self, mx, host, role, proof=False, hold=False):
        assert isinstance(host, np.ndarray) and host.dtype == np.uint32
        assert host.ndim == 1 and host.flags.c_contiguous and host.nbytes > 0
        def describe_host():
            return {'role': role, 'dtype': host.dtype.str, 'shape': list(host.shape),
                    'strides': list(host.strides), 'nbytes': host.nbytes,
                    'pointer_mod_itemsize': host.ctypes.data % host.itemsize,
                    'pointer_mod_page': host.ctypes.data % os.sysconf('SC_PAGE_SIZE'),
                    'host_owndata': bool(host.flags.owndata), 'host_writeable': bool(host.flags.writeable)}
        try:
            imported = mx.asarray(host, copy=False)
        except (ValueError, TypeError) as error:
            self.last_refusal = {**describe_host(), 'cause_type': type(error).__name__, 'cause': str(error),
                                 'copy_requested': False, 'fallback_attempted': False}
            raise PublicImportUnavailable(self.last_refusal) from error
        record = None
        if proof:
            metadata = describe_host()
            assert metadata['pointer_mod_itemsize'] == 0
            view = np.asarray(imported)
            assert view.dtype == host.dtype and view.shape == host.shape and view.strides == host.strides
            assert view.ctypes.data == host.ctypes.data and np.shares_memory(view, host), 'API result did not alias host'
            record = {'metadata': {**metadata, 'pointer_equal': True, 'shares_memory': True},
                      'owner': weakref.ref(host), 'strong': host if hold else None,
                      'hash_before': content_hash(host)}
        return imported, record

    def launch(self, original, mx, stream, table, task, normalize=False):
        assert self.dummies is not None and not table.fasttext and not task.unknown
        expected = task.arrays
        assert len(expected) == 5
        proxy = LaunchProxy(mx, expected, self)
        launched = original(proxy, stream, table, task, normalize)
        assert proxy.index == 5
        if self.mode == 'lease':
            assert id(launched) not in self.registry, 'live output identity collision'
            self.registry[id(launched)] = proxy.owner_records
        return launched

    @contextmanager
    def installed(self, kernels, mode='none'):
        assert mode in ['none', 'content', 'lease'] and not self.active
        assert self.dummies is not None and not self.records and not self.registry
        original = kernels.launch
        def imported(mx, stream, table, task, normalize=False):
            return self.launch(original, mx, stream, table, task, normalize)
        self.active, self.mode = True, mode
        kernels.launch = imported
        try:
            yield
        finally:
            kernels.launch = original
            self.active = False
            self.mode = 'none'

    def live_before_complete(self, launched):
        for _, arrays in launched:
            records = self.registry.pop(id(arrays))
            assert len(records) == 2
            for record in records:
                host = record['owner']()
                assert host is not None, 'input owner died before observed completion'
                assert content_hash(host) == record['hash_before'], 'live input changed'
                record['metadata']['alive_before_complete'] = True

    @staticmethod
    def _check_content(record):
        host = record['owner']()
        assert host is not None and content_hash(host) == record['hash_before'], 'input content changed'
        assert list(host.shape) == record['metadata']['shape'] and list(host.strides) == record['metadata']['strides']
        assert bool(host.flags.writeable) == record['metadata']['host_writeable']
        return {**record['metadata'], 'hash_before': record['hash_before'],
                'hash_after': content_hash(host), 'unchanged_through_flush': True}

    def finish_content_audit(self):
        report = [self._check_content(record) for record in self.records]
        weak = [record['owner'] for record in self.records]
        for record in self.records:
            record['strong'] = None
        self.records.clear()
        self.registry.clear()
        gc.collect()
        assert not any(ref() is not None for ref in weak), 'input retained after released content audit'
        return report

    def finish_lease_audit(self):
        assert not self.registry, 'launched group not observed at completion'
        assert self.records and all(record['metadata'].get('alive_before_complete') for record in self.records)
        report = [dict(record['metadata']) for record in self.records]
        weak = [record['owner'] for record in self.records]
        self.records.clear()
        gc.collect()
        assert not any(ref() is not None for ref in weak), 'input owner retained after cancellation cleanup/flush'
        return report
