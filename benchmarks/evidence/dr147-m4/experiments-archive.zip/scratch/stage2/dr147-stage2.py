"""Stage2 preparation. Data actions require separate inspection/start prompt.

No Linear access, including read. No source/repository edits. Only public copy=False.
Stage1 owner/controller scaffolding is reused as static source below, stage2 namespace only.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import gc
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import select
import signal
import subprocess
import threading
import time
import uuid
from contextlib import contextmanager, nullcontext
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
S = Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch')
REPO = S / 'dr147-mlx-m4'
RESULTS = Path('/Users/oliver.borchers/Desktop/fse-m4-results')
HEAD = 'ef4d6a7bb33ac65a711458365312a5c0faf0b96a'
NATIVE = 'xxh3-128:2d9d0a93859e347a5220443fab372260'
DECISION, LEDGER = S / 'DR-147-time-limit-removal.json', S / 'budget.jsonl'
ROUNDS, PASSES = 16, 5
sys.path.insert(0, str(S))
sys.path.insert(0, str(REPO / 'benchmarks'))
from dr147_stage1_supervision import ProgressGuard, pulse, progress_fds, run_job
from dr147_stage1_cancel import InterruptWitness
from dr147_stage2_imports import TaskImports, PublicImportUnavailable, content_hash

spec = importlib.util.spec_from_file_location('stage1_frozen_for_stage2', S / 'dr147-stage1.py')
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
read, write, append, digest, safety = BASE.read, BASE.write, BASE.append, BASE.digest, BASE.safety
clock_policy, setup, stop_record, spread = BASE.clock_policy, BASE.setup, BASE.stop_record, BASE.spread
FROZEN = {'dr147-stage1.py': 'eba55b15b3b29b458b82f9700509d68e1af4e226a005500986afabf8c10bd0ff',
          'dr147_stage1_supervision.py': 'a47212a90eadb6daad4316df4c371c7a1df55f2986ba6047b9179272048fa5a9',
          'dr147_stage1_cancel.py': '944b6f6e30093272a2f529f9cb983529226e6fa1addccabb8f8d49dfacb2f1da'}
BLOCKS = [('cpu10', 'cpu', 10, 'AB'), ('mlx_AB', 'mlx', 12, 'AB'),
          ('cpu12', 'cpu', 12, 'AB'), ('mlx_BC', 'mlx', 12, 'BC')]


def protocol():
    assert all(digest(S / name) == sha for name, sha in FROZEN.items())
    return {'stage': 2, 'head': HEAD, 'rounds': ROUNDS, 'passes': PASSES,
            'script_sha256': digest(__file__), 'imports_sha256': digest(HERE / 'dr147_stage2_imports.py'),
            'frozen_stage1': FROZEN, 'stage1_summary_sha256': digest(RESULTS / 'DR-147-stage1-summary.json'),
            'blocks': [list(b) for b in BLOCKS], 'c_api': 'asarray(copy=False), no fallback'}


def side_order(index, comparison):
    a, b = comparison
    return [a+'1', b+'1', b+'2', a+'2'] if index % 2 == 0 else [b+'1', a+'1', a+'2', b+'2']


def validate_rounds(records):
    assert len(records) <= ROUNDS
    for index, record in enumerate(records):
        assert record['index'] == index
        expected_blocks = BLOCKS if index % 2 == 0 else list(reversed(BLOCKS))
        assert record['blocks'] == [b[0] for b in expected_blocks]
        assert set(record['times']) == {b[0] for b in BLOCKS}
        for name, _, _, comparison in BLOCKS:
            assert record['orders'][name] == side_order(index, comparison)
            sides = record['times'][name]
            assert set(sides) == {v+str(i) for v in comparison for i in [1, 2]}
            assert all(type(t) in (int, float) and math.isfinite(t) and t > 0 for t in sides.values())


def prepare_imports(enc, guard):
    pipe = enc._pipeline('mlx')  # original canary and table preparation first
    importer = TaskImports()
    guard.check('before three cached dummy arrays')
    pipe.backend.device.call(lambda mx, _stream: importer.prepare(mx))
    guard.check('after three cached dummy arrays')
    return pipe, importer


@contextmanager
def candidate(variant, importer, mode='none'):
    from fse._backends._mlx import _kernels
    assert variant in ['A', 'B', 'C']
    with BASE.partition(variant != 'A'):
        if variant == 'C':
            with importer.installed(_kernels, mode=mode):
                yield
        else:
            yield


def owner_fixture(enc, texts, pipe, importer):
    from fse._text import StringSource, new_workspace
    from fse._backends._mlx import _kernels
    import numpy as np
    def produce():
        with BASE.partition(True):
            plans, _, _ = pipe.plan_tasks(StringSource(texts), 12, None, pipe._row_bytes('float32'))
        batch = next(plans.tasks).batch(pipe.lookup, new_workspace())
        task = _kernels.task(batch, pipe.prepared.state.table)
        assert task is not None and not task.unknown
        hosts = task.arrays[:2]
        def adopt(mx, _stream):
            pairs = [importer.adopt(mx, host, role, proof=True, hold=False)
                     for host, role in zip(hosts, ['tokens', 'offsets'], strict=True)]
            return tuple(got for got, _ in pairs), tuple(record['owner'] for _, record in pairs), tuple({**record['metadata'], 'hash_before': record['hash_before']} for _, record in pairs)
        return pipe.backend.device.call(adopt)
    adopted, weak, metadata = produce()  # no Task/Batch/hosts escape this function
    gc.collect()
    def inspect_live(values, references, expected):
        for value, ref, meta in zip(values, references, expected, strict=True):
            host = ref()
            assert host is not None, 'public import failed to retain sole host owner'
            view = np.asarray(value)
            assert view.ctypes.data == host.ctypes.data and np.shares_memory(view, host)
            assert content_hash(host) == meta['hash_before']
    inspect_live(adopted, weak, metadata)
    adopted = None
    gc.collect()
    assert not any(ref() is not None for ref in weak), 'public import retained owner after array release'
    return {'real_task_arrays': list(metadata), 'sole_owner_retained_by_public_import': True,
            'released_after_imported_arrays_dropped': True, 'no_realign_copy_or_staging': True}


def audit(config, result, guard, enc, texts, want):
    from fse._backends._mlx import _kernels
    from mlx_gate_parity import counts, delta, equal
    pipe, importer = prepare_imports(enc, guard)
    result['api_refusal'] = None
    try:
        guard.check('before sole owner real Task fixture')
        result['owner_fixture'] = owner_fixture(enc, texts, pipe, importer)
        guard.check('after sole owner real Task fixture')
        baseline = counts(enc)
        cache = {k: id(v) for k, v in _kernels._KERNELS.items()}
        guard.check('before full corpus pointer and content witness')
        with candidate('C', importer, mode='content'):
            rows = enc.encode(texts, backend='mlx', workers=12)
        pipe.backend.device.core().synchronize(pipe.backend.device._stream)
        equal(rows, want)
        assert delta(counts(enc), baseline) == {}
        result['imports'] = importer.finish_content_audit()
        expected_plan = BASE.plan_details(pipe, texts, 12, True)
        result['plan'] = expected_plan
        assert len(result['imports']) == 2 * expected_plan['tasks'] > 0
        assert sum(x['role'] == 'tokens' for x in result['imports']) == expected_plan['tasks']
        assert sum(x['role'] == 'offsets' for x in result['imports']) == expected_plan['tasks']
        importer.check_dummies()
        assert cache == {k: id(v) for k, v in _kernels._KERNELS.items()}
        result.update(bits_equal=True, fallback_events={}, kernel_cache_identity_unchanged=True,
                      dummy_arrays=3, import_calls_per_task=2, scope='untimed full-corpus alias/content witness; separate sole-owner fixture')
        guard.check('after full corpus pointer and content witness')
    finally:
        result['api_refusal'] = importer.last_refusal


def memory(config, result, guard, enc, texts, want):
    pipe, importer = prepare_imports(enc, guard)
    try:
        from fse._backends._mlx import _kernels
        imports_only = importer.installed(_kernels) if config['variant'] == 'C' else nullcontext()
        # BASE.memory already applies the partition; do not wrap candidate() around it.
        with imports_only:
            BASE.memory({**config, 'patched': True, 'backend': 'mlx', 'workers': 12}, result, guard, enc, texts, want)
        importer.check_dummies()
    finally:
        result['api_refusal'] = importer.last_refusal


def summarize(rounds, texts):
    absolute, ratios, aa = {}, {}, {}
    for name, _, _, comparison in BLOCKS:
        a, b = comparison
        ratios[name+':'+b+'/'+a] = spread([r['times'][name][b+str(i)] / r['times'][name][a+str(i)] for r in rounds for i in [1, 2]])
        for variant in comparison:
            values = [r['times'][name][variant+str(i)] for r in rounds for i in [1, 2]]
            absolute[name+':'+variant] = {'seconds': spread(values), 'texts_per_s': spread([texts/t for t in values])}
            aa[name+':'+variant+'2/'+variant+'1'] = spread([r['times'][name][variant+'2'] / r['times'][name][variant+'1'] for r in rounds])
    for mblock, variants in [('mlx_AB', 'AB'), ('mlx_BC', 'BC')]:
        for mv in variants:
            for cpu in ['cpu10', 'cpu12']:
                for cv in 'AB':
                    ratios[f'{mblock}:{mv}/{cpu}:{cv}'] = spread([r['times'][mblock][mv+str(i)] / r['times'][cpu][cv+str(i)] for r in rounds for i in [1, 2]])
    return {'absolute': absolute, 'ratios': ratios, 'AA_BB_CC': aa,
            'scope': '32 paired values in16 clusters; two B anchors remain separate'}


def timed(config, result, guard, enc, texts, want):
    from fse._runtime._pipeline import Pipeline
    from fse._backends._mlx import _kernels
    from mlx_gate_parity import counts, delta, equal, launches
    pipe, importer = prepare_imports(enc, guard)
    original_row_bytes, original_launch = Pipeline._row_bytes, _kernels.launch
    cache = {k: id(v) for k, v in _kernels._KERNELS.items()}
    plans = {}
    try:
        for name, backend, workers, comparison in BLOCKS:
            target = enc._pipeline(backend)
            for variant in comparison:
                guard.check('before warm '+name+variant)
                detail = BASE.plan_details(target, texts, workers, variant != 'A')
                before = counts(enc)
                with candidate(variant, importer), launches() as seen:
                    rows = enc.encode(texts, backend=backend, workers=workers)
                equal(rows, want)
                assert delta(counts(enc), before) == {}
                detail['gpu_launches'] = len(seen)
                if backend == 'mlx':
                    assert len(seen) == detail['tasks'] > 0
                plans[name+':'+variant] = detail
                guard.check('after warm '+name+variant)
        assert plans['mlx_BC:B']['spans'] == plans['mlx_BC:C']['spans']
        result['plans'] = plans
        baseline = counts(enc)
        for index in range(len(result['rounds']), ROUNDS):
            guard.check(f'round{index} before')
            blocks = BLOCKS if index % 2 == 0 else list(reversed(BLOCKS))
            record = {'index': index, 'times': {}, 'orders': {}, 'blocks': [b[0] for b in blocks]}
            result['incomplete_round'] = record
            for name, backend, workers, comparison in blocks:
                record['times'][name] = {}
                record['orders'][name] = side_order(index, comparison)
                for side in record['orders'][name]:
                    variant = side[0]
                    guard.check(f'{index}:{name}:{side} before side')
                    assert Pipeline._row_bytes is original_row_bytes and _kernels.launch is original_launch
                    with candidate(variant, importer):
                        values = []
                        for n in range(PASSES):
                            before = guard.check(f'{index}:{name}:{side}:{n} before pass')
                            start = time.perf_counter_ns()
                            rows = enc.encode(texts, backend=backend, workers=workers)
                            elapsed = (time.perf_counter_ns() - start) / 1e9
                            after_load = os.getloadavg()[0]
                            append(guard.journal, {'event': 'pass', 'round': index, 'block': name, 'side': side, 'variant': variant,
                                                  'backend': backend, 'workers': workers, 'pass': n, 'seconds': elapsed,
                                                  'load_before': before['load'], 'load_after': after_load if math.isfinite(after_load) else None})
                            equal(rows, want)
                            assert delta(counts(enc), baseline) == {}, 'fallback event'
                            append(guard.journal, {'event': 'pass_validated', 'round': index, 'block': name, 'side': side,
                                                  'pass': n, 'bits_equal': True, 'fallback_events': {}})
                            guard.check(f'{index}:{name}:{side}:{n} after pass', sample=after_load)
                            values.append(elapsed)
                        record['times'][name][side] = min(values)
                    assert Pipeline._row_bytes is original_row_bytes and _kernels.launch is original_launch
                    importer.check_dummies()
                    guard.check(f'{index}:{name}:{side} after side')
            guard.check(f'round{index} after')
            result['rounds'].append(record)
            result.pop('incomplete_round')
            append(guard.journal, {'event': 'round_kept', **record})
        assert cache == {k: id(v) for k, v in _kernels._KERNELS.items()}
        assert not importer.records and not importer.registry
        result.update(summary=summarize(result['rounds'], len(texts)), bits_equal=True,
                      fallback_events=delta(counts(enc), baseline), kernel_cache_identity_unchanged=True)
    finally:
        result['api_refusal'] = importer.last_refusal


def cancellation(config, result, guard, enc, texts, ready, release):
    import numpy as np
    from fse._runtime import _executor
    from fse._runtime._pipeline import Pipeline
    from fse._backends._mlx._device import Device
    from mlx_gate_parity import counts, delta
    pipe, importer = prepare_imports(enc, guard)
    baseline, targets = counts(enc), []
    original_work, original_complete = Pipeline._work, vars(Device)['_complete']
    complete = Device._complete
    try:
        with candidate('C', importer, mode='lease'), InterruptWitness(_executor, ready, release) as witness:
            def work(self, local, task, target, base):
                targets.append(target[0])
                return original_work(self, local, task, target, base)
            def finish(mx, launched):
                if launched:
                    importer.live_before_complete(launched)
                    witness.block_worker('gpu_import_owners_live_submitted_before_complete')
                return complete(mx, launched)
            Pipeline._work, Device._complete = work, staticmethod(finish)
            guard.check('before cancellation encode')
            try:
                try:
                    enc.encode(texts, backend='mlx', workers=12)
                except KeyboardInterrupt:
                    result['keyboard_interrupt'] = True
                else:
                    raise AssertionError('SIGINT witness did not interrupt encode')
            finally:
                Pipeline._work, Device._complete = original_work, original_complete
        assert witness.proof and targets
        writers = [t.name for t in threading.enumerate() if t.name.startswith(('fse-worker', 'fse-mlx'))]
        assert not writers
        snapshots = [a.view(np.uint32).copy() for a in targets]
        snapshot_at = time.monotonic()
        device = pipe.backend.device
        assert not device._queue and device._thread is None
        device.core().synchronize(device._stream)
        assert all(np.array_equal(a.view(np.uint32), b) for a, b in zip(targets, snapshots, strict=True))
        result.update(input_owner_completion_checks=importer.finish_lease_audit(), blocked_wait_proof=witness.proof,
                      writer_threads_after_cleanup=writers, queue_empty_after_cleanup=True, snapshot_at=snapshot_at,
                      unchanged_after_snapshot_through_final_flush=True, fallback_events=delta(counts(enc), baseline),
                      scope='post-exception quiescence and snapshot-to-flush stability only; no GPU-busy/return-boundary attribution')
        assert result['fallback_events'] == {}
        importer.check_dummies()
        guard.check('after cancellation cleanup')
    finally:
        result['api_refusal'] = importer.last_refusal


def jobs():
    cells = [(corpus, mode) for corpus in ['wikitext', 'massive'] for mode in ['raw', 'norm']]
    output = [{'id': f'audit-{c}-{m}', 'kind': 'audit', 'corpus': c, 'mode': m} for c, m in cells]
    output += [{'id': f'memory-{c}-{m}-{v}', 'kind': 'memory', 'corpus': c, 'mode': m, 'variant': v} for c, m in cells for v in 'BC']
    output += [{'id': f'cancel-massive-{m}', 'kind': 'cancel', 'corpus': 'massive', 'mode': m} for m in ['raw', 'norm']]
    output += [{'id': f'timing-{c}-{m}', 'kind': 'timing', 'corpus': c, 'mode': m} for c, m in cells]
    return output


def inherited_rounds(config):
    path, visited, combined = config.get('resume_result'), set(), []
    expected_digest = config.get('resume_result_sha256')
    while path:
        resolved = str(Path(path).resolve())
        assert resolved not in visited, 'cyclic resume result chain'
        visited.add(resolved)
        assert expected_digest == digest(path), 'immutable resume result changed'
        previous = read(path)
        assert previous['protocol'] == protocol()
        assert previous['job_id'] == config['id']
        assert previous['corpus_name'] == config['corpus'] and previous['mode'] == config['mode']
        assert previous['stop']['retryable_load'] is True
        records = previous['rounds']
        validate_rounds(records)
        overlap = min(len(records), len(combined))
        assert records[:overlap] == combined[:overlap], 'conflicting retained rounds'
        if len(records) > len(combined):
            combined = records
        path = previous.get('resume_result')
        expected_digest = previous.get('resume_result_sha256')
    return list(combined)


def lineage(events, requested):
    starts = [e for e in events if e['kind'] == 'start' and e.get('stage') == 2]
    seen, previous = set(), None
    for event in starts:
        root = str(Path(event['root']).resolve())
        assert root not in seen
        assert event.get('parent_root') == previous, 'branched or skipped lineage'
        seen.add(root)
        previous = root
    if previous is None:
        assert requested is None, 'resume root is not in ledger'
        return None
    assert requested is not None and str(Path(requested).resolve()) == previous, 'only latest terminal root may resume'
    prior = read(Path(previous) / 'state.json')
    assert prior['root'] == previous and prior['status'] != 'complete' and prior['retryable_load'] is True
    assert prior['protocol'] == protocol()
    return prior


def job(path, ready=None, release=None):
    config = read(path)
    folder = Path(config['folder'])
    journal = folder / 'guards.jsonl'
    result = {'status': 'incomplete', 'script_sha256': digest(__file__), 'protocol': protocol(),
              'kind': config['kind'], 'job_id': config['id'], 'corpus_name': config['corpus'],
              'mode': config['mode'], 'rounds': [], 'resume_result': config.get('resume_result'),
              'resume_result_sha256': config.get('resume_result_sha256')}
    try:
        # Retain the immutable prefix before any guard, import, setup or warmup can stop.
        result['rounds'] = inherited_rounds(config)
        pulse('resume prefix validated')
        guard = ProgressGuard(S, config['lock'], journal)
        guard.check('before child setup')
        enc, texts, want = setup(config, result, guard)
        if config['kind'] == 'audit':
            audit(config, result, guard, enc, texts, want)
        elif config['kind'] == 'timing':
            timed(config, result, guard, enc, texts, want)
            assert len(result['rounds']) == ROUNDS
        elif config['kind'] == 'memory':
            memory(config, result, guard, enc, texts, want)
        elif config['kind'] == 'cancel':
            cancellation(config, result, guard, enc, texts, ready, release)
        else:
            raise ValueError('unknown fixed stage1 job')
        assert safety().identity(REPO, HEAD) == result['identity'], 'identity changed'
        result['status'] = 'complete'
        pulse('job complete')
    except BaseException as error:
        result['status'] = 'failed'
        result['stop'] = stop_record(error, journal)
        if isinstance(error, PublicImportUnavailable):
            result['public_import_refusal'] = error.details
    finally:
        write(folder / 'result.json', result)
    return 0 if result['status'] == 'complete' else 2


def cancel_controller(path):
    config = read(path)
    folder = Path(config['folder'])
    guard = ProgressGuard(S, config['lock'], folder / 'controller-guards.jsonl')
    ready_r, ready_w = os.pipe()
    release_r, release_w = os.pipe()
    process = None
    try:
        guard.check('before cancellation witness subprocess')
        child_folder = folder / 'child'
        child_folder.mkdir()
        child_config = {**config, 'folder': str(child_folder)}
        write(child_folder / 'job.json', child_config)
        with (folder / 'cancel-child.log').open('x') as log:
            process = subprocess.Popen([sys.executable, __file__, '_job', str(child_folder / 'job.json'), '--ready', str(ready_w), '--release', str(release_r)],
                                       stdout=log, stderr=subprocess.STDOUT, pass_fds=(ready_w, release_r, *progress_fds()))
            os.close(ready_w)
            ready_w = -1
            os.close(release_r)
            release_r = -1
            data = b''
            while b'\n' not in data:
                if process.poll() is not None:
                    if (child_folder / 'result.json').exists():
                        outcome = read(child_folder / 'result.json')
                        assert outcome['status'] != 'complete'
                        write(folder / 'result.json', outcome)
                        return 2
                    raise RuntimeError('cancel child exited before blocked-call witness')
                available, _, _ = select.select([ready_r], [], [], .25)
                if available:
                    part = os.read(ready_r, 256)
                    if not part:
                        raise RuntimeError('witness pipe EOF')
                    data += part
            proof = json.loads(data.split(b'\n', 1)[0])
            assert proof['event'] == 'blocked_wait_witness' and proof['lock_handshakes']
            guard.check('before SIGINT at witnessed runtime condition wait')
            sent_at = time.monotonic()
            process.send_signal(signal.SIGINT)
            buffered = data.split(b'\n', 1)[1]
            while b'\n' not in buffered:
                if process.poll() is not None:
                    raise RuntimeError('child exited without signal-handler ACK')
                available, _, _ = select.select([ready_r], [], [], .25)
                if available:
                    more = os.read(ready_r, 256)
                    if not more:
                        raise RuntimeError('ACK pipe EOF')
                    buffered += more
            acknowledgement = json.loads(buffered.split(b'\n', 1)[0])
            assert acknowledgement['event'] == 'signal_ack' and acknowledgement['from_sigint_handler'] is True
            assert acknowledgement['pid'] == process.pid and acknowledgement['at'] >= sent_at
            release_at = time.monotonic()
            os.write(release_w, b'R')
            write(folder / 'cancel-witness.json', {'witness': proof, 'signal_sent_at': sent_at,
                                                  'signal_handler_ack': acknowledgement, 'release_at': release_at})
            pulse('signal handler ACK observed and worker released')
            code = process.wait()  # progress supervisor handles concrete stalls, no absolute job cap
            outcome = read(child_folder / 'result.json')
            if code or outcome['status'] != 'complete':
                write(folder / 'result.json', outcome)
                return 2
            guard.check('after cancellation subprocess')
            write(folder / 'result.json', outcome)
            return 0
    except BaseException as error:
        if not (folder / 'result.json').exists():
            write(folder / 'result.json', {'status': 'failed', 'stop': stop_record(error, guard.journal)})
        return 2
    finally:
        for fd in [ready_r, ready_w, release_r, release_w]:
            if fd >= 0:
                os.close(fd)
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)


def owner(resume):
    resume = str(Path(resume).resolve()) if resume else None
    from mlx_gate_process import controlled_termination
    assert not (S / 'bench.lock').exists() and not (S / 'pause-local.marker').exists()
    total = clock_policy()
    events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
    prior = lineage(events, resume)
    while True:
        assert not (S / 'pause-local.marker').exists() and not (S / 'bench.lock').exists()
        load = os.getloadavg()[0]
        assert math.isfinite(load), 'nonfinite entry load'
        if load < 5:
            break
        print(f'entry waiting without lock or accounting: load={load}', flush=True)
        time.sleep(15)
    started = time.monotonic()
    lock = safety().acquire(S, HEAD, 'dr147-mlx-m4')
    token = uuid.uuid4().hex
    root = HERE / ('run-' + token[:12])
    root.mkdir()
    state = {'stage': 2, 'root': str(root), 'lock': lock, 'script_sha256': digest(__file__),
             'protocol': protocol(), 'status': 'incomplete', 'decision': str(DECISION),
             'global_before': total, 'matrix_fixed_s': 523.0340705840008,
             'jobs': dict(prior['jobs']) if prior else {}, 'retryable_load': False, 'resume': resume}
    admitted = False
    try:
        # Recheck latest lineage under exclusive bench.lock, immediately before ledger append.
        total = clock_policy()
        events = [json.loads(x) for x in LEDGER.read_text().splitlines()]
        prior = lineage(events, resume)
        append(LEDGER, {'kind': 'start', 'id': token, 'stage': 2, 'root': str(root), 'parent_root': resume,
                        'protocol': protocol(), 'pid': os.getpid(), 'at': time.time(), 'policy': 'no cap'})
        admitted = True
        write(root / 'invocation.json', state)
        with controlled_termination():
            state['identity'] = safety().identity(REPO, HEAD)
            assert state['identity']['native_checksum'] == NATIVE
            for spec in jobs():
                old = state['jobs'].get(spec['id'])
                if old:
                    assert digest(old['result']) == old['result_sha256'], 'immutable result changed'
                if old and old['status'] == 'complete':
                    continue
                folder = root / spec['id']
                folder.mkdir()
                guard = ProgressGuard(S, lock, root / 'parent.jsonl')
                guard.check('before ' + spec['id'])
                config = {**spec, 'folder': str(folder), 'lock': lock}
                if old and spec['kind'] == 'timing':
                    config['resume_result'] = old['result']
                    config['resume_result_sha256'] = old['result_sha256']
                write(folder / 'job.json', config)
                action = '_cancel' if spec['kind'] == 'cancel' else '_job'
                with (folder / 'worker.log').open('x') as log:
                    code = run_job([sys.executable, __file__, action, str(folder / 'job.json')], log,
                                   journal=folder / 'supervision.jsonl')
                outcome = read(folder / 'result.json')
                state['jobs'][spec['id']] = {'status': outcome['status'], 'result': str(folder / 'result.json'),
                                            'result_sha256': digest(folder / 'result.json')}
                if code or outcome['status'] != 'complete':
                    state['stop'] = outcome.get('stop', {'type': 'ProcessFailure', 'reason': f'exit={code}', 'retryable_load': False})
                    state['retryable_load'] = state['stop'].get('retryable_load') is True
                    return 2
                guard.check('after ' + spec['id'])
                print('complete ' + spec['id'], flush=True)
            assert len(state['jobs']) == len(jobs())
            assert safety().identity(REPO, HEAD) == state['identity']
            state['status'] = 'complete'
            return 0
    except BaseException as error:
        state['stop'] = stop_record(error, root / 'parent.jsonl')
        state['retryable_load'] = admitted and state['stop']['retryable_load']
        return 2
    finally:
        elapsed = time.monotonic() - started
        state['active_seconds'] = elapsed
        event = {'kind': 'finish' if admitted else 'admission_rejected', 'id': token, 'stage': 2,
                 'at': time.time(), 'active_seconds': elapsed, 'status': state['status'], 'root': str(root)}
        append(LEDGER, event)
        write(root / 'state.json', state)
        print('Stage2 evidence: ' + str(root) + '; own lock retained for verified Finder cleanup.', flush=True)


def check():
    import numpy as np
    from dr147_stage2_imports import content_hash
    class FakeArray:
        def __init__(self, owner):
            self.owner = owner
        def __array__(self, dtype=None, copy=None):
            assert copy is not True
            return self.owner if dtype is None else self.owner.astype(dtype, copy=False)
    class FakeMX:
        def __init__(self):
            self.creations, self.imports, self.reject, self.lie = 0, 0, False, False
        def array(self, host):
            self.creations += 1
            return FakeArray(np.array(host, copy=True))
        def asarray(self, host, *, copy):
            assert copy is False
            self.imports += 1
            if self.reject:
                raise ValueError('CONTROL public import refusal')
            return FakeArray(host.copy() if self.lie else host)
        def eval(self, *arrays):
            pass
    mx, importer = FakeMX(), TaskImports()
    importer.prepare(mx)
    hosts = (np.arange(4, dtype=np.uint32), np.array([0, 4], np.uint32), *(np.zeros(1, np.uint32) for _ in range(3)))
    task = SimpleNamespace(arrays=hosts, unknown=False)
    table = SimpleNamespace(fasttext=False)
    def original(mx, stream, table, task, normalize=False):
        return tuple(mx.array(a) for a in task.arrays)
    kernels = SimpleNamespace(launch=original)
    with importer.installed(kernels):
        one = kernels.launch(mx, None, table, task)
        two = kernels.launch(mx, None, table, task)
    assert mx.creations == 3 and mx.imports == 4
    assert all(one[i] is two[i] for i in [2, 3, 4]) and kernels.launch is original
    mx.reject = True
    try:
        with importer.installed(kernels):
            kernels.launch(mx, None, table, task)
    except PublicImportUnavailable as error:
        assert error.details['fallback_attempted'] is False
    else:
        raise AssertionError('public refusal was hidden')
    assert kernels.launch is original and mx.creations == 3
    mx.reject, mx.lie = False, True
    try:
        importer.adopt(mx, hosts[0], 'tokens', proof=True)
    except AssertionError:
        pass
    else:
        raise AssertionError('copied storage passed alias proof')
    mx.lie = False
    host = np.arange(4, dtype=np.uint32)
    imported, record = importer.adopt(mx, host, 'tokens', proof=True)
    before = content_hash(host)
    host[0] = 99  # control fixture only, no live GPU or model data
    try:
        importer._check_content(record)
    except AssertionError:
        pass
    else:
        raise AssertionError('input mutation was not detected')
    host[0] = 0
    assert content_hash(host) == before
    owner = record['owner']
    del host
    gc.collect()
    assert owner() is not None
    del imported
    gc.collect()
    assert owner() is None
    from fse._runtime._pipeline import Pipeline
    memory_observed = []
    real_prepare, real_memory = globals()['prepare_imports'], BASE.memory
    class MemoryImporter:
        last_refusal = None
        def installed(self, kernels, mode='none'):
            return nullcontext()
        def check_dummies(self):
            pass
    def memory_partition_probe(config, *args):
        dummy = SimpleNamespace(output_dim=1024, _device_rows=True, prepared=SimpleNamespace(steps=(1,)))
        with BASE.partition(config['patched']):
            memory_observed.append(Pipeline._row_bytes(dummy, 'float32'))
    globals()['prepare_imports'] = lambda *args: (None, MemoryImporter())
    BASE.memory = memory_partition_probe
    try:
        for variant in ['B', 'C']:
            memory({'variant': variant}, {}, None, None, None, None)
    finally:
        globals()['prepare_imports'], BASE.memory = real_prepare, real_memory
    assert memory_observed == [8328, 8328], 'memory job applied partition more than once'
    assert json.loads(json.dumps(protocol())) == protocol()
    assert len(jobs()) == 18 and ROUNDS == 16 and PASSES == 5
    control_root = RESULTS / ('DR-147-stage2-controls-' + uuid.uuid4().hex[:12])
    control_root.mkdir()
    records = []
    for index in range(2):
        blocks = BLOCKS if index % 2 == 0 else list(reversed(BLOCKS))
        records.append({'index': index, 'blocks': [b[0] for b in blocks],
                        'orders': {name: side_order(index, comparison) for name, _, _, comparison in BLOCKS},
                        'times': {name: {side: 1.0 for side in side_order(index, comparison)} for name, _, _, comparison in BLOCKS}})
    validate_rounds(records)
    prior_path = control_root / 'prior.json'
    write(prior_path, {'protocol': protocol(), 'job_id': 'timing-wikitext-raw', 'corpus_name': 'wikitext',
                       'mode': 'raw', 'stop': {'retryable_load': True}, 'rounds': records})
    real_guard, real_setup = globals()['ProgressGuard'], globals()['setup']
    class FailBeforeSetup:
        def __init__(self, scratch, lock, journal):
            self.journal = journal
        def check(self, label):
            append(self.journal, {'event': 'guard', 'label': 'CONTROL injected early load stop', 'load': 5.25,
                                  'finite_load': True, 'synthetic_control_fixture': True})
            raise safety().StopError('load 5.25 is not strictly below 5')
    def no_model_setup(*args):
        raise AssertionError('model setup must not be reached in control')
    globals()['ProgressGuard'], globals()['setup'] = FailBeforeSetup, no_model_setup
    try:
        for index in [1, 2]:
            folder = control_root / f'early-stop-{index}'
            folder.mkdir()
            cfg = {'id': 'timing-wikitext-raw', 'kind': 'timing', 'corpus': 'wikitext', 'mode': 'raw',
                   'folder': str(folder), 'lock': {}, 'resume_result': str(prior_path),
                   'resume_result_sha256': digest(prior_path)}
            write(folder / 'job.json', cfg)
            assert job(folder / 'job.json') == 2
            prior_path = folder / 'result.json'
            outcome = read(prior_path)
            assert outcome['rounds'] == records and outcome['stop']['retryable_load'] is True
    finally:
        globals()['ProgressGuard'], globals()['setup'] = real_guard, real_setup
    roots = [control_root / 'root-a', control_root / 'root-b']
    for path in roots:
        path.mkdir()
        write(path / 'state.json', {'root': str(path), 'status': 'incomplete', 'retryable_load': True, 'protocol': protocol()})
    events = [{'kind': 'start', 'stage': 2, 'root': str(roots[0]), 'parent_root': None},
              {'kind': 'start', 'stage': 2, 'root': str(roots[1]), 'parent_root': str(roots[0])}]
    assert lineage(events, str(roots[1]))['root'] == str(roots[1])
    for changed, requested in [(events, str(roots[0])), (events, None),
                               (events + [{'kind': 'start', 'stage': 2, 'root': str(control_root / 'fork'), 'parent_root': str(roots[0])}], str(control_root / 'fork'))]:
        try:
            lineage(changed, requested)
        except AssertionError:
            pass
        else:
            raise AssertionError('ancestor/fork admission accepted')
    ident = safety().identity(REPO, HEAD)
    assert ident['native_checksum'] == NATIVE
    print(json.dumps({'status': 'model-free stage2 controls passed', 'encodes': 0, 'models_loaded': False,
                      'real_mlx_calls': 0, 'dummy_reuse': True, 'public_refusal_propagated_without_copy': True,
                      'false_alias_and_mutation_rejected': True, 'fake_api_owner_lifetime_checked': True, 'memory_single_partition_B_C': memory_observed,
                      'two_early_stop_resume_prefixes_preserved': True, 'ancestor_and_fork_rejected': True,
                      'control_files': str(control_root), 'global_actual_seconds': clock_policy(),
                      'identity': ident, 'protocol': protocol(), 'jobs': jobs()}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['check', 'run', '_job', '_cancel'])
    parser.add_argument('config', nargs='?')
    parser.add_argument('--resume')
    parser.add_argument('--ready', type=int)
    parser.add_argument('--release', type=int)
    args = parser.parse_args()
    os.chdir(REPO)
    os.environ.update(TMPDIR=str(S), GIT_CEILING_DIRECTORIES=str(S), UV_NO_SYNC='1', UV_OFFLINE='1', HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    if args.action == 'check':
        check()
    else:
        raise SystemExit(owner(args.resume) if args.action == 'run' else cancel_controller(args.config) if args.action == '_cancel' else job(args.config, args.ready, args.release))
