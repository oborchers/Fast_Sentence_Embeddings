# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): Stufe 2 vor Ausführung

Status: ausschließlich Plan und Scratch-Runner. Kein Modelllauf vor fse-codex-Skriptprüfung. Kein src-/Repo-Edit, Commit, Push, Merge oder Linear-Zugriff, auch nicht lesend. PR bleibt Draft. Der unabhängige Forschungserstbericht und die angenommene Stufe1 bleiben unverändert.

## Hypothese und Restlücke

Original A, Stufe1-Partition B und zusätzlicher Importwechsel C werden getrennt. A verwendet Originalpartition/Originalimporte. B verwendet Raw-Partition und Originalimporte. C verwendet dieselbe Raw-Partition wie B, übernimmt zwei echte Taskarrays über die öffentliche API `mx.asarray(host, copy=False)` und nutzt drei einmal vorbereitete unveränderliche Dummyarrays wieder. Keine Änderung von Kernel, Arithmetik, Bounds, Gruppierung oder Ausgabe-Rückkopie. Kein Packen, Metal-Neubau oder Stagingpuffer.

Aus angenommenen Stufe1-Paaren gegen CPU12-B: MASSIVE Norm Verhältnis1.3151925127000865, nötige Einsparung23.9655038830%; Raw1.6042661551732922, nötige Einsparung37.6662035302%. Median der tatsächlich gepaarten Zeitdifferenzen: Norm11.526417ms, Raw17.5554165ms. Ein Verhältnis der absoluten Mediane ist dafür nicht eingesetzt.

Bei89Tasks: Original445Task-Arrayerzeugungen, C178öffentliche Übernahmeaufrufe und drei Dummy-Erzeugungen einmal außerhalb der Encode-Uhr. 267wiederholte Dummy-Neuanlagen entfallen. C importiert weiterhin zwei echte Arrays pro Task und startet weiterhin89Kernel. Für MASSIVE umfassen Tokens/Satzoffsets9498904logischeBytes, Dummies weitere1068Bytes. Vermiedene Hostkopie läse/schriebe ungefähr18999944Bytes. Selbst mit nur angenommener273GB/s wären das0.0696ms. Das ist kein Messwert und keine Untergrenze. Ein Effekt in Höhe der Restlücke müsste überwiegend Verwaltung/Allokation oder andere gekoppelte Arbeit sparen. Er ist nicht durch die kleine Bytezahl bewiesen. Die Restlücke entspräche rechnerisch43.17 beziehungsweise65.75µs je267entfallenden API-Neuanlagen, falls allein diese sie schlösse. Keine gemessene Aufruflatenz behaupten.

## Übernahme- und Sicherheitsnachweise vor Zeitmessung

1. Reale Taskarrays unverändert verwenden. Kein Umkopieren, Auffüllen oder Neuallokieren, um Alignment zu erzwingen. UInt32, zusammenhängendes Layout, Elementausrichtung und positive Größe prüfen. Tatsächlichen Pointerrest zur VM-Seitengröße protokollieren. Zusätzliche Plattformbedingungen entscheidet die öffentliche API.
2. Immer `copy=False`, niemals `copy=None`. Eine API-Verweigerung beendet Stufe2 als nicht ausführbare öffentliche Übernahme dieses Inputs. Originalfehler und Metadaten erhalten. Keine stille Kopie, kein ungefragter Staging-/Pack-/Metal-Ersatz. Auch späterer einzelner Importfehler ist nicht lastbedingt und nicht wiederholbar.
3. Separater Owner-Nachweis mit zwei echten Arrays aus einem realen Task: importierte Arrays zurückgeben, alle übrigen Host-/Batch-/Taskreferenzen fallen lassen, Garbage Collection. NumPy-Owner müssen durch MLX weiterleben. Pointer, Shape, Dtype, Strides und gemeinsamer Speicher werden verglichen. Nach Freigabe der MLX-Arrays und Abschluss müssen die nicht anderweitig gehaltenen Owner freigegeben sein. Keine absichtliche Mutation eines noch benutzten Inputs.
4. Separater unbezeiteter vollständiger C-Aufruf pro Zelle: jede echte Übernahme per Pointergleichheit/`shares_memory` belegen. Inhalte vor/nach GPU-Abschluss per Hash vergleichen. Dieser Inhaltszeuge hält bewusst eigene Hostreferenzen und wird nicht als unabhängiger MLX-Ownernachweis ausgegeben.
5. Speichervergleich B/C in frischen Prozessen für jede der vier Zellen, mit denselben nachträglichen RSS-/Workspaceprüfungen wie Stufe1. Keine Behauptung eines Live-RSS-Limits oder vollständigen Windowvertrags. CPU-Speicherpfad bleibt unverändert und ist in Stufe1 geprüft.
6. C-Abbruchzeugen auf MASSIVE Raw und Norm. Echtes Runtime-Conditionwait/Lockhandshake, ACK direkt aus SIGINT-Handler vor Workerfreigabe. Reale Inputs müssen bis zum bewachten Geräteabschluss leben. Keine neue Behauptung von GPU-busy. Nach Cleanup keine beobachteten Runtimewriter/Queuejobs, Snapshot-bis-Flush-Stabilität im engen bereits geprüften Umfang. Keine Marker in zeitgemessenen Encodes.

Kernel und bestehende Ausgabe-Leases unverändert. Drei Dummyarrays werden im bestehenden Gerätethread vor den Messseiten vorbereitet und dauerhaft nur gelesen. Originalfunktionen werden nach jeder Seite und jedem Fehler per finally restauriert. `_kernels.kernel` bleibt derselbe bereits vorbereitete pool4-Cacheeintrag. C verwendet den Original-Launch über einen eng begrenzten mx-Proxy für genau dessen fünf Taskarray-Aufrufe. Es entsteht kein neuer Shader und kein anderer Reduktionsbaum.

## Vorab festgelegte Zeitreihe, falls alle API-/Sicherheitsnachweise bestehen

Vier Zellen MRL1024/Float32: WikiText Raw, WikiText Norm, MASSIVE Raw, MASSIVE Norm. Je16vollständige gültige Blöcke, fünf Pässe pro Seite, Seitenminimum. Jede Runde enthält vier Unterblöcke: CPU10 A/B, MLX A/B, CPU12 A/B, MLX B/C. Nächste Runde umgekehrte Unterblockfolge. Innerhalb jedes Unterblocks ABBA, nächsteRunde BAAB. Keine Dreiseitenrotation.

Für A/B: A1,B1,B2,A2 bzwB1,A1,A2,B2. Für B/C: B1,C1,C2,B2 bzwC1,B1,B2,C2. Importwirkung C1/B1 undC2/B2 ausschließlich aus dem B/C-Unterblock, nicht aus einem nachträglich günstigeren B des anderen Unterblocks. Beide B-Kontrollen bleiben getrennt sichtbar. 32Quotienten in16Clustern pro Vergleich. A/A, B/B undC/C vollständig berichten.

CPU10/12 A/B bleiben frische faire Vergleiche. Alle MLX-Varianten werden innerhalb gleicher Runde/Position mit allen vier festen CPU-Konfigurationen verglichen. Keine proPaar ausgewählte CPU-Minimumseite. Absolute Zeit- und Texte/s-Mediane/Spannen vollständig zeigen. FünfPässe sind für beide Korpora fest. Insgesamt5120akzeptierte zeitgemessene Encode-Pässe, falls die öffentliche Übernahme und alle Vorprüfungen bestehen.

Volle Bits jedes Passes gegen die unveränderte akzeptierte Corpusreferenz außerhalb der Encode-Uhr; keine Fallbacks. Last strikt<5 vor/nach Pass/Seite und vor Subprozessen. Nur exakt verifizierte endliche Lastabbrüche dürfen fehlende Blöcke fortsetzen. Ganze unvollständige Blöcke verwerfen und behalten. Alle gültigen Präfixe vor Guards/Setup/Warmup übernehmen. Nur letzter unverzweigter terminaler Stufe2-Root fortsetzbar. Keine Wiederholung fertiger Jobs/Blöcke.

## Vorab-Stoppregeln und Urteil

Sofortiger Nichtlaststopp bei API-Verweigerung, fehlendem Alias-/Owner-/Inhaltsnachweis, Bitabweichung, Fallback, Identitäts-/Layout-/Speicherdiagnosefehler, Abbruchzeugen- oder Aufsichtsfehler. Kein Retry und keine Ersatzhypothese innerhalb dieses Scripts.

Nach16gültigen Blöcken pro Zelle immer zur Ergebnisprüfung stoppen. Kein Aufstocken oder Auswählen wegen ungünstiger C/B-Werte. Ein medianer CPU-Sieg darf nur für seine konkrete feste Konfiguration berichtet werden. Überspannt die Paarspanne eins, keinen Sieg jedes Paars behaupten. Wenn C/B keinen klaren Gewinn gegenüber A/A/B/B trägt, Importrettung als nicht belegt ausgeben. Weder bloße Richtung noch erfülltes Zero-copy-Protokoll schließen die24..38%-Restlücke automatisch. Keine weitere Stufe implementieren/starten. Eine Fortsetzung verlangt eine neue konkrete Restlückenbegründung und Inspektion.

## Aufsicht, Buchführung und Ablage

Keine Zeitcaps. Echter Verbrauch weiter im etablierten gemeinsamen budget.jsonl, ohne Reset oder alte Budgetklasse. Historischer mlx-gate-budget.jsonl unverändert. OwnerEOF/Prozessgruppenaufsicht und echte Fortschrittspulse an Phasen/Passgrenzen aus dem bereits geprüften Helper, kein periodischer Fakeheartbeat. Stillstandsprüfung bleibt ein Sicherheitswächter, keine absolute Job-/Stufendeadline. Ein eigener bench.lock, nur terminale eigene Finderfreigabe mit sofortiger und verzögerter Dublettenprüfung.

Alle neuen Stände, Merkpunkte, Reports und Stage2-Rohresultate unter ~/Desktop/fse-m4/ oder ~/Desktop/fse-m4-results/. Scratch-Scripts: /Users/oliver.borchers/Desktop/fse-m4/dr147-stage2/. Gemeinsame bereits vorgeschriebene Lock-/Pause-/Cache-/Accountingpfade bleiben explizit im bestehenden Scratch, damit Buchführung und Eigentum nicht still gewechselt werden. Diese Pfadkontinuität ist im Skript vor Datenstart prüfbar.

Primärquellen: [MLX v0.32.4 asarray-Vertrag](https://github.com/ml-explore/mlx/blob/v0.32.4/python/src/ops.cpp#L1795-L1821), [CPU-Pufferübernahme und Owner](https://github.com/ml-explore/mlx/blob/v0.32.4/python/src/convert.cpp#L170-L216), [Metal make_buffer](https://github.com/ml-explore/mlx/blob/v0.32.4/mlx/backend/metal/allocator.cpp#L195-L218). Diese Quellen belegen Bedingungen, nicht erfolgreiche Übernahme der fse-Arrays. Letzteres ist erst nach dem Prüf-Go zu messen.

Zero-Copy bezeichnet ausschließlich die belegte Hostpufferübernahme. Es bedeutet weder nullDRAMtraffic noch kostenlose Synchronisation. Die vollständige Alias-/Inhaltsprüfung muss exakt zwei Nachweise je tatsächlich geplanter Task liefern. Alle realen Arrayoperationen bleiben bis zur Skriptfreigabe ungestartet.
