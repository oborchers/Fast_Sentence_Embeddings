# DR-147 (MLX-Gate entscheiden und auf dem M4 Pro nachmessen): Stufe 3 vor Ausführung

Status: Plan und Scratch-Runner werden vorbereitet. Kein Modelllauf vor aktiver Skriptprüfung und Hash-Startprompt von fse-codex.
Stufe 2 ist unabhängig angenommen. Stufe 3 baut ausschließlich auf B mit Originalimporten auf. C wird nicht kumuliert.
Kein src-/Repo-Edit, Commit, Push, Merge oder Linear-Zugriff, auch nicht lesend. PR bleibt Draft.

## Isolierte Hypothese

B: Raw-Partition für Norm, ursprüngliche fünf mx.array-Importe je ursprünglichem Task.
D: identische ursprüngliche Tasks und Prüfungen, jedoch kompatible bereits wartende Tasks eines bestehenden Device-Gruppenabrufs zusammen starten.
Keine künstliche Wartefrist, kein vergrößertes Window, keine neue Gruppierungsgrenze. Device._take bleibt unverändert, maximal acht Tasks und bestehendes Tokenlimit.
Kompatibilität: dieselbe Table-Identität, derselbe Normalize-Schalter, bekannte WordPiece-IDs ohne FastText, UInt32-Layouts innerhalb der ursprünglichen Grenzen.
Andere Jobs und nicht kompatible Nachbarn behalten ihren Originalstart. Kein Überholen in der Queue.

Der Originalkernel fusioniert Pooling und Normalize bereits. D ändert nur dessen Anzahl und Zeilenraster, keinen Shader oder Reduktionsbaum.
Die ursprünglichen Backendprüfungen, Aufgabenindizes, Bounds, Fallbackentscheidung und Worker-Rückkopie bleiben aktiv.

## Konkreter Mechanismus und Leases

Ein schmaler Worker-Kontext markiert ausschließlich Backend-Launches mit Table, Task und Normalize. Original-Device.run bleibt für Queue, Wait, Abort und Lease zuständig.
Device._launch bildet zusammenhängende kompatible Teilgruppen seines bereits entnommenen Gruppenarguments.
Tokens werden im Gerätethread kopiert zusammengehängt, Satzoffsets additiv um die bisherigen Tokenzahlen verschoben. Keine Tokens oder Satzreihenfolgen innerhalb eines ursprünglichen Tasks ändern sich.
Ein Original-_kernels.launch für die gepackte Task verwendet unverändert mx.array und den bestehenden pool4-Cache.
Jeder ursprüngliche Job bekommt dieselben drei vollständigen MLX-Ergebnisarrays als geliehene Eigentümer.
Sein finish erstellt erst nach eval NumPy-Ansichten seines disjunkten Zeilenbereichs und ruft das ursprüngliche finish darauf auf.
Keine MLX-Slice-Primitiven, keine zusätzlichen GPU-Kernel für Ausgabeslices. Keine vorgezogene Freigabe geteilter Arrays.
Original-_complete, _settle, _give_back und _collect behalten die Originaljobs und deren einzelne Leases. Der gemeinsame Speicher lebt bis zur letzten Rückgabe.
Originale Job-Launchfunktionen werden nach dem Start restauriert. Finish-Slices halten keine versteckten Ergebnisreferenzen.
Pack-/Dispatchfehler werden den beteiligten Originaljobs zugeordnet. Unabhängige Teilgruppen bleiben zuordenbar. Ein individuelles finish-Problem bleibt beim betroffenen Job.
Die unveränderten CPU-Eingabefehler werden vor dieser Stufe vom ursprünglichen Backendpfad behandelt. Reale Fehlerwitnesses und modellfreie Kontrollen prüfen dies.

## Kostenrechnung und verbleibende Lücke

Stufe 2 B/CPU12-B auf MASSIVE: Raw 1,6130 im A/B-Anker und 1,6980 im B/C-Anker, benötigte Einsparung 38,0052 beziehungsweise 41,1061 Prozent.
Norm: 1,3263 in beiden Ankern, benötigte Einsparung etwa 24,600 Prozent. Gegen CPU10-B: Raw 36,7519 beziehungsweise 39,8840 Prozent, Norm etwa 22,3 Prozent.
Beide B-Anker bleiben berichtet. Die neue Reihe erhält ihren eigenen frischen B-Anker, keinen ausgewählten historischen Bestwert.

89 ursprüngliche MASSIVE-Tasks könnten bei vollständig gefüllten Achtergruppen theoretisch mindestens zwölf Poolstarts benötigen. Tatsächliche Gruppen hängen von der laufenden Queue ab und können deutlich kleiner sein.
Die ursprünglichen 89 Hosttasks bleiben erhalten. D spart weder deren WordPiece noch automatisch deren Bounds, Fehlerprüfungen oder Worker-Kopien.
Stufe 1 sparte 119 Tasks/Starts und ungefähr 46 ms. Rund 0,4 ms je Start sind ausschließlich eine Annahme für einen gekoppelten Effekt, keine gemessene Launchlatenz.
77 vermiedene Starts mal angenommene 0,4 ms ergeben 30,8 ms. Dies ist eine Möglichkeitsskizze, kein prognostizierter Gewinn. Stufe 1 reduzierte zusätzlich Hosttasks, D nicht.

MASSIVE-Eingaben pro kompletter Runde enthalten rund 9,5 MB Tokens/Offsets. Packen fügt mindestens Lesen und Schreiben dieser Eingaben hinzu, danach bleiben die ursprünglichen MLX-Kopierimporte pro Pack.
Ausgabe weiterhin 621256704 Bytes bei MASSIVE und 21921792 bei WikiText. Originale Worker-Rückkopie bleibt vollständig bestehen.
Packkosten, Metadaten und minimale Startzähler sind Teil der Encode-Uhr. Keine Kosten werden abgezogen. Gesamtdauer/Start ist keine Launchlatenz.
Keine Zusage, dass Bündeln allein die Restlücke schließt. Genau dies entscheidet der Versuch.

## Vorprüfungen vor Timing

Modellfrei: künstliche Tasks mit ungleichen Größen und nicht zusammenhängenden first_row-Werten, exakte Tokens/Offsetrebasierung, Zeilen-/Flag-/Boundsslices, keine Inputmutation.
Modellfrei: Table-/Normalize-Grenzen, nicht markierte Jobs, leere Queue ohne Wartefrist, einzelne und mehrere Packs, Launch-/Eval-/Finishfehler und Zuordnung.
Modellfrei: reale Device-Job-/Lease-Mechanik mit Fake-MLX, letzte Referenzen erst nach allen Rückgaben, Abbruch mit echtem Wait-/Lockhandshake und restaurierte Originalmethoden.
Modellfrei: unverzweigtes Resume, erhaltene Runden vor Setup/Guard, früher Laststopp und Nichtlastfehler ohne Erfolgsstatus.
Kein Modell, kein Encode und kein echtes MLX im check.

Nach Startfreigabe: vier vollständige unbezeitete D-Audits gegen akzeptierte Referenzen, tatsächliche Startreduktion, Originaltask-Zuordnung und unveränderter Kernelcache.
Dabei Eingabefehler mit identischen CPU-Fehlertypen und Texten prüfen. Bei Nichtausübung des Packens stoppen, keine Zeitreihe ohne echte Bündelung.
Acht frische Speicherjobs: vier Zellen B/D, gleicher Workspace-Reader wie vorher, erste RSS vor Reader/Bits, zweite diagnostische RSS mit Reader/Bits.
Vor jeder Packallokation logische Größe und UInt32-Überlauf prüfen. Maximale einzelne zusätzliche Hostpackallokation 128 MiB. RSS/Workspaceprüfungen bleiben nachträglich, 8 GiB beziehungsweise 512 MiB.
Zwei reale MASSIVE-Abbruchzeugen Raw/Norm blockieren ein tatsächlich mehrteiliges Pack vor complete. Echter Runtime-Conditionwait und SIGINT-Handler-ACK vor Freigabe.
Keine GPU-busy-Behauptung. Quieszenz und Snapshot-bis-Flush-Stabilität nur im belegten Umfang.

## Feste Zeitreihe

MRL1024, Float32, volle WikiText und MASSIVE, Raw/Norm, M4 Pro 8P+4E.
16 vollständige ABBA/BAAB-Blöcke pro Zelle, fünf Pässe pro Seite, Seitenminimum. Keine Aufstockung nach Ergebnis.
Drei Unterblöcke: CPU10 A/B, CPU12 A/B, MLX12 B/D. Ihre Folge kehrt sich pro Runde um.
AB: A1,B1,B2,A2, nächste Runde B1,A1,A2,B2. BD entsprechend B1,D1,D2,B2 beziehungsweise D1,B1,B2,D2.
32 gepaarte Quotienten in 16 Clustern, A/A, B/B und D/D vollständig. 3840 akzeptierte zeitgemessene Pässe insgesamt.
Alle vier festen CPU-Konfigurationen bleiben fair sichtbar. MLX B und D werden je Runde/Position mit jeder verglichen. Kein CPU-Minimum pro Paar.
Absolute Zeiten, Texte/s, gepaarte Median-/Min-/Maxwerte, Starts/Taskzahl, RSS und Workspace vollständig berichten.
Ungünstig gefüllte oder einzelne Gruppen während der Zeitreihe bleiben gültig. Niemals nach Startzahl oder Vorteil auswählen.
Volle Bits gegen unveränderte akzeptierte Referenzen außerhalb der Encode-Uhr. Zunächst unveränderte strenge Bitprüfung, keine nachträgliche Toleranzlockerung.
Keine Tracingzeitmarken. Minimale algorithmische Zähler sind im D-Aufwand enthalten. Kein kausaler Wandzeitanteil wird daraus berechnet.

## Sicherheits- und Fortsetzungsregel

Last1 strikt unter fünf vor und nach Pass, Seite und Subprozess. Pause und Ownership unmittelbar prüfen. Ein eigener bench.lock.
Nur exakt bestätigte endliche Laststopps dürfen nach eigener terminaler Finderfreigabe mit sofortiger/verzögerter Dublettenprüfung fortsetzen.
Nur letzter unverzweigter Terminalroot, fertige Jobs/Blöcke nie wiederholen. Ganzen unvollständigen Block verwerfen und Rawdaten behalten.
Jede Bitabweichung, jeder Fallback, Layout-/Speicher-/Fehlerzuordnungs-/Lease-/Abbruch-/Identitäts-/Aufsichtsfehler ist Nichtlaststopp ohne Retry.
Originale werden per finally restauriert. Fortschrittspulse nur an echten Phasen/Passgrenzen. Owner-EOF und Prozessgruppenaufsicht bleiben aktiv.
Keine Zeitcaps. Gemeinsamen budget.jsonl fortführen, historischen Ledger und Matrixdaten unverändert. Stufe-2-Abschlussstand 1186.4762297509951 Sekunden.
Nach den festen Blöcken immer Ergebnisprüfung. Kein Sieg bei bloß günstigem Einzelpaar. Fortsetzung nur korrekt, rückfallfrei und mit konkreter plausibler Restlücke zu CPU10/12.
Stufe 4 oder 5 wird nicht jetzt implementiert. Ihr Go erfolgt nach Stufe-3-Ergebnisprüfung und eigener Skriptprüfung.

## Primärquellen

- Gefrorener fse-Code: src/fse/_backends/_mlx/_device.py (_take, _launch, _complete, _collect), _kernels.py (Task, launch, view), _backend.py (_device_rows, _use), _sources.py (unveränderte Arithmetik).
- MLX Custom Metal Kernels: https://ml-explore.github.io/mlx/build/html/dev/custom_metal_kernels.html (ein Raster und deklarierte Ausgaben je Aufruf, keine Garantie für diesen Gewinn).
- MLX async_eval: https://ml-explore.github.io/mlx/build/html/python/_autosummary/mlx.core.async_eval.html (asynchrone Auswertung, bestehende Überlappung beibehalten).
- MLX v0.32.4 Auswertung: https://github.com/ml-explore/mlx/blob/v0.32.4/mlx/transforms.cpp (Arraystatus und asynchrone Auswertung, reale Packs erst nach Freigabe prüfen).
- NumPy concatenate: https://numpy.org/doc/stable/reference/generated/numpy.concatenate.html (neue gepackte Arrays und deren Kosten explizit).
- Angenommene Stufe-1- und Stufe-2-Rohdaten unter ~/Desktop/fse-m4-results/, keine fremden Forschungsbefunde nötig.

Ablage: Runner und Helper ausschließlich /Users/oliver.borchers/Desktop/fse-m4/dr147-stage3/, Berichte im Ergebnisordner.
Vorbereitung ist keine Startfreigabe. Plan und modellfrei geprüfte Hashes gehen an fse-codex. Kein Modelllauf bis zu dessen Prompt.

## Korrigierter Ownerstand vor Messstart

Der Owner bindet jetzt api.REPO. F821 aller vier Dateien und der echte ausgelagerte Owner mit Fake-API bestehen. Aktuelle Hashes und Belege: `/Users/oliver.borchers/Desktop/fse-m4-results/DR-147-stage3-owner-fix-checkpoint.md`. Frühere Hashes dieses Vorbereitungsstands sind überholt. Kein Modelllauf vor korrigierter Hashprüfung und Startprompt.
