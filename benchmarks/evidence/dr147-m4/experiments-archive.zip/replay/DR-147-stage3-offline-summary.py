"""Existing Stage3 journals only. Never imports fse/MLX or starts workloads."""
import hashlib
import json
import math
from pathlib import Path
import statistics as st
import sys

S=Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch')
R=Path('/Users/oliver.borchers/Desktop/fse-m4-results')
BLOCKS=[('cpu10','AB'),('cpu12','AB'),('mlx','BD')]

def read(path):return json.loads(Path(path).read_text())
def lines(path):return [json.loads(x)for x in Path(path).read_text().splitlines()]
def spread(v):return {'values':v,'median':st.median(v),'min':min(v),'max':max(v)}

def main():
 ledger=lines(S/'budget.jsonl')
 roots=[Path(e['root'])for e in ledger if e['kind']=='start'and e.get('stage')==3]
 state=read(roots[-1]/'state.json')
 assert state['status']=='complete','final offline summary requires complete terminal Stage3'
 audits,memory,cancel,cells,discarded,load_stops={},{},{},{},[],[]
 total=0
 for root in roots:
  stop=read(root/'state.json').get('stop')
  if stop:load_stops.append({'root':str(root),'stop':stop})
 for job,item in state['jobs'].items():
  path=Path(item['result']);assert hashlib.sha256(path.read_bytes()).hexdigest()==item['result_sha256']
  result=read(path);assert result['status']=='complete'
  assert result['protocol']==state['protocol']
  assert result['identity']['commit']=='ef4d6a7bb33ac65a711458365312a5c0faf0b96a'
  assert result['identity']['native_checksum']=='xxh3-128:2d9d0a93859e347a5220443fab372260'
  if result['kind']=='audit':
   assert result['bits_equal']is True and result['fallback_events']=={} and result['leases_released']is True
   assert result['kernel_cache_identity_unchanged']is True
   mapping=result['task_map'];stats=result['packing'];packs=result['packs']
   assert sorted([[v['first_row'],v['rows']]for v in mapping])==sorted(result['plan']['spans'])
   assert len(mapping)==stats['jobs']==result['plan']['tasks']
   assert len({v['job_id']for v in mapping})==len(mapping)
   assert 0<stats['dispatches']<stats['jobs'] and stats['packed_dispatches']>0
   byid={v['job_id']:v for v in mapping};seen=set()
   for pack in packs:
    assert 2<=len(pack['job_ids'])<=8 and not seen.intersection(pack['job_ids'])
    seen.update(pack['job_ids'])
    original=[byid[j]for j in pack['job_ids']]
    assert [[v['first_row'],v['rows'],v['tokens']]for v in original]==pack['original_tasks']
    assert all(v['group']==pack['group']for v in original)
    assert sum(v['rows']for v in original)==pack['packed_rows']
    assert sum(v['tokens']for v in original)==pack['packed_tokens']<=1<<24
    assert pack['host_pack_bytes']==4*(pack['packed_rows']+pack['packed_tokens']+1)<=128<<20
   assert len(seen)==stats['packed_jobs'] and len(packs)==stats['packed_dispatches']
   assert sum(p['host_pack_bytes']for p in packs)==stats['host_pack_bytes']
   assert result['original_input_error']['first_row']>0
   assert result['original_input_error']['errors']['cpu']==result['original_input_error']['errors']['mlx_D']
   audits[job]=result;continue
  if result['kind']=='memory':
   assert result['bits_equal']is True and result['fallback_events']=={}
   assert result['workspace_capacity_bytes']<=512*1024**2
   assert result['rss_safety_peak_with_reader_and_bits_bytes']<=8*1024**3
   if job.endswith('-D'):
    assert result['packing']['jobs']==result['plan']['tasks']
    assert 0<result['packing']['dispatches']==result['gpu_launches']<result['plan']['tasks']
    assert result['packing']['largest_host_pack_bytes']<=128<<20
   else:assert result['gpu_launches']==result['plan']['tasks']
   memory[job]=result;continue
  if result['kind']=='cancel':
   assert result['keyboard_interrupt']is True and result['fallback_events']=={} and result['leases_released']is True
   assert result['blocked_wait_proof']['lock_handshakes']is True and result['blocked_wait_proof']['gpu_busy_claim']is False
   assert result['writer_threads_after_cleanup']==[] and result['queue_empty_after_cleanup']is True
   assert result['unchanged_after_snapshot_through_final_flush']is True
   assert result['shared_packs_at_completion']
   assert any(len(set(v['shared_output_tuple_ids']))<len(v['shared_output_tuple_ids'])for v in result['shared_packs_at_completion'])
   witness=read(path.parent/'cancel-witness.json')
   ack=witness['signal_handler_ack']
   assert ack['from_sigint_handler']is True and ack['pid']==witness['witness']['pid']
   assert witness['release_at']>=ack['at']>=witness['signal_sent_at']
   cancel[job]=result;continue
  assert len(result['rounds'])==16 and result['bits_equal']is True and result['fallback_events']=={}
  assert result['kernel_cache_identity_unchanged']is True
  kept,loads,start_counts={},[],{}
  for root in roots:
   folder=root/job
   if not(folder/'guards.jsonl').exists():continue
   events=lines(folder/'guards.jsonl')
   pass_events=[x for x in events if x.get('event')=='pass']
   passes={(x['round'],x['block'],x['side'],x['pass']):x for x in pass_events}
   assert len(passes)==len(pass_events),'duplicate raw pass key'
   checked={(x['round'],x['block'],x['side'],x['pass']):x for x in events if x.get('event')=='pass_validated'}
   assert len(checked)==sum(x.get('event')=='pass_validated' for x in events),'duplicate validation key'
   for event in [x for x in events if x.get('event')=='round_kept']:
    idx=event['index'];assert idx not in kept,'complete block rerun'
    record={k:v for k,v in event.items()if k!='event'};assert record==result['rounds'][idx]
    expected_blocks=BLOCKS if idx%2==0 else list(reversed(BLOCKS))
    assert record['blocks']==[b[0]for b in expected_blocks]
    for block,comparison in BLOCKS:
     a,b=comparison
     expected_order=[a+'1',b+'1',b+'2',a+'2']if idx%2==0 else[b+'1',a+'1',a+'2',b+'2']
     assert record['orders'][block]==expected_order
     for variant in comparison:
      for side in [variant+'1',variant+'2']:
       values=[]
       for n in range(5):
        key=idx,block,side,n;p,v=passes[key],checked[key]
        assert v['bits_equal']is True and v['fallback_events']=={}
        assert math.isfinite(p['seconds'])and p['seconds']>0
        assert all(math.isfinite(p[k])and p[k]<5 for k in['load_before','load_after'])
        if block=='mlx':
         assert p['logical_gpu_jobs']==result['plans'][block+':'+variant]['tasks']
         assert 0<p['gpu_pool_starts']<=p['logical_gpu_jobs']
         if variant=='D':
          pack=p['packing']
          assert pack['dispatches']==p['gpu_pool_starts'] and pack['jobs']==p['logical_gpu_jobs']
          assert pack['packed_jobs']+pack['dispatches']-pack['packed_dispatches']==pack['jobs']
         else:assert p['gpu_pool_starts']==p['logical_gpu_jobs']
        else:assert p['gpu_pool_starts']==p['logical_gpu_jobs']==0
        counts=start_counts.setdefault(block+':'+variant,{v:[]for v in ['gpu_pool_starts','logical_gpu_jobs','device_evaluations','host_pack_bytes']})
        for v in ['gpu_pool_starts','logical_gpu_jobs','device_evaluations']:counts[v].append(p[v])
        counts['host_pack_bytes'].append(p['packing']['host_pack_bytes'])
        values.append(p['seconds']);loads.extend([p['load_before'],p['load_after']]);total+=1
       assert min(values)==record['times'][block][side]
    for x in events:
     if x.get('event')!='guard':continue
     label=x['label'];prefix=label.split(':',1)[0]
     if(prefix.isdigit()and int(prefix)==idx)or label.startswith(f'round{idx} '):
      assert x['finite_load']and x['load']<5;loads.append(x['load'])
    kept[idx]=record
   partial=read(folder/'result.json')
   if partial.get('incomplete_round'):
    idx=partial['incomplete_round']['index']
    for key,v in checked.items():
     if key[0]==idx:assert v['bits_equal']is True and v['fallback_events']=={}
    assert {key for key in passes if key[0]==idx}=={key for key in checked if key[0]==idx}
    discarded.append({'root':str(root),'job':job,'index':idx,'stop':partial.get('stop'),
                      'pass_count':sum(k[0]==idx for k in passes),'validated_pass_count':sum(k[0]==idx for k in checked)})
  assert sorted(kept)==list(range(16))
  rounds=[kept[i]for i in range(16)];absolute,ratios,aa={},{},{}
  for block,comparison in BLOCKS:
   a,b=comparison
   ratios[block+':'+b+'/'+a]=spread([r['times'][block][b+str(i)]/r['times'][block][a+str(i)]for r in rounds for i in[1,2]])
   for v in comparison:
    values=[r['times'][block][v+str(i)]for r in rounds for i in[1,2]]
    absolute[block+':'+v]={'seconds':spread(values),'texts_per_s':spread([result['corpus']['texts']/t for t in values])}
    aa[block+':'+v+'2/'+v+'1']=spread([r['times'][block][v+'2']/r['times'][block][v+'1']for r in rounds])
  for mblock,variants in[('mlx','BD')]:
   for mv in variants:
    for cpu in['cpu10','cpu12']:
     for cv in'AB':ratios[f'{mblock}:{mv}/{cpu}:{cv}']=spread([r['times'][mblock][mv+str(i)]/r['times'][cpu][cv+str(i)]for r in rounds for i in[1,2]])
  assert result['summary']['absolute']==absolute and result['summary']['ratios']==ratios and result['summary']['AA_BB_DD']==aa
  cells[job]={'reference_result':str(path),'clusters':16,'paired_values_per_comparison':32,'accepted_passes':960,
              'start_statistics':{k:{v:spread(a)for v,a in vals.items()}for k,vals in start_counts.items()},
              'texts':result['corpus']['texts'],'absolute':absolute,'ratios':ratios,'AA_BB_DD':aa,
              'load_min':min(loads),'load_max':max(loads),'plans':result['plans'],'bits_equal':True,'fallback_events':{}}
 assert total==3840 and len(audits)==4 and len(memory)==8 and len(cancel)==2
 old=S/'mlx-gate-budget.jsonl';assert hashlib.sha256(old.read_bytes()).hexdigest()==ledger[0]['source_sha256']
 charges=[x for x in ledger if x['kind']=='finish'and x.get('stage')==3]
 value={'stage':3,'latest_root':str(roots[-1]),'roots':list(map(str,roots)),'protocol':state['protocol'],
        'cells':cells,'audits':audits,'memory':memory,'cancellation':cancel,'discarded_blocks':discarded,'load_stops':load_stops,
        'accepted_passes':total,'stage_active_seconds':sum(x['active_seconds']for x in charges),'per_attempt':charges,
        'global_actual_seconds':ledger[0]['seconds']+sum(x.get('active_seconds',0)for x in ledger if x['kind']in['finish','admission_rejected']),
        'historical_matrix_seconds':523.0340705840008,'historical_ledger_unchanged':True}
 target=R/'DR-147-stage3-summary.json'
 if sys.argv[1:]==['--verify-only']:
  assert read(target)==value,'stored summary mismatch'
  print('Read-only replay exact: 64 blocks,3840 accepted passes; all ratios,absolute,AA,starts,pack/error/lease,memory,cancellation,identity,accounting. Discarded passes='+str(sum(v['pass_count']for v in discarded)))
 else:
  assert not sys.argv[1:]
  with target.open('x')as f:json.dump(value,f,indent=2);f.write('\n')
  print(str(target))

if __name__=='__main__':main()
