"""Existing Stage2 journals only. Never imports fse/MLX or starts workloads."""
import hashlib
import json
import math
from pathlib import Path
import statistics as st
import sys

S=Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch')
R=Path('/Users/oliver.borchers/Desktop/fse-m4-results')
BLOCKS=[('cpu10','AB'),('mlx_AB','AB'),('cpu12','AB'),('mlx_BC','BC')]

def read(path):return json.loads(Path(path).read_text())
def lines(path):return [json.loads(x)for x in Path(path).read_text().splitlines()]
def spread(v):return {'values':v,'median':st.median(v),'min':min(v),'max':max(v)}

def main():
 ledger=lines(S/'budget.jsonl')
 roots=[Path(e['root'])for e in ledger if e['kind']=='start'and e.get('stage')==2]
 state=read(roots[-1]/'state.json')
 assert state['status']=='complete','final offline summary requires complete terminal Stage2'
 audits,memory,cancel,cells,discarded,load_stops={},{},{},{},[],[]
 total=0
 for root in roots:
  stop=read(root/'state.json').get('stop')
  if stop:load_stops.append({'root':str(root),'stop':stop})
 for job,item in state['jobs'].items():
  path=Path(item['result']);assert hashlib.sha256(path.read_bytes()).hexdigest()==item['result_sha256']
  result=read(path);assert result['status']=='complete'
  assert result['protocol']==state['protocol'] and result['api_refusal']is None
  assert result['identity']['commit']=='ef4d6a7bb33ac65a711458365312a5c0faf0b96a'
  assert result['identity']['native_checksum']=='xxh3-128:2d9d0a93859e347a5220443fab372260'
  if result['kind']=='audit':
   assert result['bits_equal']is True and result['fallback_events']=={}
   assert result['owner_fixture']['sole_owner_retained_by_public_import']is True
   assert result['owner_fixture']['released_after_imported_arrays_dropped']is True
   imports=result['imports'];assert len(imports)==2*result['plan']['tasks']
   for x in imports:
    assert x['pointer_equal']and x['shares_memory']and x['unchanged_through_flush']and x['hash_before']==x['hash_after']
   audits[job]=result;continue
  if result['kind']=='memory':
   assert result['bits_equal']is True and result['fallback_events']=={} and result['api_refusal']is None
   assert result['workspace_capacity_bytes']<=512*1024**2
   assert result['rss_safety_peak_with_reader_and_bits_bytes']<=8*1024**3
   memory[job]=result;continue
  if result['kind']=='cancel':
   assert result['keyboard_interrupt']is True and result['fallback_events']=={} and result['api_refusal']is None
   assert result['blocked_wait_proof']['lock_handshakes']is True and result['blocked_wait_proof']['gpu_busy_claim']is False
   assert result['writer_threads_after_cleanup']==[] and result['queue_empty_after_cleanup']is True
   assert result['unchanged_after_snapshot_through_final_flush']is True
   assert result['input_owner_completion_checks'] and all(x['alive_before_complete']and x['pointer_equal']and x['shares_memory']for x in result['input_owner_completion_checks'])
   cancel[job]=result;continue
  assert len(result['rounds'])==16 and result['bits_equal']is True and result['fallback_events']=={}
  assert result['kernel_cache_identity_unchanged']is True
  kept,loads={},[]
  for root in roots:
   folder=root/job
   if not(folder/'guards.jsonl').exists():continue
   events=lines(folder/'guards.jsonl')
   pass_events=[x for x in events if x.get('event')=='pass']
   passes={(x['round'],x['block'],x['side'],x['pass']):x for x in pass_events}
   assert len(passes)==len(pass_events),'duplicate raw pass key'
   checked={(x['round'],x['block'],x['side'],x['pass']):x for x in events if x.get('event')=='pass_validated'}
   assert len(checked)==sum(x.get('event')=='pass_validated' for x in events),'duplicate validation key'
   for event in [x for x in events if x.get('event')=='round_kept']:
    idx=event['index'];assert idx not in kept,'complete block rerun'
    record={k:v for k,v in event.items()if k!='event'};assert record==result['rounds'][idx]
    expected_blocks=BLOCKS if idx%2==0 else list(reversed(BLOCKS))
    assert record['blocks']==[b[0]for b in expected_blocks]
    for block,comparison in BLOCKS:
     a,b=comparison
     expected_order=[a+'1',b+'1',b+'2',a+'2']if idx%2==0 else[b+'1',a+'1',a+'2',b+'2']
     assert record['orders'][block]==expected_order
     for variant in comparison:
      for side in [variant+'1',variant+'2']:
       values=[]
       for n in range(5):
        key=idx,block,side,n;p,v=passes[key],checked[key]
        assert v['bits_equal']is True and v['fallback_events']=={}
        assert math.isfinite(p['seconds'])and p['seconds']>0
        assert all(math.isfinite(p[k])and p[k]<5 for k in['load_before','load_after'])
        values.append(p['seconds']);loads.extend([p['load_before'],p['load_after']]);total+=1
       assert min(values)==record['times'][block][side]
    for x in events:
     if x.get('event')!='guard':continue
     label=x['label'];prefix=label.split(':',1)[0]
     if(prefix.isdigit()and int(prefix)==idx)or label.startswith(f'round{idx} '):
      assert x['finite_load']and x['load']<5;loads.append(x['load'])
    kept[idx]=record
   partial=read(folder/'result.json')
   if partial.get('incomplete_round'):
    idx=partial['incomplete_round']['index']
    for key,v in checked.items():
     if key[0]==idx:assert v['bits_equal']is True and v['fallback_events']=={}
    assert {key for key in passes if key[0]==idx}=={key for key in checked if key[0]==idx}
    discarded.append({'root':str(root),'job':job,'index':idx,'stop':partial.get('stop'),
                      'pass_count':sum(k[0]==idx for k in passes),'validated_pass_count':sum(k[0]==idx for k in checked)})
  assert sorted(kept)==list(range(16))
  rounds=[kept[i]for i in range(16)];absolute,ratios,aa={},{},{}
  for block,comparison in BLOCKS:
   a,b=comparison
   ratios[block+':'+b+'/'+a]=spread([r['times'][block][b+str(i)]/r['times'][block][a+str(i)]for r in rounds for i in[1,2]])
   for v in comparison:
    values=[r['times'][block][v+str(i)]for r in rounds for i in[1,2]]
    absolute[block+':'+v]={'seconds':spread(values),'texts_per_s':spread([result['corpus']['texts']/t for t in values])}
    aa[block+':'+v+'2/'+v+'1']=spread([r['times'][block][v+'2']/r['times'][block][v+'1']for r in rounds])
  for mblock,variants in[('mlx_AB','AB'),('mlx_BC','BC')]:
   for mv in variants:
    for cpu in['cpu10','cpu12']:
     for cv in'AB':ratios[f'{mblock}:{mv}/{cpu}:{cv}']=spread([r['times'][mblock][mv+str(i)]/r['times'][cpu][cv+str(i)]for r in rounds for i in[1,2]])
  assert result['summary']['absolute']==absolute and result['summary']['ratios']==ratios and result['summary']['AA_BB_CC']==aa
  cells[job]={'reference_result':str(path),'clusters':16,'paired_values_per_comparison':32,'accepted_passes':1280,
              'texts':result['corpus']['texts'],'absolute':absolute,'ratios':ratios,'AA_BB_CC':aa,
              'load_min':min(loads),'load_max':max(loads),'plans':result['plans'],'bits_equal':True,'fallback_events':{}}
 assert total==5120 and len(audits)==4 and len(memory)==8 and len(cancel)==2
 old=S/'mlx-gate-budget.jsonl';assert hashlib.sha256(old.read_bytes()).hexdigest()==ledger[0]['source_sha256']
 charges=[x for x in ledger if x['kind']=='finish'and x.get('stage')==2]
 value={'stage':2,'latest_root':str(roots[-1]),'roots':list(map(str,roots)),'protocol':state['protocol'],
        'cells':cells,'audits':audits,'memory':memory,'cancellation':cancel,'discarded_blocks':discarded,'load_stops':load_stops,
        'accepted_passes':total,'stage_active_seconds':sum(x['active_seconds']for x in charges),'per_attempt':charges,
        'global_actual_seconds':ledger[0]['seconds']+sum(x.get('active_seconds',0)for x in ledger if x['kind']in['finish','admission_rejected']),
        'historical_matrix_seconds':523.0340705840008,'historical_ledger_unchanged':True}
 target=R/'DR-147-stage2-summary.json'
 if sys.argv[1:]==['--verify-only']:
  assert read(target)==value,'stored summary mismatch'
  print('Read-only replay exact: 64 blocks, 5120 accepted passes, all ratios/absolute/AA, 264 discarded bitvalidations, API/memory/cancellation/identity/accounting.')
 else:
  assert not sys.argv[1:]
  with target.open('x')as f:json.dump(value,f,indent=2);f.write('\n')
  print(str(target))

if __name__=='__main__':main()
