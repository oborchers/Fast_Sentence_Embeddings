"""Parse existing stage1 evidence only. No fse/model/measurement imports or execution."""
import hashlib
import json
import math
from pathlib import Path
import statistics as st

S = Path('/Users/oliver.borchers/Desktop/Code/fse-m4-scratch')
R = Path('/Users/oliver.borchers/Desktop/fse-m4-results')


def read(path):
    return json.loads(Path(path).read_text())


def lines(path):
    return [json.loads(x) for x in Path(path).read_text().splitlines()]


def spread(values):
    return {'values': values, 'median': st.median(values), 'min': min(values), 'max': max(values)}


def main():
    ledger = lines(S / 'budget.jsonl')
    roots = [Path(x['root']) for x in ledger if x['kind'] == 'start' and x.get('stage') == 1]
    state = read(roots[-1] / 'state.json')
    assert state['status'] == 'complete', 'offline final replay needs complete terminal stage1'
    outputs, memory, cancel, discarded = {}, {}, {}, []
    total_passes = 0
    for name, item in state['jobs'].items():
        path = Path(item['result'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['result_sha256']
        result = read(path)
        assert result['status'] == 'complete'
        if result['kind'] == 'memory':
            memory[name] = result
            continue
        if result['kind'] == 'cancel':
            cancel[name] = result
            continue
        assert len(result['rounds']) == 16 and result['bits_equal'] and result['fallback_events'] == {}
        records, loads = {}, []
        for root in roots:
            folder = root / name
            if not (folder / 'guards.jsonl').exists():
                continue
            events = lines(folder / 'guards.jsonl')
            passes = {(e['round'], e['backend'], e['side'], e['pass']): e for e in events if e.get('event') == 'pass'}
            validated = {(e['round'], e['backend'], e['side'], e['pass']): e for e in events if e.get('event') == 'pass_validated'}
            for kept in [e for e in events if e.get('event') == 'round_kept']:
                index = kept['index']
                assert index not in records, 'complete block was rerun'
                record = {k: v for k, v in kept.items() if k != 'event'}
                assert record == result['rounds'][index]
                for backend in ['cpu10', 'cpu12', 'mlx']:
                    for side in ['A1', 'B1', 'B2', 'A2']:
                        times = []
                        for n in range(5):
                            key = index, backend, side, n
                            p, v = passes[key], validated[key]
                            assert v['bits_equal'] is True and v['fallback_events'] == {}
                            assert math.isfinite(p['seconds']) and p['seconds'] > 0
                            assert all(math.isfinite(p[k]) and p[k] < 5 for k in ['load_before', 'load_after'])
                            loads += [p['load_before'], p['load_after']]
                            times.append(p['seconds'])
                            total_passes += 1
                        assert min(times) == record['times'][backend][side]
                for event in events:
                    if event.get('event') != 'guard':
                        continue
                    label = event['label']
                    prefix = label.split(':', 1)[0]
                    matching = (prefix.isdigit() and int(prefix) == index) or label.startswith(f'round{index} ')
                    if matching:
                        assert event['finite_load'] is True and event['load'] < 5
                        loads.append(event['load'])
                records[index] = record
            attempt_result = read(folder / 'result.json')
            if attempt_result.get('incomplete_round'):
                idx = attempt_result['incomplete_round']['index']
                discarded.append({'root': str(root), 'job': name, 'index': idx,
                                  'stop': attempt_result.get('stop'),
                                  'pass_count': sum(k[0] == idx for k in passes),
                                  'validated_pass_count': sum(k[0] == idx for k in validated)})
        assert sorted(records) == list(range(16))
        rounds = [records[i] for i in range(16)]
        absolute, ratio, aa, bb = {}, {}, {}, {}
        texts = result['corpus']['texts']
        for backend in ['cpu10', 'cpu12', 'mlx']:
            for variant in ['A', 'B']:
                values = [r['times'][backend][variant + str(i)] for r in rounds for i in [1, 2]]
                absolute[f'{backend}:{variant}'] = {'seconds': spread(values), 'texts_per_s': spread([texts / x for x in values])}
            ratio[f'{backend}:B/A'] = spread([r['times'][backend][b] / r['times'][backend][a] for r in rounds for a, b in [('A1', 'B1'), ('A2', 'B2')]])
            aa[backend] = spread([r['times'][backend]['A2'] / r['times'][backend]['A1'] for r in rounds])
            bb[backend] = spread([r['times'][backend]['B2'] / r['times'][backend]['B1'] for r in rounds])
        for cpu in ['cpu10', 'cpu12']:
            for mv in ['A', 'B']:
                for cv in ['A', 'B']:
                    ratio[f'mlx:{mv}/{cpu}:{cv}'] = spread([r['times']['mlx'][mv + str(i)] / r['times'][cpu][cv + str(i)] for r in rounds for i in [1, 2]])
        outputs[name] = {'reference_result': str(path), 'texts': texts, 'clusters': 16,
                         'ratios_per_configuration': 32, 'passes': 960, 'absolute': absolute,
                         'ratios': ratio, 'AA': aa, 'BB': bb, 'load_min': min(loads), 'load_max': max(loads),
                         'plans': result['plans'], 'bits_equal': True, 'fallback_events': {}}
    assert total_passes == 3840 and len(memory) == 12 and len(cancel) == 2
    finishes = [e for e in ledger if e['kind'] == 'finish' and e.get('stage') == 1]
    old = S / 'mlx-gate-budget.jsonl'
    assert hashlib.sha256(old.read_bytes()).hexdigest() == ledger[0]['source_sha256']
    value = {'stage': 1, 'latest_root': str(roots[-1]), 'roots': list(map(str, roots)),
             'protocol': state['protocol'], 'cells': outputs, 'memory': memory, 'cancellation': cancel,
             'discarded_blocks': discarded, 'accepted_passes': total_passes,
             'stage_active_seconds': sum(e['active_seconds'] for e in finishes),
             'global_actual_seconds': ledger[0]['seconds'] + sum(e.get('active_seconds', 0) for e in ledger if e['kind'] in ['finish', 'admission_rejected']),
             'per_attempt': finishes, 'historical_matrix_seconds': 523.0340705840008,
             'historical_ledger_unchanged': True, 'statistics_scope': '32 paired values in16 clusters; all complete blocks retained'}
    output = R / 'DR-147-stage1-summary.json'
    with output.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')
    print(str(output))


if __name__ == '__main__':
    main()
